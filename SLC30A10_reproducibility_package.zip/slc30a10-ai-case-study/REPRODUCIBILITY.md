# Reproducibility package

This package documents the completed SLC30A10 workflow and provides prompts for a separate transporter project. It was reconstructed from the conversation “文章故事讲解” (6aa4f234-fb04-83ec-804c-cb9318756cdd) and repository evidence at `03379f6af433d0134a8d910a39cd8993fc0ea9a3`. These are standardized, retrospective templates, not a claim that these exact prompt files existed before prediction. Where conversation suggestions differ from implemented methods, committed methods and scripts take precedence.

Start with [pipeline stages](PIPELINE.md), [environment and execution](ENVIRONMENT.md), [configuration template](config/pipeline.yaml), and the [prompt index](prompts/README.md). The existing [project rules](AGENTS.md) remain authoritative for operations.

## Two different forms of reuse

**Audit the completed instance:** inspect existing inputs, commands, hashes, figures and reports. Do not rerun writers in this locked project, including validators that write their own validation outputs. Verify checksums using the read-only example below. The documentation task does not reconnect to the server or claim a fresh remote audit.

**Reproduce calculations:** use an isolated local copy and a distinct remote project/environment. Reconfigure all three synchronization/execution scripts before running them; copying the local checkout alone still targets the original remote path. Replay archived raw responses and model assets, with the original software versions and seeds. Use a deliberately prepared stage input copy; do not remove this project's lock or overwrite its outputs. Existing fetchers and frozen-stage writers may refuse to overwrite inputs. Historical absolute paths and hashes in manifests require explicit provenance when porting. Live retrieval is a new dataset, not exact replay.

**Test a new transporter:** create a fresh repository with empty output directories and a fresh blind agent context. Copy only generic templates and reviewed implementation code; do not supply the SLC30A10 ground truth, final report, candidate lists, or this instance's revealed results to that agent. Replace target/accession/family/taxonomy/sequence length and local/remote locations in a new config, audit hard-coded values in scripts, and implement config loading or a documented mapping before execution. The YAML is a specification only: existing scripts do not read it. Freeze methods, numerical parameters, target-independent chemistry and sampling rules before generating results. Keep target-specific adaptations and any deviations in a dated ledger before reveal. Do not improve agreement by tuning after reveal.

## Concrete instance and checkpoints

Target: human SLC30A10, UniProt Q6XR72, 485 residues; 60 candidate orthologs and 10 human SLC30 paralogs. Local Mac repository: `/path/to/slc30a10_ai`. Scientific computation: Linux via SSH alias `slc-server`, remote `/path/to/projects/slc30a10_ai`, Conda `/path/to/conda/envs/slc30a10_ai`.

| Checkpoint | Full Git commit | Meaning |
|---|---|---|
| Pre-lock | `9dd83e1c946f127f9475fad47de6b9f8390249d7` | Validated Steps 1–6 and mutation panel |
| Blind freeze | `008b7ad7a436fc02898292ec7d0441cf0df6c390` | Immutable blind checkpoint |
| Step 7 | `2a9cbac6a2a4d0eca963918648fdfddd46ecbeca` | Experimental comparison |
| Step 8A | `5af7e3e53e36e91f47c884da9932e37aa4b44f05` | Matched-null evaluation |
| Technical report | `03379f6af433d0134a8d910a39cd8993fc0ea9a3` | Final case study |

There are no separate Step 1–5 commits in this repository history; do not invent them. The lock file's “subsequent commit” refers to the freeze commit above, not today's HEAD. Historical counts (137 snapshot files; later report validation of 245 preceding tracked files) describe their respective checkpoints, not the present repository file count.

## Freeze, reveal and integrity

Before reveal, freeze sequence, data selection, methods, scores, ranks, mutation tiers, controls, figures, scripts, provenance and the final prediction. Save SHA256 manifests and a lock, verify local/remote bytes, then commit and record the full commit outside the manifest to avoid self-referential hashing. Verify the lock and both manifests before any target-paper access. Once revealed, new work belongs in ground-truth/comparison outputs; blind files stay immutable. Any scientific correction must be a separately labeled analysis, never a replacement frozen prediction.

The [lock](reports/BLIND_PHASE_LOCKED.txt), [final manifest](results/FINAL_BLIND_PREDICTION.sha256) and [blind-file manifest](results/BLIND_PHASE_FILES.sha256) are the audit boundary. Final prediction report SHA256: `993e35a04785a0a1c778ad073ed2f3af2074c8a20a83596aa60def8e7f07de4a`.

Read-only local verification from the repository root (macOS Python 3):

```sh
cd /path/to/slc30a10_ai
git status --porcelain
python3 -B - <<'VERIFY'
from pathlib import Path
import hashlib
for manifest in ['results/FINAL_BLIND_PREDICTION.sha256', 'results/BLIND_PHASE_FILES.sha256']:
    rows = Path(manifest).read_text().splitlines()
    for row in rows:
        expected, name = row.split(maxsplit=1)
        path = Path(name.lstrip('*'))
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, path
    print(manifest, len(rows), 'entries verified')
VERIFY
git log --format='%H %s'
```

A clean status is empty output. On failure stop; do not regenerate a hash to make a mismatch disappear. Hash verification proves byte identity, not absence of prior knowledge or biological correctness.

## Provenance and limitations

For every fresh stage record UTC time, exact command/working directory, full Git commit, input/output hashes, service URLs and retrieval dates, software versions, threads, random streams, runtime, QC failures and deviations. Commit the actual prompt used and its response/decision record in the new project. Do not store SSH private keys, credentials or hidden functional annotations.

The Step 3 score actually used is coverage × identity × other-paralog coverage × (1 − other-paralog identity), not the alternate square-root coverage formula suggested in conversation. [Step 6 methods](data/processed/step6_prespecified_methods.md) disclose a post-ranking, pre-freeze control correction to S56T/T90S; the initial panel is archived under [superseded outputs](data/raw/step6_initial_panel_superseded/). Do not portray this correction as prospective preregistration.

Step 7 methods were specified after reading ground truth but before performance calculation; Step 8A is retrospective evaluation. The study is prospective-style blind prediction, not a fully independent prospective experiment. Gene-name orthology is provisional. Predicted-structure training/template influences are not eliminated; experimental structures were initialized from AlphaFold2. Untested residues are not false positives. Representative-atom proximity cannot establish metal coordination. Strict NULL 5 had only nine possible sets for benchmarks A/B and no corrected significance; geometry's independent contribution remains inconclusive.

The [full report](reports/SLC30A10_AI4SCIENCE_TECHNICAL_REPORT.md), [summary](reports/SLC30A10_AI4SCIENCE_TECHNICAL_REPORT_SUMMARY.md), [Step 7 protocol](comparison/methods_prespecified.md) and [Step 8A protocol](comparison/matched_null/METHODS_PRESPECIFIED.md) preserve the detailed evidence and interpretation.
