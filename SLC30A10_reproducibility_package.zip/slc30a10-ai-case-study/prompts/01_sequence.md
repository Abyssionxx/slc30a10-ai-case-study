# Step 1 — canonical sequence

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../scripts/fetch_slc30a10_sequence.py). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Retrieve only authoritative sequence/identity metadata for ${TARGET}/${ACCESSION}; exclude functional annotations, mutations, disease variants and experimental structures. Preserve raw response, query/URL, date, headers where available and SHA256. Verify one canonical sequence, accession/organism, length, standard amino-acid alphabet and numbering. Freeze FASTA and metadata; verify local/remote hashes. Do not retrieve homologs yet.

Expected deliverables: Canonical FASTA, checksum, metadata and raw retrieval/QC.

Acceptance gate: Sequence identity and transfer hashes agree; no unresolved canonical-isoform ambiguity.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
