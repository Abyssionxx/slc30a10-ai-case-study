# Standardized prompt library

These prompts reconstruct the completed workflow; they are not verbatim historical transcripts. They are intended to be copied and filled in for a new run. [Pipeline](../PIPELINE.md) supplies the concrete SLC30A10 evidence; [reproducibility](../REPRODUCIBILITY.md) explains the frozen instance and reuse boundaries.

## Contract

Replace `${TARGET}`, `${ACCESSION}` and all config placeholders. Resolve paths relative to the new repository root, check the implementation actually uses the declared parameters, and keep an actual-run copy of each prompt with UTC date/config hash/commit. Numeric methods remain fixed for a transfer experiment unless an input-specific deviation is recorded before reveal. These prompts do not automate stage execution or override AGENTS.md.

For a fresh blind run, provide only the selected blind-stage prompt, new config, rules and eligible methods/inputs in a clean agent context. Do not load this library recursively: reporting references and the existing SLC30A10 checkout contain revealed information. Reading the full completed case study cannot be undone by calling a subsequent run “blind.” Use a new target and control access to its ground truth.

At every stage verify preceding hashes, preserve raw data, record tool versions and commands, estimate resources, validate outputs and commit scoped changes. At freeze, pin the resulting commit. Reveal requires successful verification of the lock and manifests. After reveal, only new comparison/reporting files may be written. Replaying a stage requires an isolated input copy and separately configured remote destinations, not deletion of a lock.

## Order

1. [Setup and environment audit](00_setup_audit.md)
2. [Step 1 — canonical sequence](01_sequence.md)
3. [Step 2 — homolog and family datasets](02_datasets.md)
4. [Step 3 — alignments and conservation](03_conservation.md)
5. [Step 4 — topology and sequence context](04_topology.md)
6. [Step 5 — predicted structure and geometry](05_structure.md)
7. [Step 6 — mutation prioritization](06_mutations.md)
8. [Blind freeze — mandatory gate before reveal](06B_freeze.md)
9. [Step 7 — reveal and ground-truth comparison](07_ground_truth_comparison.md)
10. [Step 8 — evaluation handoff](08_evaluation_handoff.md)
11. [Step 8A — matched-null robustness](08A_matched_null.md)
12. [Technical report generation](09_technical_report.md)
