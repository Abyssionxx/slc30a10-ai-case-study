# Step 4 — topology and sequence context

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../data/processed/step4_prespecified_methods.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Use only Steps 1–3 and sequence-only topology predictors. Archive Phobius and SCAMPI-single outputs without manually editing boundaries. Strict intersection is primary; union is sensitivity. Apply the fixed <=5-residue boundary window, 19-residue hydropathy window, +/-4 polar density and >=40-residue non-TM rule. Use the six recorded chemistry classes and the exact T formula/factors from the methods. Retain every original Step 3 value. Report predictor disagreement and sensitivity rather than selecting the better-looking mask. Long non-TM length is not a disorder prediction.

Expected deliverables: Raw predictions, topology consensus/context, transport ranking, strict/union comparison, methods/QC/hashes.

Acceptance gate: Two usable predictions or an explicitly documented prescoring deviation; source sequence and Step 3 unchanged.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
