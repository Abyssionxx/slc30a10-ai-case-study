# Technical report generation

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../reports/SLC30A10_AI4SCIENCE_TECHNICAL_REPORT.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **POST-REVEAL**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Treat this as reporting only. Read frozen prediction, lock, Step 7 and Step 8A reports, source tables, figures, provenance and Git history. Write a rigorous publication-style case study: abstract, question, workflow, Results, Methods, Discussion, limitations and reproducibility. Reuse verified numbers and label new derived presentation tables. Include datasets/QC, frozen ranks, mutation panel, matched-null findings and limitations; visualize workflow, rank trajectories, topology/structure, recovery, robustness and mutation outcomes where supported. Distinguish predictions from experiments and report zero/negative/inconclusive findings. Do not claim exact prompt preregistration, independent structural validation, causal geometry gains or false positives among untested sites. Add a concise portfolio summary and validate every table/figure/reference plus all prior-file hashes. Do not optimize, recalculate Steps 1–6 or change any benchmark/null.

Expected deliverables: Full technical report, summary, sourced figures/tables and validation in new reporting paths.

Acceptance gate: Every scientific statement traces to frozen evidence; existing analyses stay byte-identical; commit only reporting outputs.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
