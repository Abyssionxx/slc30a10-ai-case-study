# Step 5 — predicted structure and geometry

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../data/processed/step5_prespecified_methods.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Use a sequence-predicted model only; archive model/version, coordinates, confidence/PAE and source metadata. Validate full sequence mapping and representative atoms (CB, CA for Gly). If no suitable predicted model exists, stop before expensive prediction and report options. Apply fixed 6 A primary graph distance, 5/8 A sensitivity, >=2 actual core helices and pLDDT rules. Use the documented geometric cavity fallback if the same methods are being transferred; keep grid/probe/rays fixed. Score with the exact S5 formula and preserve Step 3/4 values. Run the 18 specified distance/topology/confidence variants. Enumerate all-pairs <=6 A triplets/quadruplets; accept an empty table. Distinguish representative-atom proximity from coordination and heuristic secondary structure from DSSP.

Expected deliverables: Model QC, confidence/context tables, clusters/cavity voxels, constellation and score tables, sensitivity, figures and validation.

Acceptance gate: Numbering and hashes pass; zero clusters/cavities/constellations never trigger threshold relaxation.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
