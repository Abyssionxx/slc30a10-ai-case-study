# Setup and environment audit

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../AGENTS.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Read AGENTS.md and the run configuration. First summarize the goal, blind exclusions, local/remote paths, software policy and resource limits using only these files. Then perform a lightweight read-only SSH audit: connectivity, user/OS, CPU, RAM, disk, Conda prefixes and executable versions. Classify dependencies as available, missing or optional. Do not install during the audit. After the audit, configure only the authorized new user-owned project/environment; inspect installed software before any installation. Preserve host-key verification. Check all three wrappers point to this new run, use dry runs, and record versions and exact transfer commands. Do not access target-paper or residue annotations.

Expected deliverables: Environment audit, destination mapping, missing-dependency record and version manifest.

Acceptance gate: No scientific stage begins until paths, baseline status and available tools are verified.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
