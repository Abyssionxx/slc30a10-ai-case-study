# Step 6 — mutation prioritization

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../data/processed/step6_prespecified_methods.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Verify frozen Steps 1–5 and save input ranking hashes. Predeclare mutation library, chemical-loss factors, eligibility, exact M formula, tier selection and controls from the linked methods. Preserve old scores. Rank residues by maximum eligible mutation score; maintain missing ranks. Select 5/4/3 hypothesis-arm sites with no manual filling; report shortfalls. For future runs predeclare the final low-priority conservative-control rule, explicitly recognizing its historical post-ranking correction in SLC30A10. Perform the fixed partial evidence ablations without changing baseline scores. Do not download PLM weights or infer transport percentages. Produce the final blind report and validation; leave lock creation to the freeze prompt.

Expected deliverables: Mutation table, residue ranks, panel/tiers/controls, partial-ablation outputs, QC and final blind report.

Acceptance gate: Prior score bytes unchanged; baseline score reconstruction and control qualification pass.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
