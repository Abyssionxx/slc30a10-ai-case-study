# Step 8 — evaluation handoff

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../comparison/matched_null/METHODS_PRESPECIFIED.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **POST-REVEAL**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Audit completed Step 7, immutable ranks and source labels without running blind scoring. Separate full-protein enrichment from matching for biological covariates. Define benchmark membership, frozen-feature whitelist, six nulls, global bins, deterministic sparse-stratum fallback, sampling, seeds, endpoints and correction families before Step 8A p values. Record any unsupported/absent ranks and out-of-pool benchmark chemistry. This is an organizational handoff to Step 8A, not a separate historical scoring algorithm. Do not start final report synthesis before matched-null validation.

Expected deliverables: Fixed matched-null design and handoff record in a new evaluation directory.

Acceptance gate: Methods, pools and runtime preflight design are fixed; no changes made to prediction or benchmark membership.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
