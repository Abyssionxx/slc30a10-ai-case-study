# Blind freeze — mandatory gate before reveal

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../scripts/freeze_blind_predictions.py). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Use validated Steps 1–6 only. Verify clean baseline and document any approved pre-freeze corrections. Freeze all predictions, panel, input/method/script/provenance artifacts and final report. Generate SHA256 manifests, verify local and remote copies, create an explicit immutable lock and commit it. Record full freeze commit after commit creation; do not attempt to include a manifest hash inside itself. Record UTC timestamp and final-report checksum. After lock no writer may regenerate the blind phase. Do not access the target paper until the checkpoint, lock and both manifests verify.

Expected deliverables: Final prediction manifest, complete blind-file manifest, lock, verification record and full freeze commit.

Acceptance gate: All hashes agree and commit/status are recorded before reveal; never substitute current HEAD for the historical freeze commit.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
