# Step 2 — homolog and family datasets

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../data/processed/SLC30_step2_notes.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Use the frozen canonical sequence. Build separate candidate-ortholog and paralog datasets from sequence/taxonomy fields only. Predeclare queries, representative selection, length window and diversity cap. Use one representative per species, reviewed preference and deterministic ties. Record every exclusion; label gene-name orthology provisional. Keep family paralogs separate from ortholog length filtering. Verify unique IDs, alphabet, target presence, pairwise QC and hashes. No MSA or ranking yet. For exact replay use archived responses with --raw-dir in an isolated input copy.

Expected deliverables: Two frozen FASTAs, metadata, selection audits, response archives, checksums and QC.

Acceptance gate: Both datasets contain the exact target; ambiguous/duplicate/incomplete entries are accounted for.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
