# Step 7 — reveal and ground-truth comparison

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../comparison/methods_prespecified.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **POST-REVEAL**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

First verify the immutable blind checkpoint, lock, manifests and clean baseline. Only now access the target paper and supplements. Curate residue, position, substitution, assay, phenotype, structural role, evidence strength and exact source location under ground_truth. Keep substitution-specific effects, combination-only mutations and disease associations distinct. Define evaluation sets before performance computation and disclose that this is retrospective. Use stored ranks with NA retained, fixed Top 5/10/20 and tiers. Compute recall, known-positive fraction, enrichment, 100000 uniform permutations with the recorded seed and plus-one p values; cross-check hypergeometric tails. Match experimental numbering to sequence before structural comparisons. Write only new post-reveal artifacts and report limitations, including model-initialization dependence.

Expected deliverables: Curated ground truth, comparison tables/structures/provenance, Step 7 report and integrity checks.

Acceptance gate: Frozen prediction bytes unchanged; every label has a source and experimental comparisons have validated residue mapping.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
