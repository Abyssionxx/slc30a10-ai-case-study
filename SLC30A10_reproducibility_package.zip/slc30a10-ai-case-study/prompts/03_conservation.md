# Step 3 — alignments and conservation

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../data/processed/step3_prespecified_methods.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **BLIND**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Verify Step 1–2 hashes. Fix methods before scoring. Run separate MAFFT alignments using --auto --thread 8 --threadit 0 and 1200-second timeouts. Check every input ID once and exact ungapped sequence identity; map the target to 1-based positions. Compute non-gap identity, coverage, entropy and consensus. Specificity is Corth*Iorth*Cother*(1-Iother), excluding target from other-paralog statistics. Report all-family statistics separately. Preserve all positions, mean-rank percentiles and positional tie-breaks. Predeclare divergent-member sensitivity; for SLC30A10 remove the lamprey from the fixed alignment without realignment. Do not change the primary ranking based on sensitivity.

Expected deliverables: Two alignments, mapping/QC, conservation and specificity tables, sensitivity, commands/version logs and hashes.

Acceptance gate: Exact mapping, score bounds and baseline integrity pass; no topology or experimental data used.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
