# Step 8A — matched-null robustness

Reusable standardized prompt; substitute ${TARGET}, ${ACCESSION} and run paths before use. Read the [prompt contract](README.md) and [parameter template](../config/pipeline.yaml). Historical implementation reference: [source](../comparison/matched_null/METHODS_PRESPECIFIED.md). For another target, copy reviewed methods into its own project before use; do not import target answers.

## Prompt

Read the new project's AGENTS.md, run configuration and prior stage provenance first. This stage is **POST-REVEAL**. In a blind stage, do not access the target paper, experimental structures, mutations, disease variants, ground_truth, comparison or final revealed reports. Use only allowed stage inputs. If the project is already locked, perform read-only inspection instead of regenerating blind outputs.

Verify blind manifests and Step 7 membership/stored ranks. Use only frozen Step 3 identity, Step 4 topology/chemistry/transport score and Step 5 pLDDT as matching covariates. Implement NULL 0–5 exactly as the linked protocol: never condition on Step 5 geometry or Step 6 score. Fix global decile/quintile rules and <70/[70,90)/>=90 confidence categories; retain ties, eligible known sites and exact topology/chemistry. Precompute distinct-assignment feasibility and common-radius ordinal fallback. Preserve pools/strata/input hashes before tests. Pilot with a separate seed and apply the runtime approval gate. Use one thread and 1000000 accepted draws per benchmark/null, independent uniform slots and whole-tuple duplicate rejection. Use SeedSequence streams; report plus-one tails, intervals, separate Holm families, rank/NA handling, diagnostics and exact recovery checks. Do not weaken singleton or small pools. Write new evaluation outputs only; never rerun blind scoring or redefine pools after seeing p values.

Expected deliverables: Matched-null definitions, frozen pools/features, cutoff and rank results, site percentiles, diagnostics, validation and report.

Acceptance gate: Every test has the specified accepted count; exact checks and frozen-byte checks pass; sparse/unsupported cases disclosed.

Record exact commands, input/output SHA256, software versions, resource use, UTC timestamps, config and prompt hashes, deviations and the stage Git checkpoint. Run scientific computation through the configured remote wrapper; inspect dry-run transfers and verify retrieval completeness. Respect the 8-thread default and the project's >30-minute approval rule. Do not silently modify an existing output. Stop after validating this stage and report files, checks, limitations and commit.
