# Experimental mechanism: Step 7 ground truth

Source: Shen et al., *Molecular mechanisms of SLC30A10-mediated manganese transport*, Nature Communications 16, 8581 (2025), [DOI and article](https://www.nature.com/articles/s41467-025-63616-7), including its Supplementary Information and source-data workbook. Archived article XML, supplement PDF, source workbook and coordinate files are under `ground_truth/raw/`; retrieval URLs, dates and hashes are preserved there. Evidence below was accessed only after blind-checkpoint verification.

## Observations and proposed mechanism

The protein is a homodimer, with six transmembrane helices per protomer and a cytoplasmic C-terminal domain. The reported structures are Mn-bound symmetric inward-facing/inward-facing (IF/IF; 9KVX, 2.79 Å), asymmetric IF/outward-facing (IF/OF; 9KVY, 3.34 Å), and apo IF/IF (9KVZ, 2.94 Å). Mn density occurs in the IF binding site; the OF protomer lacks a corresponding resolved ion. Missing experimental residues must not be confused with deletions in the biological protein. Sources: Fig. 1, Fig. 3, Supplementary Table 1 and data availability.

The direct Mn ligands are **D40 (TM2), N127 (TM4), D248 (TM5), and S252 (TM5)**. The modeled site has a distorted octahedral oxygen coordination: D40 carboxylate oxygens, N127 side-chain carbonyl, D248 side-chain carboxylate plus backbone carbonyl, and S252 hydroxyl. E25 and M44 support the D40 environment rather than directly coordinating Mn. The paper's broader discussion of E25 as a binding-site component is not treated as direct metal ligation. Sources: Fig. 2b, Supplementary Fig. 7b–d; separate alanine assays in Fig. 2e and Supplementary Fig. 9f.

The reported IF-to-OF comparison shows TM5 turning inward by 22.4°, closing the cytoplasmic cavity; extracellular portions of TM1 and TM2 rotate outward by 37.1° and 20.6°, respectively. The coordination residues separate in the OF state. These are the authors' alignment-dependent angles, not measurements derived from the frozen topology ranges. Sources: Fig. 3c–e and Supplementary Fig. 12.

The authors propose recruitment into a negatively charged cytoplasmic cavity, transfer through D248 to the four-residue site, coupled helix rearrangement, and extracellular release. D47 is proposed to support recruitment: D47A abolishes transport while D47N/E reduce it. Static structures and mutagenesis support this working model but do not directly establish every temporal event, rate constant or counter-ion stoichiometry. The present comparison performs no new MD or docking. Sources: Fig. 2j and Fig. 4a.

## Selectivity and functional distinctions

The site differs from the conventional ZnT-family metal-binding arrangement. In SLC30A10, N43A/N43H and H244A retain transport in the reported assay; H244N and H244D reduce it. N43 therefore does not act as an experimentally sufficient single-residue explanation of Mn selectivity here. Other cavity-context substitutions and combinations reduce transport, supporting a distributed chemical/geometric explanation; reduced Mn transport alone does not prove changed ion selectivity. Observations on ZnT1 H43N are not relabeled as SLC30A10 mutations. Sources: Fig. 2f–j and Supplementary Fig. 11.

D40A, N127A, D248A, S252A and D47A define the narrow transport-essential benchmark. D248N independently supports the D248 effect. E25A, M44A, S39A, C93A and I291L also reduce transport; H244 effects depend on substitution. G251V and V254I occur in combination mutants and are not independently proven essential. Clinical variants in Supplementary Table 3 are kept in their own association category, including deletions and frameshifts that cannot identify one causal coordinating residue.

## Source discrepancies and limits

The source workbook's I291 statistical-comparison label says I291A, whereas its raw-data header, the plotted assay and localization panel label I291L; the evidence table retains I291L with the discrepancy. The Supplementary Fig. 11 localization panel labels one combination V254L while the assay plot/workbook use V254I; another localization label omits S39A from a combination. No single-site V254 or G251 effect is inferred.

Author descriptions of abolished activity are preserved as qualitative assay conclusions. Background-normalized values can be nonzero or negative; they are not literal transport rates. Lack of a statistically significant change is recorded as unchanged in the tested conditions, not proof of universal dispensability. Structural proximity, disease association, functional necessity and direct Mn coordination remain separate evidence categories.

The experimental model-building procedure started from an AlphaFold2 prediction before map fitting/refinement. Consequently, predicted-versus-experimental backbone similarity is not wholly independent validation. Cryo-EM density and separate functional assays supply additional evidence, but neither this retrospective comparison nor the previous blind phase proves absence of pretrained-model exposure to prior biology.
