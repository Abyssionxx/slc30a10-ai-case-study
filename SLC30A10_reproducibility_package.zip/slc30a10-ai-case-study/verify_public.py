from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
rows=(root/'PUBLIC_FILES.sha256').read_text().splitlines()
for row in rows:
    expected,name=row.split('  ',1)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
print(f"Verified {len(rows)} public distribution files")
