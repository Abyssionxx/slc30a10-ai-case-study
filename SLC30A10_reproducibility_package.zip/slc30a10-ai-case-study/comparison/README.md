# Step 7 artifacts

Start with [`../reports/STEP7_GROUND_TRUTH_COMPARISON.md`](../reports/STEP7_GROUND_TRUTH_COMPARISON.md). The immutable blind checkpoint is `008b7ad7a436fc02898292ec7d0441cf0df6c390`.

`step7_comparison_provenance.json` records clean-git and SHA256 verification **before** target-paper access. `methods_prespecified.md` defines retrospective benchmarks before calculation. `final_integrity_verification.json` records the post-analysis check. `STEP7_FILES.sha256` covers new artifacts, excluding itself, runtime caches and Mac filesystem metadata.

Scripts in this directory write only new Step 7 paths. Run scientific code on `slc-server`, from `/path/to/projects/slc30a10_ai`, with the preferred environment's Python. See `execution_provenance.json` for commands and versions. No old blind-phase script should be executed.

Order: `fetch_ground_truth_assets.py`, `curate_ground_truth.py`, `extract_source_workbook.py`, `analyze_blind_comparison.py`, `compare_structures.py`, `write_comparison_report.py`, then the read-only `verify_comparison.py`. Use `MPLCONFIGDIR=comparison/cache OPENBLAS_NUM_THREADS=1` when plotting. Archived downloaded sources are reused rather than overwritten; original retrieval dates remain in their original provenance JSON files. Manual source interpretation is encoded in the versioned curation script and mechanism Markdown, including conflicting figure/workbook labels.

`performance_metrics.tsv` uses residue-level benchmarks; `panel_experimental_status.tsv` evaluates exact substitutions. They intentionally differ for H244. Precision means known-positive fraction, and experimentally untested positions are not false positives. `non_single_residue_evidence.tsv` preserves combination, deletion, frameshift/splice evidence that cannot be assigned a single functional-residue rank. A disease-associated point mutation has its positional rank reported but is excluded from the functional benchmarks unless separately assayed.

No new software was installed. The Springer CDN download path failed (local certificate verification and remote DNS); the authoritative Europe PMC supplementary-files endpoint supplied the archived supplement and source workbook. No claim relies on the failed download.
