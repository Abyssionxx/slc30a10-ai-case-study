#!/usr/bin/env python3
"""Step 8A only: frozen-feature matching and immutable-rank evaluation."""
import csv,json,hashlib,time,sys,platform,warnings
from pathlib import Path
import numpy as np
from scipy.stats import beta
R=Path(__file__).resolve().parents[2];O=R/'comparison/matched_null'
SEED=2026091308;N=1000000;BATCH=20000
INPUTS=['results/tables/SLC30A10_sequence_specificity.tsv','results/tables/SLC30A10_residue_context.tsv','results/tables/SLC30A10_topology_transport_candidates.tsv','results/tables/SLC30A10_structure_confidence.tsv','results/tables/SLC30A10_mutation_prioritization.tsv','results/tables/SLC30A10_final_blind_mutation_panel.tsv','comparison/comparison_summary.json','comparison/frozen_residue_ranks.tsv','ground_truth/SLC30A10_experimental_residues.tsv']
BM={'A':'direct_coordination','B':'transport_essential','C':'individually_transport_sensitive'}
def read(p):
 with (R/p).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def write(p,rows):
 with (O/p).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
def verify_inputs():
 for manifest in ['results/FINAL_BLIND_PREDICTION.sha256','results/BLIND_PHASE_FILES.sha256']:
  for line in (R/manifest).read_text().splitlines():
   h,p=line.split(maxsplit=1);assert sha(p.strip().lstrip('*'))==h,p
 if (O/'input_manifest.json').exists():
  for p,h in json.loads((O/'input_manifest.json').read_text()).items():assert sha(p)==h,p

def features():
 s3={int(x['human_residue_number']):x for x in read(INPUTS[0])};ctx={int(x['residue_number']):x for x in read(INPUTS[1])};s4={int(x['human_residue_number']):x for x in read(INPUTS[2])};s5={int(x['residue_number']):x for x in read(INPUTS[3])}
 f=[]
 for p in range(1,486):
  assert s3[p]['human_residue']==ctx[p]['amino_acid']==s5[p]['amino_acid']
  inside=ctx[p]['inside_TM']=='True';near=ctx[p]['within5_TM_boundary']=='True'
  f.append(dict(position=p,aa=ctx[p]['amino_acid'],ortholog_identity=float(s3[p]['ortholog_identity']),inside_TM=inside,within5_TM_boundary=near,topology_class='TM' if inside else 'boundary' if near else 'non-TM',chemical_class=ctx[p]['amino_acid_class'],transport_score=float(s4[p]['transport_score']),pLDDT=float(s5[p]['pLDDT'])))
 cons=np.array([x['ortholog_identity'] for x in f]);top=np.array([x['inside_TM'] or x['within5_TM_boundary'] for x in f]);chem=np.array([x['aa'] in 'DEHNQSTCY' for x in f]);base=top&chem
 dc=np.quantile(cons,np.arange(1,10)/10,method='linear');db=np.searchsorted(dc,cons,side='right');counts=np.bincount(db[base],minlength=10)
 feasible=len(np.unique(dc))==9 and bool(np.all(counts>=11));n=10 if feasible else 5;cut=np.quantile(cons,np.arange(1,n)/n,method='linear');bins=np.searchsorted(cut,cons,side='right');tc=np.quantile([x['transport_score'] for x in f],[.2,.4,.6,.8],method='linear')
 for i,x in enumerate(f):x.update(conservation_bin=int(bins[i]),confidence_bin=0 if x['pLDDT']<70 else 1 if x['pLDDT']<90 else 2,transport_quintile=int(np.searchsorted(tc,x['transport_score'],side='right')))
 strata=dict(conservation_bin_count=n,deciles_feasible=feasible,decile_NULL2_counts=counts.tolist(),decile_cutpoints=dc.tolist(),conservation_cutpoints=cut.tolist(),transport_cutpoints=tc.tolist(),confidence_cutpoints=[70,90],quantile_method='linear; right-side assignment; no tie splitting')
 return f,strata

def feasible(pools):
 owner={}
 def assign(j,seen):
  for p in pools[j]:
   if p in seen:continue
   seen.add(p)
   if p not in owner or assign(owner[p],seen):owner[p]=j;return True
  return False
 return all(assign(j,set()) for j in sorted(range(len(pools)),key=lambda i:(len(pools[i]),i)))

def build_plan(f,sites,null):
 base=[i for i,x in enumerate(f) if null==0 or (null==5) or ((x['inside_TM'] or x['within5_TM_boundary']) and (null==1 or x['aa'] in 'DEHNQSTCY'))]
 def pool(p,radius):
  if null<3:return base.copy()
  t=f[p];out=[]
  for i in base:
   x=f[i]
   if null==5 and (x['topology_class']!=t['topology_class'] or x['chemical_class']!=t['chemical_class']):continue
   distance=abs(x['conservation_bin']-t['conservation_bin'])
   if null>=4:distance+=abs(x['confidence_bin']-t['confidence_bin'])
   if null==5:distance+=abs(x['transport_quintile']-t['transport_quintile'])
   if distance<=radius:out.append(i)
  return out
 exact=[pool(p,0) for p in sites]
 for radius in range(20):
  pools=[pool(p,radius) for p in sites]
  if feasible(pools):break
 else:raise RuntimeError('No feasible distinct matched assignment')
 return dict(null=null,sites=sites,base_pool=base,exact_pools=exact,pools=pools,radius=radius,expanded_slots=sum(a!=b for a,b in zip(exact,pools)),out_of_base=[p for p in sites if p not in base],singleton_slots=sum(len(x)==1 for x in pools))

def sample(rng,pools,n):
 """Product-uniform slots conditioned on no duplicate, independently per row."""
 out=[];have=0;proposed=0
 while have<n:
  size=min(BATCH,n-have)
  a=np.column_stack([np.asarray(p,dtype=np.int16)[rng.integers(len(p),size=size)] for p in pools]);proposed+=size
  good=np.all(np.diff(np.sort(a,axis=1),axis=1)!=0,axis=1);a=a[good];out.append(a);have+=len(a)
  if proposed>max(10000000,n*10000):raise RuntimeError('Rejection cost too high; stop for runtime assessment, do not relax pools')
 return np.concatenate(out,axis=0),proposed

def prepare():
 verify_inputs();assert not (O/'matched_null_permutation_results.tsv').exists(),'Cannot redefine pools after p-values'
 f,strata=features();write('features_frozen.tsv',f)
 bench=json.loads((R/INPUTS[6]).read_text())['benchmarks'];plans=[]
 for b,key in BM.items():
  sites=[p-1 for p in bench[key]]
  for null in range(6):plans.append(dict(benchmark=b,**build_plan(f,sites,null)))
 siteplans={str(p):{str(null):build_plan(f,[p-1],null) for null in range(5)} for p in sorted(set().union(*[set(v) for v in bench.values()]))}
 (O/'sampling_pools.json').write_text(json.dumps(dict(plans=plans,siteplans=siteplans),indent=2)+'\n');(O/'strata.json').write_text(json.dumps(strata,indent=2)+'\n')
 manifest={p:sha(p) for p in INPUTS};manifest['comparison/matched_null/METHODS_PRESPECIFIED.md']=sha('comparison/matched_null/METHODS_PRESPECIFIED.md');(O/'input_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 labels=['Uniform protein','TM or within 5 residues of boundary','Topology + DEHNQSTCY','Topology + chemistry + conservation','Topology + chemistry + conservation + pLDDT','Diagnostic: topology class + chemical class + conservation + pLDDT + Step4 quintile']
 write('null_model_definitions.tsv',[dict(null_model=i,label=labels[i],primary_or_diagnostic='diagnostic' if i==5 else 'primary',base_pool_size=len(plans[i]['base_pool']),conservation_bins=strata['conservation_bin_count'] if i>=3 else 'none',matching='product-uniform slot sampling conditioned on distinct residues',fallback='none' if i<3 else 'common nearest ordinal radius; exact topology/chemical classes retained for NULL5',seed=SEED,permutations=N) for i in range(6)])
 # Profile sampling only, on independent streams; no ranks or observed hits read.
 pilot=[]
 for j,p in enumerate(plans):
  start=time.perf_counter();a,proposed=sample(np.random.default_rng(np.random.SeedSequence([2026091309,j])),p['pools'],10000);elapsed=time.perf_counter()-start
  pilot.append(dict(benchmark=p['benchmark'],null=p['null'],seconds=elapsed,accepted=len(a),proposed=proposed))
 projected=sum(x['seconds'] for x in pilot)*100*3+120
 from datetime import datetime,timezone
 record=dict(prepared_utc=datetime.now(timezone.utc).isoformat(),pilot=pilot,projected_total_seconds=projected,approval_threshold_seconds=1800,approved_for_lightweight_execution=projected<1800,methods_sha256=manifest['comparison/matched_null/METHODS_PRESPECIFIED.md'],pool_sha256=sha('comparison/matched_null/sampling_pools.json'),strata_sha256=sha('comparison/matched_null/strata.json'))
 (O/'runtime_preflight.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(strata=strata,projected_seconds=projected,pool_sizes=[len(plans[i]['base_pool']) for i in range(6)],fallbacks=[(x['benchmark'],x['null'],x['radius']) for x in plans]),indent=2),flush=True)
 if projected>=1800:raise RuntimeError('STOP: projected runtime exceeds 30 minutes; explicit approval required')

def ci(k,n):return (0. if k==0 else float(beta.ppf(.025,k,n-k+1)),1. if k==n else float(beta.ppf(.975,k+1,n-k)))
def infer(k,n,obs,total,total2,high=True):
 mu=total/n;sd=np.sqrt(max(0,total2/n-mu*mu));lo,hi=ci(k,n)
 return dict(exceedances=int(k),permutations=n,empirical_p=(k+1)/(n+1),mc95_lower=lo,mc95_upper=hi,null_expected=float(mu),null_sd=float(sd),z_score=float((obs-mu)/sd) if sd>1e-12 else 'NA')
def holm(rows,groupfield):
 for group in sorted({x[groupfield] for x in rows}):
  xs=sorted([x for x in rows if x[groupfield]==group],key=lambda x:x['empirical_p']);last=0
  for i,x in enumerate(xs):last=max(last,min(1,(len(xs)-i)*x['empirical_p']));x['holm_p']=last;x['holm_family_size']=len(xs)

def analyze():
 verify_inputs();runtime=json.loads((O/'runtime_preflight.json').read_text());assert runtime['approved_for_lightweight_execution']
 assert runtime['pool_sha256']==sha('comparison/matched_null/sampling_pools.json');assert runtime['strata_sha256']==sha('comparison/matched_null/strata.json')
 plans=json.loads((O/'sampling_pools.json').read_text());f,_=features();saved=read('comparison/matched_null/features_frozen.tsv');assert len(saved)==485
 fr=read(INPUTS[7]);rank=np.array([int(x['Step6_rank']) if x['Step6_rank']!='NA' else 0 for x in fr]);assert len(rank)==485 and max(rank)==215
 panel=read(INPUTS[5]);tier1={int(x['residue_position'])-1 for x in panel if x['tier']=='Tier 1'};tier12={int(x['residue_position'])-1 for x in panel if x['tier'] in ['Tier 1','Tier 2']}
 cuts={**{f'Top {k}':set(np.where((rank>0)&(rank<=k))[0]) for k in [5,10,20]},'Tier 1':tier1,'Tier 1 + Tier 2':tier12};cutm=np.array([[i in c for i in range(485)] for c in cuts.values()],dtype=np.int8)
 rr=np.divide(1.,rank,out=np.zeros(485),where=rank>0);loss=np.where(rank>0,(rank-1)/215,1.)
 results=[];rankresults=[];diagnostics=[];hist=[];progress=[];started=time.perf_counter()
 for index,plan in enumerate(plans['plans']):
  start=time.perf_counter();sites=np.array(plan['sites']);b=plan['benchmark'];null=plan['null'];m=len(sites);observed=cutm[:,sites].sum(1);r=rank[sites];missing=int((r==0).sum());finite=r[r>0];om=float(finite.mean()) if len(finite) else np.inf;omed=float(np.median(finite)) if len(finite) else np.inf;orr=float(rr[sites].mean());oloss=float(loss[sites].mean())
  rng=np.random.default_rng(np.random.SeedSequence([SEED,list(BM).index(b),null]));Hs=np.zeros((5,m+1),dtype=np.int64);tails=np.zeros(4,dtype=np.int64);sums=np.zeros(4);squares=np.zeros(4);valid=np.zeros(4,dtype=int);proposed=0;digest=hashlib.sha256();sum_miss=0
  for batchstart in range(0,N,BATCH):
   a,pr=sample(rng,plan['pools'],min(BATCH,N-batchstart));proposed+=pr;digest.update(a.tobytes());assert np.all(np.diff(np.sort(a,axis=1),axis=1)!=0)
   for c in range(5):Hs[c]+=np.bincount(cutm[c,a].sum(1),minlength=m+1)
   ar=rank[a];na=(ar==0).sum(1);cnt=m-na;sum_miss+=int(na.sum());mean=np.divide(ar.sum(1),cnt,out=np.full(len(a),np.inf),where=cnt>0)
   with warnings.catch_warnings():
    warnings.simplefilter('ignore',RuntimeWarning);med=np.nanmedian(np.where(ar>0,ar,np.nan),axis=1)
   med=np.nan_to_num(med,nan=np.inf);recip=rr[a].mean(1);ls=loss[a].mean(1)
   tails[0]+=np.count_nonzero((na<missing)|((na==missing)&(mean<=om+1e-12)));tails[1]+=np.count_nonzero((na<missing)|((na==missing)&(med<=omed+1e-12)));tails[2]+=np.count_nonzero(recip>=orr-1e-12);tails[3]+=np.count_nonzero(ls<=oloss+1e-12)
   for j,v in enumerate([mean,med,recip,ls]):
    v=v[np.isfinite(v)];valid[j]+=len(v);sums[j]+=v.sum();squares[j]+=(v*v).sum()
  for c,label in enumerate(cuts):
   xs=np.arange(m+1);h=Hs[c];obs=int(observed[c]);inf=infer(h[obs:].sum(),N,obs,(h*xs).sum(),(h*xs*xs).sum());expected=inf['null_expected']
   results.append(dict(benchmark=b,benchmark_size=m,cutoff=label,prediction_size=len(cuts[label]),null_model=null,observed_recovery=obs,**inf,fold_enrichment=obs/expected if expected else 'NA' if obs==0 else 'inf',inference_family='diagnostic' if null==5 else 'primary',out_of_base_sites=';'.join(f[p]['aa']+str(p+1) for p in plan['out_of_base']),matching_supported=not bool(plan['out_of_base'])))
   for x,count in enumerate(h):hist.append(dict(benchmark=b,null_model=null,cutoff=label,recovery=x,count=int(count)))
  for j,(name,obs) in enumerate(zip(['mean_frozen_rank','median_frozen_rank','mean_reciprocal_rank','normalized_rank_loss'],[om,omed,orr,oloss])):
   lo,hi=ci(int(tails[j]),N);mu=sums[j]/valid[j];sd=np.sqrt(max(0,squares[j]/valid[j]-mu*mu))
   rankresults.append(dict(benchmark=b,null_model=null,statistic=name,observed_statistic=obs if np.isfinite(obs) else 'NA',observed_unranked_count=missing,full_set_raw_rank_defined=missing==0 if j<2 else True,null_expected=float(mu),null_summary_defined_draws=int(valid[j]),null_mean_unranked=sum_miss/N,exceedances=int(tails[j]),permutations=N,empirical_p=(int(tails[j])+1)/(N+1),mc95_lower=lo,mc95_upper=hi,z_score=float((obs-mu)/sd) if j>=2 and sd>1e-12 else 'NA',test_direction='fewer unranked then lower finite statistic' if j<2 else 'higher' if j==2 else 'lower',inference_family='diagnostic' if null==5 else 'primary',out_of_base_sites=';'.join(f[p]['aa']+str(p+1) for p in plan['out_of_base'])))
  for slot,(p,exact,pool) in enumerate(zip(plan['sites'],plan['exact_pools'],plan['pools'])):
   x=f[p];diagnostics.append(dict(benchmark=b,null_model=null,target=x['aa']+str(p+1),base_pool_size=len(plan['base_pool']),exact_stratum_size=len(exact),effective_stratum_size=len(pool),conservation_bin=x['conservation_bin'],confidence_bin=x['confidence_bin'],topology_class=x['topology_class'],chemical_class=x['chemical_class'],transport_quintile=x['transport_quintile'],fallback_radius=plan['radius'],fallback_slot_count=plan['expanded_slots'],this_slot_expanded=exact!=pool,singleton_pool=len(pool)==1,target_in_effective_pool=p in pool,benchmark_out_of_support=bool(plan['out_of_base']),duplicate_safeguard='reject entire tuple with any duplicate',proposed_tuples=proposed,rejected_tuples=proposed-N,effective_permutations=N,master_seed=SEED,seed_sequence=f'{SEED},{list(BM).index(b)},{null}',draw_sha256=digest.hexdigest()))
  elapsed=time.perf_counter()-start;progress.append(dict(benchmark=b,null_model=null,seconds=elapsed,accepted=N,proposed=proposed,draw_sha256=digest.hexdigest()));print(f'{b} NULL {null}: {N:,} accepted; {elapsed:.2f}s',flush=True)
 holm(results,'inference_family');holm(rankresults,'inference_family');write('matched_null_permutation_results.tsv',results);write('rank_based_enrichment.tsv',rankresults);write('null_sampling_diagnostics.tsv',diagnostics);write('recovery_histograms.tsv',hist)
 siteout=[]
 for pstr,sp in plans['siteplans'].items():
  p=int(pstr)-1;x=f[p];row=dict(residue=x['aa']+pstr,position=p+1,frozen_Step6_rank=int(rank[p]) if rank[p] else 'NA',ortholog_conservation=x['ortholog_identity'],pLDDT=x['pLDDT'])
  for null in range(5):
   q=sp[str(null)];pool=q['pools'][0];rp=rank[pool];percent=100*((np.count_nonzero((rp==0)|(rp>rank[p]))+.5*np.count_nonzero(rp==rank[p]))/len(pool)) if rank[p]>0 else 'NA'
   row.update({f'NULL{null}_percentile':percent,f'NULL{null}_eligible':p in pool,f'NULL{null}_exact_pool_size':len(q['exact_pools'][0]),f'NULL{null}_pool_size':len(pool),f'NULL{null}_fallback_radius':q['radius']})
  siteout.append(row)
 write('residue_matched_percentiles.tsv',siteout)
 import scipy
 from datetime import datetime,timezone
 (O/'execution_summary.json').write_text(json.dumps(dict(completed_utc=datetime.now(timezone.utc).isoformat(),seconds=time.perf_counter()-started,permutations_per_test=N,master_seed=SEED,runs=progress,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,methods_sha256=sha('comparison/matched_null/METHODS_PRESPECIFIED.md'),input_manifest_sha256=sha('comparison/matched_null/input_manifest.json')),indent=2)+'\n')
 verify_inputs()
if __name__=='__main__':
 {'prepare':prepare,'analyze':analyze}[sys.argv[1]]()
