#!/usr/bin/env python3
"""Local/remote read-only hash comparison, then Step 8A manifest creation."""
from pathlib import Path
import hashlib,json,subprocess,shlex
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[2];O=R/'comparison/matched_null'
pre=json.loads((O/'preanalysis_verification.json').read_text());base=pre['current_commit']
changes=subprocess.check_output(['git','diff','--name-status',base],cwd=R,text=True).splitlines()
extra=['figures/matched_null_enrichment.png','figures/matched_null_empirical_pvalues.png','figures/experimental_residue_matched_percentiles.png','reports/STEP8A_MATCHED_NULL_ROBUSTNESS.md']
for line in changes:
 status,p=line.split('\t',1);assert status=='A' and (p.startswith('comparison/matched_null/') or p in extra),line
blind={}
for manifest in ['results/FINAL_BLIND_PREDICTION.sha256','results/BLIND_PHASE_FILES.sha256']:
 lines=(R/manifest).read_text().splitlines()
 for line in lines:
  h,p=line.split(maxsplit=1);assert hashlib.sha256((R/p.strip()).read_bytes()).hexdigest()==h,p
 blind[manifest]={'sha256':hashlib.sha256((R/manifest).read_bytes()).hexdigest(),'entries':len(lines)}
files=sorted(p for p in O.rglob('*') if p.is_file() and p.name not in ['.DS_Store','final_integrity.json','STEP8A_FILES.sha256'] and not any(x in ['cache','__pycache__'] for x in p.relative_to(O).parts))+[R/p for p in extra]
local={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
remote_cmd='cd /path/to/projects/slc30a10_ai && sha256sum -- '+' '.join(shlex.quote(p) for p in local)
output=subprocess.check_output(['ssh','slc-server',remote_cmd],text=True)
remote={line.split(maxsplit=1)[1].strip():line.split(maxsplit=1)[0] for line in output.splitlines()}
assert local==remote,'Local/remote payload hashes differ'
record=dict(verified_utc=datetime.now(timezone.utc).isoformat(),starting_commit=base,current_precommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),blind_checkpoint=pre['blind_checkpoint'],blind_manifests=blind,old_tracked_files_unchanged=True,remote_statistical_validation=json.loads((O/'validation.json').read_text())['status'],local_remote_payload_hashes_identical=True,payload_files=len(local),payload_sha256=local,note='This JSON and final manifest are synchronized and checked after creation; payload agreement above excludes these two self-referential metadata files.')
(O/'final_integrity.json').write_text(json.dumps(record,indent=2)+'\n')
files.append(O/'final_integrity.json');(O/'STEP8A_FILES.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(R))+'\n' for p in sorted(files)))
print('Frozen files unchanged; local/remote payload agreement:',len(local),'files; final manifest entries:',len(files))
