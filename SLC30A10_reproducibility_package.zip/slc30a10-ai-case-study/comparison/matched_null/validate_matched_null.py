#!/usr/bin/env python3
"""Read-only scientific checks; writes its own Step 8A validation artifacts only."""
import csv,json,hashlib,inspect,ast,math
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
from scipy.stats import hypergeom
import matched_null as m
R=m.R;O=m.O
m.verify_inputs()
bench=json.loads((R/'comparison/comparison_summary.json').read_text())['benchmarks']
gt=m.read('ground_truth/SLC30A10_experimental_residues.tsv')
derived={'direct_coordination':{int(x['position']) for x in gt if x['experimental_category']=='1_direct_Mn_coordination'},'transport_essential':{int(x['position']) for x in gt if x['experimental_category']=='2_transport_function' and x['variant_scope']=='single' and x['transport_effect']=='abolished'},'individually_transport_sensitive':{int(x['position']) for x in gt if x['experimental_category']=='2_transport_function' and x['variant_scope']=='single' and x['transport_effect'] in ['abolished','reduced']}}
assert all(set(bench[k])==v for k,v in derived.items())
fr=m.read('comparison/frozen_residue_ranks.tsv');stored={int(x['position']):x['Step6_rank'] for x in fr};first=[]
for x in m.read('results/tables/SLC30A10_mutation_prioritization.tsv'):
 p=int(x['residue_position'])
 if p not in first:first.append(p)
assert len(first)==215
for p in range(1,486):assert stored[p]==(str(first.index(p)+1) if p in first else 'NA')
# Verification only, not regeneration or use of recomputed ranks for analysis.
features,strata=m.features();saved=m.read('comparison/matched_null/features_frozen.tsv')
for a,b in zip(features,saved):assert all(str(v)==b[k] for k,v in a.items())
assert set(features[0])=={'position','aa','ortholog_identity','inside_TM','within5_TM_boundary','topology_class','chemical_class','transport_score','pLDDT','conservation_bin','confidence_bin','transport_quintile'}
# Feature construction reads only INPUTS 0..3; these are frozen Step3/4/5 data.
source=ast.parse(inspect.getsource(m.features));subscripts=[n for n in ast.walk(source) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='INPUTS'];assert {n.slice.value for n in subscripts}=={0,1,2,3}
assert all(word not in inspect.getsource(m.build_plan) for word in ['rank','score','cluster','cavity','ground_truth'])
plans=json.loads((O/'sampling_pools.json').read_text())
for p in plans['plans']:
 assert p['sites']==[x-1 for x in bench[m.BM[p['benchmark']]]]
 assert m.build_plan(features,p['sites'],p['null'])=={k:v for k,v in p.items() if k!='benchmark'}
 assert m.feasible(p['pools'])
results=m.read('comparison/matched_null/matched_null_permutation_results.tsv');rankstats=m.read('comparison/matched_null/rank_based_enrichment.tsv');assert len(results)==90 and len(rankstats)==72
for x in results+rankstats:
 n=int(x['permutations']);k=int(x['exceedances']);assert n==1000000
 assert float(x['empirical_p'])==(k+1)/(n+1) and float(x['empirical_p'])>0
 lo,hi=m.ci(k,n);assert abs(float(x['mc95_lower'])-lo)<1e-14 and abs(float(x['mc95_upper'])-hi)<1e-14
 assert float(x['holm_p'])>=float(x['empirical_p'])
for p in (O).glob('*.py'):ast.parse(p.read_text(),filename=str(p))
# Independent analytic cross-check: exact strata here are identical or disjoint.
panel=m.read('results/tables/SLC30A10_final_blind_mutation_panel.tsv');cut={f'Top {k}':{p-1 for p,r in stored.items() if r!='NA' and int(r)<=k} for k in [5,10,20]}
cut['Tier 1']={int(x['residue_position'])-1 for x in panel if x['tier']=='Tier 1'};cut['Tier 1 + Tier 2']={int(x['residue_position'])-1 for x in panel if x['tier'] in ['Tier 1','Tier 2']}
assert sorted(p+1 for p in cut['Top 20'])==sorted(json.loads((R/'comparison/comparison_summary.json').read_text())['step6_top20'])
checks=[];support=[]
for plan in plans['plans']:
 groups={}
 for pool in plan['pools']:groups[tuple(pool)]=groups.get(tuple(pool),0)+1
 support.append(dict(benchmark=plan['benchmark'],null_model=plan['null'],distinct_possible_unordered_sets=math.prod(math.comb(len(pool),count) for pool,count in groups.items()),singleton_slots=plan['singleton_slots'],forced_target_slots=';'.join(features[p]['aa']+str(p+1) for p,pool in zip(plan['sites'],plan['pools']) if len(pool)==1 and p in pool),fallback_radius=plan['radius']))
 keys=list(groups);assert all(not(set(a)&set(b)) for i,a in enumerate(keys) for b in keys[i+1:]),'Analytic validator requires disjoint distinct strata'
 for label,chosen in cut.items():
  pmf=np.array([1.])
  for pool,count in groups.items():pmf=np.convolve(pmf,hypergeom.pmf(np.arange(count+1),len(pool),len(set(pool)&chosen),count))
  row=next(x for x in results if x['benchmark']==plan['benchmark'] and int(x['null_model'])==plan['null'] and x['cutoff']==label);obs=len(set(plan['sites'])&chosen);assert obs==int(row['observed_recovery'])
  p=float(pmf[obs:].sum());expect=float(pmf@np.arange(len(pmf)));var=float(pmf@(np.arange(len(pmf))-expect)**2);emp=float(row['exceedances'])/1000000
  assert abs(emp-p)<=8*np.sqrt(p*(1-p)/1000000)+5/1000000
  assert abs(float(row['null_expected'])-expect)<=8*np.sqrt(var/1000000)+1e-8
  checks.append(dict(benchmark=plan['benchmark'],null_model=plan['null'],cutoff=label,exact_expected=expect,exact_tail_probability=p,monte_carlo_raw_frequency=emp,within_8_MC_standard_errors_plus_discrete_tolerance=True))
m.write('exact_recovery_crosscheck.tsv',checks)
m.write('support_summary.tsv',support)
for x in m.read('comparison/matched_null/null_sampling_diagnostics.tsv'):
 assert int(x['effective_permutations'])==1000000 and int(x['proposed_tuples'])-int(x['rejected_tuples'])==1000000
 assert x['duplicate_safeguard']=='reject entire tuple with any duplicate'
# Frozen means are absent when a benchmark includes M44, never a fabricated rank.
site=m.read('comparison/matched_null/residue_matched_percentiles.tsv');assert next(x for x in site if x['residue']=='M44')['frozen_Step6_rank']=='NA'
assert all(x['frozen_Step6_rank']==stored[int(x['position'])] for x in site)
report=dict(validated_utc=datetime.now(timezone.utc).isoformat(),status='PASS',blind_files_byte_identical=True,benchmark_membership_unchanged=True,stored_ranks_unchanged=True,matching_features_whitelisted=True,no_blind_scoring_executed=True,plus_one_all_tests=True,set_tests=90,rank_tests=72,permutations_per_test=1000000,analytic_distribution_crosschecks=90,notes='Feature whitelist and pool rebuild checked independently; source/rank hashes and frozen byte identity verified. No experimental data supplied to any blind scoring function.')
(O/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
