#!/usr/bin/env python3
"""Retrieve only Step 7 sources; existing files are never overwritten."""
import urllib.request,hashlib,json,zipfile
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[2];raw=R/'ground_truth/raw';raw.mkdir(parents=True,exist_ok=True)
assets={'article.xml':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12480533/fullTextXML','supplementary_files.zip':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12480533/supplementaryFiles',**{p+'.cif':f'https://files.rcsb.org/download/{p}.cif' for p in ['9KVX','9KVY','9KVZ']}}
records=[]
for name,url in assets.items():
 p=raw/name;now=None
 if not p.exists():
  with urllib.request.urlopen(url,timeout=60) as r:b=r.read()
  p.write_bytes(b);now=datetime.now(timezone.utc).isoformat()
 records.append(dict(file=name,url=url,new_retrieval_utc=now,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),note='For existing original retrieval dates see archived article/europepmc_supplement/assets provenance JSON files.'))
with zipfile.ZipFile(raw/'supplementary_files.zip') as z:
 for name in z.namelist():
  target='supplement.pdf' if name.endswith('MOESM1_ESM.pdf') else 'source_data.xlsx' if name.endswith('MOESM4_ESM.xlsx') else Path(name).name if name.endswith('_HTML.jpg') else None
  if target and not (raw/target).exists():(raw/target).write_bytes(z.read(name))
(raw/'retrieval_reproducibility_manifest.json').write_text(json.dumps(records,indent=2)+'\n')
