#!/usr/bin/env python3
"""Retrospective analysis of immutable scores; writes only Step 7 artifacts."""
import csv,json,hashlib,sys,platform
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
from scipy.stats import hypergeom,spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[2]; O=R/'comparison'
def read(name):
 with (R/name).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def write(name,rows):
 with (R/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
for manifest in ['results/FINAL_BLIND_PREDICTION.sha256','results/BLIND_PHASE_FILES.sha256']:
 for line in (R/manifest).read_text().splitlines():
  sha,p=line.split(maxsplit=1);assert hashlib.sha256((R/p.strip().lstrip('*')).read_bytes()).hexdigest()==sha,p
seq=''.join(x.strip() for x in (R/'sequences/SLC30A10_human_canonical.fasta').read_text().splitlines() if not x.startswith('>'));assert len(seq)==485
specs=[('Step3','SLC30A10_sequence_specificity.tsv','human_residue_number','specificity_score'),('Step4','SLC30A10_topology_transport_candidates.tsv','human_residue_number','transport_score'),('Step5','SLC30A10_structure_transport_candidates.tsv','residue_number','step5_score'),('Step6','SLC30A10_mutation_prioritization.tsv','residue_position','mutation_priority_score')]
ranks={}; by={}; orders={}
for step,file,pfield,sfield in specs:
 rows=read('results/tables/'+file);rows=sorted(rows,key=lambda x:(-float(x[sfield]),int(x[pfield])))
 d={}
 for x in rows:d.setdefault(int(x[pfield]),x)
 by[step]=d;orders[step]=list(d);ranks[step]={p:i+1 for i,p in enumerate(d)}
panel=read('results/tables/SLC30A10_final_blind_mutation_panel.tsv'); pm={}
for x in panel:pm.setdefault(int(x['residue_position']),[]).append(x)
tiers={t:{int(x['residue_position']) for x in panel if x['tier']==t} for t in ['Tier 1','Tier 2','Tier 3']}
B={'direct_coordination':{40,127,248,252},'transport_essential':{40,47,127,248,252},'individually_transport_sensitive':{25,39,40,44,47,93,127,244,248,252,291}}
gt=read('ground_truth/SLC30A10_experimental_residues.tsv')
for x in gt:
 if x['position'].isdigit() and len(x['residue'])<=5:assert seq[int(x['position'])-1]==x['residue'][0],x
assays={x['mutation_tested']:x for x in gt if x['experimental_category']=='2_transport_function' and x['variant_scope']=='single'}
out=[]
for x in gt:
 if not x['position'].isdigit():continue
 p=int(x['position']); muts=pm.get(p,[]); pred='/'.join(z['mutation'] for z in muts)
 status='experimentally untested'
 if x['experimental_category']=='2_transport_function':
  status=('experimentally negative' if x['transport_effect']=='unchanged' else 'confirmed hit' if muts else 'confirmed miss')
 elif x['experimental_category']=='1_direct_Mn_coordination':status='confirmed hit' if muts else 'confirmed miss'
 out.append(dict(residue=seq[p-1]+str(p),experimental_category=x['experimental_category'],frozen_blind_tier=muts[0]['tier'] if muts else 'none',**{s+'_rank':ranks[s].get(p,'NA') for s in ranks},included_final_panel=bool(muts),predicted_mutation=pred,experimental_mutation=x['mutation_tested'],experimental_effect=x['transport_effect'],hit_miss_classification=status,classification_scope='residue recovery; exact mutation agreement is in panel_experimental_status.tsv',source_location=x['source_location']))
write('comparison/blind_vs_experiment_residues.tsv',out)
pr=[]
for x in panel:
 a=assays.get(x['mutation']);status='experimentally untested' if a is None else 'experimentally negative' if a['transport_effect']=='unchanged' else 'confirmed hit'
 pr.append(dict(residue=x['residue'],mutation=x['mutation'],tier=x['tier'],frozen_predicted_effect=x['predicted_qualitative_effect'],experimental_effect=a['transport_effect'] if a else 'not tested',classification=status,source=a['source_location'] if a else 'no exact-substitution assay in target paper'))
write('comparison/panel_experimental_status.tsv',pr)
metrics=[]
def metric(label,chosen,step,bench,positive):
 h=chosen&positive; finite=[ranks[step][p] for p in positive if p in ranks[step]]
 return dict(prediction_set=label,ranking=step,benchmark=bench,set_size=len(chosen),benchmark_size=len(positive),hits=len(h),hit_residues=';'.join(seq[p-1]+str(p) for p in sorted(h)),recall=len(h)/len(positive),precision_known_positive_fraction=len(h)/len(chosen),enrichment=(len(h)/len(chosen))/(len(positive)/485),mean_rank=float(np.mean(finite)),median_rank=float(np.median(finite)),best_rank=min(finite),worst_finite_rank=max(finite),unranked_count=len(positive)-len(finite))
for step in ranks:
 for k in [5,10,20]:
  for b,pos in B.items():metrics.append(metric('Top '+str(k),set(orders[step][:k]),step,b,pos))
for label,ch in [('Tier 1',tiers['Tier 1']),('Tier 1 + Tier 2',tiers['Tier 1']|tiers['Tier 2'])]:
 for b,pos in B.items():metrics.append(metric(label,ch,'Step6',b,pos))
write('comparison/performance_metrics.tsv',metrics)
rng=np.random.default_rng(20260913); n=100000;counts={(b,k):0 for b in B for k in [5,10,20]}; observed={(b,k):len(set(orders['Step6'][:k])&pos) for b,pos in B.items() for k in [5,10,20]}
# Actual uniformly sampled residue sets, not a parametric replacement of the requested permutations.
for _ in range(n):
 sample=rng.choice(485,20,replace=False)+1
 for k in [5,10,20]:
  s=set(sample[:k])
  for b,pos in B.items():counts[b,k]+=len(s&pos)>=observed[b,k]
perms=[dict(benchmark=b,top_k=k,observed_hits=observed[b,k],permutations=n,seed=20260913,exceedances=counts[b,k],monte_carlo_p=(counts[b,k]+1)/(n+1),exact_hypergeometric_p=float(hypergeom.sf(observed[b,k]-1,485,len(B[b]),k))) for b,k in counts]
write('comparison/permutation_enrichment.tsv',perms)
abl=read('results/tables/SLC30A10_mutation_evidence_dependencies.tsv'); ar=[];aborders={}
for name in sorted({x['ablation'] for x in abl}):
 xs=[x for x in abl if x['ablation']==name];xs.sort(key=lambda x:(-float(x['ablated_residue_priority']),int(x['residue_position']))); order=[int(x['residue_position']) for x in xs];aborders[name]=order;rank={p:i+1 for i,p in enumerate(order)}
 for b,pos in B.items():
  for k in [5,10,20]:
   base=len(set(orders['Step6'][:k])&pos);new=len(set(order[:k])&pos)
   ar.append(dict(ablation=name,benchmark=b,top_k=k,primary_hits=base,ablated_hits=new,change=new-base,interpretation='improved' if new>base else 'worsened' if new<base else 'unchanged',spearman_all=float(spearmanr([ranks['Step6'][p] for p in order],[rank[p] for p in order]).statistic),experimental_residue_ranks=';'.join(f'{seq[p-1]}{p}:{rank.get(p,"NA")}' for p in sorted(pos))))
write('comparison/ablation_performance.tsv',ar)
diag=[]
important=set().union(*B.values())|set(pm)
for p in sorted(important):
 s3=by['Step3'][p];s4=by['Step4'][p];s5=by['Step5'][p];s6=by['Step6'].get(p,{})
 first=next((s for s in ranks if ranks[s].get(p,999)<=20),'never top20')
 status=';'.join(x['classification'] for x in pr if x['residue']==seq[p-1]+str(p)) or ('confirmed miss (final panel)' if p in B['individually_transport_sensitive'] else 'experimentally untested')
 diag.append(dict(residue=seq[p-1]+str(p),**{s+'_rank':ranks[s].get(p,'NA') for s in ranks},first_top20_step=first,ortholog_conservation=s3['ortholog_identity'],specificity_percentile=s3['specificity_percentile'],topology_assignment=s4['assignment'],step4_score=s4['transport_score'],step5_score=s5['step5_score'],cluster=s5['cluster_membership'],cavity=s5['cavity_membership'],cross_helix_neighbors=s5['cross_helix_polar_neighbors6'],pLDDT=s5['pLDDT'],panel_status=status,diagnostic='Structural cluster/cavity and chemistry promoted this residue' if ranks['Step5'].get(p,999)<ranks['Step4'].get(p,999) else 'Topology/chemistry or earlier evidence; inspect frozen ablation shifts for dependence'))
write('comparison/residue_evidence_diagnostics.tsv',diag)
# Fully enumerate frozen ranks so all retrospective ordinal choices are inspectable.
write('comparison/frozen_residue_ranks.tsv',[dict(position=p,residue=seq[p-1]+str(p),**{s+'_rank':ranks[s].get(p,'NA') for s in ranks}) for p in range(1,486)])
plt.rcParams.update({'font.size':10,'figure.dpi':150})
fig,ax=plt.subplots(figsize=(11,5))
for label,pos,color,marker in [('Direct coordinators',B['direct_coordination'],'#d55e00','*'),('Other individually impaired',B['individually_transport_sensitive']-B['direct_coordination']-{244},'#0072b2','o'),('H244: A unchanged; N/D reduced',{244},'#cc79a7','D'),('Panel sites untested in this paper',set(pm)-B['individually_transport_sensitive'],'#777777','x')]:
 ps=sorted(pos);ax.scatter(ps,[ranks['Step6'].get(p,np.nan) for p in ps],label=label,c=color,marker=marker,s=80)
 for p in ps:
  if p in ranks['Step6']:ax.annotate(seq[p-1]+str(p),(p,ranks['Step6'][p]),xytext=(3,4),textcoords='offset points',fontsize=8)
ax.axhline(20,color='grey',ls=':',lw=1);ax.set(xlabel='Human residue number',ylabel='Frozen Step 6 distinct-residue rank',title='Blind mutation-priority ranks versus experimental evidence');ax.invert_yaxis();ax.legend(fontsize=8,loc='upper center',bbox_to_anchor=(.5,-.17),ncol=2);ax.text(.02,.05,'M44: unranked in Step 6',transform=ax.transAxes,ha='left',fontsize=8);fig.tight_layout();fig.savefig(R/'figures/blind_vs_experimental_residue_ranks.png');plt.close(fig)
ps=sorted(B['individually_transport_sensitive']); mat=np.array([[ranks[s].get(p,np.nan) for s in ranks] for p in ps]);fig,ax=plt.subplots(figsize=(8,6));im=ax.imshow(mat,aspect='auto',cmap='viridis_r',vmin=1,vmax=485)
for i,p in enumerate(ps):
 for j,s in enumerate(ranks):ax.text(j,i,str(ranks[s].get(p,'NA')),ha='center',va='center',color='white' if mat[i,j]>280 else 'black',fontsize=9)
ax.set_xticks(range(4),list(ranks));ax.set_yticks(range(len(ps)),[seq[p-1]+str(p)+(' *' if p in B['direct_coordination'] else '') for p in ps]);ax.set_title('Frozen ranks by evidence step\n* direct Mn coordinator; H244 effect is substitution-dependent');fig.colorbar(im,ax=ax,label='Ordinal rank (different eligible universes)');fig.tight_layout();fig.savefig(R/'figures/evidence_layer_recovery.png');plt.close(fig)
summary=dict(tiers={k:sorted(v) for k,v in tiers.items()},benchmarks={k:sorted(v) for k,v in B.items()},step6_top20=orders['Step6'][:20],panel_classification_counts={s:sum(x['classification']==s for x in pr) for s in ['confirmed hit','experimentally negative','experimentally untested']},coordinator_ranks={str(p):{s:ranks[s].get(p) for s in ranks} for p in sorted(B['direct_coordination'])},versions=dict(python=sys.version,numpy=np.__version__,platform=platform.platform()),completed_utc=datetime.now(timezone.utc).isoformat())
(O/'comparison_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
