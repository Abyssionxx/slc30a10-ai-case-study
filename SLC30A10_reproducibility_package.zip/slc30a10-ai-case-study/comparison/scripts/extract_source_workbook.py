#!/usr/bin/env python3
"""Preserve cell-level source data for mutation assays without Excel dependencies."""
import zipfile,xml.etree.ElementTree as E,csv
from pathlib import Path
R=Path(__file__).resolve().parents[2];n={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(R/'ground_truth/raw/source_data.xlsx') as z:
 ss=[''.join(x.itertext()) for x in E.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',n)]
 sheets=E.fromstring(z.read('xl/workbook.xml')).find('s:sheets',n)
 out=[]
 for i,s in enumerate(sheets,1):
  for c in E.fromstring(z.read(f'xl/worksheets/sheet{i}.xml')).findall('.//s:c',n):
   v=c.find('s:v',n)
   if v is None:continue
   value=ss[int(v.text)] if c.get('t')=='s' else v.text
   out.append(dict(sheet=s.get('name'),cell=c.get('r'),value=value))
with (R/'ground_truth/source_workbook_cells.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(out)
print(len(out),'source cells archived')
