#!/usr/bin/env python3
"""Read-only validation of blind integrity and Step 7 internal consistency."""
import csv,hashlib,json,ast
from pathlib import Path
R=Path(__file__).resolve().parents[2]
def read(p):
 with (R/p).open() as f:return list(csv.DictReader(f,delimiter='\t'))
counts={}
for name in ['results/FINAL_BLIND_PREDICTION.sha256','results/BLIND_PHASE_FILES.sha256']:
 lines=(R/name).read_text().splitlines();counts[name]=len(lines)
 for line in lines:
  sha,p=line.split(maxsplit=1);p=p.strip().lstrip('*');assert hashlib.sha256((R/p).read_bytes()).hexdigest()==sha,p
for p in (R/'comparison/scripts').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
ranks=read('comparison/frozen_residue_ranks.tsv');assert len(ranks)==485
assert len({x['position'] for x in ranks})==485
for s,n in [('Step3',485),('Step4',485),('Step5',485),('Step6',215)]:assert sorted(int(x[s+'_rank']) for x in ranks if x[s+'_rank']!='NA')==list(range(1,n+1))
panel=read('comparison/panel_experimental_status.tsv');assert len(panel)==16
assert len({x['mutation'] for x in panel})==16
assert [x['mutation'] for x in panel if x['classification']=='experimentally negative']==['H244A']
assert sum(x['classification']=='confirmed hit' for x in panel)==6
assert sum(x['classification']=='experimentally untested' for x in panel)==9
for x in read('comparison/performance_metrics.tsv'):
 assert 0<=float(x['recall'])<=1 and 0<=float(x['precision_known_positive_fraction'])<=1
 assert int(x['hits'])<=min(int(x['set_size']),int(x['benchmark_size']))
for x in read('comparison/permutation_enrichment.tsv'):assert int(x['permutations'])>=100000 and 0<float(x['monte_carlo_p'])<=1
struct=read('comparison/structural_alignment_metrics.tsv');assert len(struct)==6 and all(x['sequence_mismatches']=='0' for x in struct)
gt=read('ground_truth/SLC30A10_experimental_residues.tsv');assert {x['residue'] for x in gt if x['experimental_category']=='1_direct_Mn_coordination'}=={'D40','N127','D248','S252'}
assert len({x['experimental_category'] for x in gt})==5
assert len(read('comparison/predicted_vs_experimental_mechanism.tsv'))==15
for p in ['figures/blind_vs_experimental_residue_ranks.png','figures/blind_prediction_structure_vs_experiment.png','figures/evidence_layer_recovery.png']:
 assert (R/p).read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
print(json.dumps(dict(status='PASS',blind_manifests_verified=counts,experimental_evidence_records=len(gt),mutation_panel_records=len(panel),experimental_protein_chains=len(struct)),indent=2))
