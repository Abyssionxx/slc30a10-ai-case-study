#!/usr/bin/env python3
"""Unweighted, sequence-verified comparisons; does not modify predicted models."""
import csv,json,itertools,sys
from pathlib import Path
import numpy as np
from Bio.PDB import MMCIFParser,PDBParser
from Bio.SeqUtils import seq1
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[2];O=R/'comparison'
seq=''.join(x for x in (R/'sequences/SLC30A10_human_canonical.fasta').read_text().splitlines() if not x.startswith('>'))
ranges=[(12,28),(44,61),(86,105),(121,141),(245,265),(279,299)];tm={p for a,b in ranges for p in range(a,b+1)};site=[40,127,248,252]
def residues(chain):
 d={}
 for r in chain:
  if r.id[0]==' ' and 'CA' in r:
   p=r.id[1];assert 1<=p<=485 and seq1(r.resname)==seq[p-1],(chain.id,p,r.resname,seq[p-1]);assert p not in d;d[p]=r
 return d
def coords(d,ps,atom='CA'):return np.array([d[p][atom].coord for p in ps],dtype=float)
def fit(x,y):
 a=x.mean(0);b=y.mean(0);u,_,vt=np.linalg.svd((x-a).T@(y-b));v=u@np.diag([1,1,np.linalg.det(u@vt)])@vt;t=b-a@v
 return v,t,float(np.sqrt(np.mean(np.sum((x@v+t-y)**2,axis=1))))
def write(name,rows):
 with (O/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
af=residues(next(PDBParser(QUIET=True).get_structure('AF',R/'structures/predicted/AF-Q6XR72-F1-model_v6.pdb').get_chains()));assert len(af)==485
models={};metals={}
for code in ['9KVX','9KVY','9KVZ']:
 model=MMCIFParser(QUIET=True).get_structure(code,R/f'ground_truth/raw/{code}.cif')[0]
 ions=[a.coord for r in model.get_residues() if r.resname.strip()=='MN' for a in r]
 for ch in model:
  d=residues(ch)
  if not d:continue
  key=code+'_'+ch.id;models[key]=d
  cen=coords(d,site).mean(0);near=min(ions,key=lambda q:np.linalg.norm(q-cen)) if ions else None
  metals[key]=near if near is not None and np.linalg.norm(near-cen)<10 else None
metrics=[];geometry=[];ligand=[];transforms={};states={}
donors={40:['OD1','OD2'],127:['OD1'],248:['OD1','OD2','O'],252:['OG']}
for key,d in models.items():
 state=('IF-Mn' if metals[key] is not None else 'OF' if key.startswith('9KVY') else 'apo-IF');states[key]=state
 ps=sorted(set(d)&set(af));ts=sorted(set(ps)&tm);rot,shift,rms=fit(coords(af,ts),coords(d,ts));transforms[key]=(rot,shift)
 _,_,globalr=fit(coords(af,ps),coords(d,ps));local=float(np.sqrt(np.mean(np.sum((coords(af,site)@rot+shift-coords(d,site))**2,axis=1))));_,_,localfit=fit(coords(af,site),coords(d,site))
 metrics.append(dict(model_chain=key,state=state,resolved_residues=len(d),coverage_fraction=len(d)/485,missing_residues=';'.join(str(p) for p in range(1,486) if p not in d),sequence_mismatches=0,shared_CA_count=len(ps),shared_CA_RMSD_A=globalr,TM_CA_count=len(ts),TM_CA_RMSD_A=rms,site_CA_RMSD_after_TM_fit_A=local,site_only_CA_RMSD_A=localfit))
for key,d in [('AlphaFold',af)]+list(models.items()):
 for a,b in itertools.combinations(site,2):
  rep=lambda p:d[p]['CB' if 'CB' in d[p] else 'CA'].coord
  da=np.array([d[a][n].coord for n in donors[a]]);db=np.array([d[b][n].coord for n in donors[b]])
  geometry.append(dict(model_chain=key,state=states.get(key,'sequence-predicted'),residue1=seq[a-1]+str(a),residue2=seq[b-1]+str(b),CA_distance_A=float(np.linalg.norm(d[a]['CA'].coord-d[b]['CA'].coord)),CB_distance_A=float(np.linalg.norm(rep(a)-rep(b))),minimum_donor_distance_A=float(np.linalg.norm(da[:,None,:]-db[None,:,:],axis=2).min())))
 if key!='AlphaFold' and metals[key] is not None:
  rot,shift=transforms[key];mn=metals[key]
  for p in site:
   for atom in donors[p]:ligand.append(dict(model_chain=key,residue=seq[p-1]+str(p),atom=atom,experimental_Mn_distance_A=float(np.linalg.norm(d[p][atom].coord-mn)),AF_atom_to_experimental_Mn_after_TM_fit_A=float(np.linalg.norm(af[p][atom].coord@rot+shift-mn)),caveat='Aligned reference-ion distance only; no metal predicted or docked into AF'))
write('structural_alignment_metrics.tsv',metrics);write('coordination_distances.tsv',geometry);write('metal_atom_distances.tsv',ligand)
# IF/OF motion using a common TM-domain alignment and fixed frozen helix endpoints.
ifkey=next(k for k in models if k.startswith('9KVY') and states[k]=='IF-Mn');ofkey=next(k for k in models if k.startswith('9KVY') and states[k]=='OF')
i=models[ifkey];o=models[ofkey];ps=sorted(tm&set(i)&set(o));rot,shift,rms=fit(coords(o,ps),coords(i,ps));motion=[]
for h,(a,b) in enumerate(ranges,1):
 ps=[p for p in range(a,b+1) if p in i and p in o];x=coords(i,ps);y=coords(o,ps)@rot+shift;vx=x[-3:].mean(0)-x[:3].mean(0);vy=y[-3:].mean(0)-y[:3].mean(0);ang=np.degrees(np.arccos(np.clip(vx@vy/np.linalg.norm(vx)/np.linalg.norm(vy),-1,1)))
 motion.append(dict(helix=h,frozen_range=f'{a}-{b}',IF_chain=ifkey,OF_chain=ofkey,axis_angle_change_deg=float(ang),centroid_displacement_A=float(np.linalg.norm(x.mean(0)-y.mean(0))),CA_RMSD_after_common_TM_fit_A=float(np.sqrt(np.mean(np.sum((x-y)**2,axis=1)))),definition='end-three-residue centroid axis after unweighted full-TM fit; differs from authors alignment definition'))
write('IF_OF_helix_motion.tsv',motion)
with (R/'results/intermediate/SLC30A10_cavity_voxels.tsv').open() as f:vox=list(csv.DictReader(f,delimiter='\t'))
with (R/'results/tables/SLC30A10_cavities.tsv').open() as f:cav=list(csv.DictReader(f,delimiter='\t'))
cr=[]
for c in cav:
 pts=np.array([[float(v[k]) for k in ['x','y','z']] for v in vox if v['cavity_id']==c['cavity_id']])
 for key,mn in metals.items():
  if mn is None:continue
  ro,tr=transforms[key];distance=float(np.linalg.norm(pts@ro+tr-mn,axis=1).min())
  cr.append(dict(cavity=c['cavity_id'],model_chain=key,frozen_probe_center_volume_A3=c['volume_A3'],frozen_lining_coordinators=';'.join(sorted(set(c['lining_residues'].split(';'))&{'D40','N127','D248','S252'})),nearest_frozen_probe_center_to_experimental_Mn_A=distance,caveat='Comparison after TM superposition; no new cavity detection; nearest grid center is not a cavity boundary distance'))
write('cavity_experimental_overlap.tsv',cr)

# Local neighborhood tests use exactly the frozen CB/CA graph convention.
g=[x for x in geometry if x['model_chain']=='AlphaFold'];maxcb=max(x['CB_distance_A'] for x in g)
# Geometry plotted without changing the AF coordinates or any blind artifact.
fig=plt.figure(figsize=(12,5));tier1=[127,248,280,47,252];tier2=[40,50,85,244]
for idx,key in enumerate([ifkey,ofkey],1):
 ax=fig.add_subplot(1,2,idx,projection='3d');d=models[key];rot,shift=transforms[key]
 for h,(a,b) in enumerate(ranges):
  ps=[p for p in range(a,b+1) if p in d];x=coords(d,ps);y=coords(af,ps)@rot+shift
  ax.plot(*x.T,color='#0072b2',lw=3,label='Experimental TM' if h==0 else None);ax.plot(*y.T,color='#999999',lw=2,alpha=.8,label='Frozen AlphaFold TM' if h==0 else None)
 for label,ps,c,m in [('Frozen Tier 1/2 (AF)',tier1+tier2,'#7b3294','o'),('Experimental Mn coordinators',site,'#d55e00','*')]:
  x=coords(af,ps)@rot+shift if m=='o' else coords(d,ps);ax.scatter(*x.T,c=c,marker=m,s=35 if m=='o' else 110,label=label,depthshade=False)
 if metals[key] is not None:ax.scatter(*metals[key],c='black',s=40,label='Experimental Mn')
 ax.set_title(key+' '+states[key]);ax.set(xlabel='X (Å)',ylabel='Y (Å)',zlabel='Z (Å)');ax.view_init(20,45);ax.set_box_aspect((1,1,1));ax.legend(fontsize=6,loc='upper left')
fig.suptitle('Frozen predicted candidates and experimental sites: independently TM-fitted overlays',fontsize=11);fig.tight_layout();fig.savefig(R/'figures/blind_prediction_structure_vs_experiment.png',dpi=180);plt.close(fig)
(O/'structure_comparison_summary.json').write_text(json.dumps(dict(metrics=metrics,IF_chain=ifkey,OF_chain=ofkey,IF_OF_TM_RMSD_A=rms,AF_max_coordinator_CB_pair_distance_A=maxcb,AF_four_site_all_pairs_within6A=maxcb<=6,notes='Same connected cluster does not imply compact all-pairs coordination geometry. No refinement performed.'),indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k!='missing_residues'} for row in metrics],indent=2))
