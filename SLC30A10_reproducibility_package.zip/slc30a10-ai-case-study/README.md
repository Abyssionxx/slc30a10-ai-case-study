# SLC30A10 reproducibility package

Read [PUBLICATION_NOTES.md](PUBLICATION_NOTES.md) first: this export normalizes private paths and omits selected third-party full-text assets. Verify with `python3 verify_public.py`.

- [Scientific report](reports/SLC30A10_AI4SCIENCE_TECHNICAL_REPORT.md)
- [Pipeline](PIPELINE.md)
- [Reproducibility](REPRODUCIBILITY.md)
- [Environment](ENVIRONMENT.md)
- [Prompts](prompts/README.md)
- [Source attribution](SOURCES.md)

Results are archived, not regenerated. Consult the publication notes before attempting historical hash checks or executing writers.
