# SLC30A10: an AI-assisted blind computational biology case study

## Problem

Human SLC30A10 exports manganese, but identifying transport-important residues requires more than locating conserved amino acids. Conserved positions can support folding, membrane packing, regulation, or substrate interaction. This project asked whether a reproducible combination of evolutionary information, membrane topology, chemistry, and predicted structure could prioritize useful mutations before the target paper was inspected within the workflow.

The intended output was a small, falsifiable experimental panel. It was not a claim to establish a transport mechanism computationally. The work is best described as a retrospective technical case study with an internal blind-prediction phase: the experimental paper already existed when the computational exercise was conducted.

## Blind design

During Steps 1–6, the workflow prohibited access to the target paper, experimental SLC30A10 structures, reported mutations, disease variants, and literature-derived functional residues. Each analysis retained its own scores. Predictions were frozen before disclosure using SHA256 manifests and Git checkpoint `008b7ad7a436fc02898292ec7d0441cf0df6c390`.

These records provide an auditable account of file contents and information flow. They are not tamper-proof security or proof that pretrained models had never encountered related biology. After the freeze, ground truth was curated separately, followed by matched-null benchmarking at commit `5af7e3e53e36e91f47c884da9932e37aa4b44f05`. Neither comparison changed the blind ranks, tiers, or mutation panel.

## Computational workflow

A database query resolved reviewed canonical UniProt entry Q6XR72, providing the frozen 485-residue human sequence. Comparative data comprised 60 candidate SLC30A10 orthologs from 60 vertebrate species and a separate set of ten reviewed human SLC30 paralogs. Sequence QC, accession tracking, raw responses, and checksums supported reproducibility; candidate orthology was not claimed to be fully phylogenetically validated.

Separate MAFFT alignments supported ortholog conservation and family-specificity calculations. Phobius and SCAMPI supplied six-helix topology predictions, agreeing at 455 of 485 positions. Residue chemistry and local polar density then constrained the sequence ranking. An AlphaFold DB model supplied confidence and spatial context for polar-neighbor graphs and a lightweight geometry-based cavity analysis. Finally, transparent mutation rules produced a 16-substitution panel at 14 positions.

The implementation combined a local Mac repository with SSH execution on a Linux server, a project Conda environment, Python scripts, rsync synchronization, and Git provenance. It demonstrates practical Linux/HPC-style workflow management, sequence and structural bioinformatics, permutation statistics, and scientific interpretation. Codex generated substantial coding and analysis support within a human-defined workflow; the project should not be represented as wholly independent manual coding or autonomous scientific discovery.

## Main result

After disclosure, all four experimentally identified Mn2+-coordinating residues were found within the first six positions of the frozen Step 6 mutation ranking: N127 ranked first, D248 second, D40 fifth, and S252 sixth. D47, an additional narrowly defined transport-essential site, ranked fourth and was also in the final panel.

Sequence specificity alone had ranked the four coordinators poorly. Topology and physicochemical constraints produced the first major improvement, while structural context strongly promoted N127, D248, and S252. Tier 1 contained four of the five transport-essential sites; Tier 1 plus Tier 2 contained all five. These are benchmark recovery results, not fully measured panel precision, because several predictions remain untested.

Six proposed substitutions at five sites had supported disruptive effects. H244A was experimentally unchanged despite a predicted strong effect. Nine substitutions had no exact experimental test in the reference, including both proposed negative controls. This distinction between residue-level overlap and exact-mutation outcomes is essential to interpreting success.

## Robustness

Uniform sampling from all 485 residues gave strong enrichment but was a permissive baseline. The matched-null analysis therefore compared the same frozen predictions with residues sharing increasingly plausible biological features. Every Step 8A test used one million accepted permutations and plus-one empirical probabilities, with explicit Holm multiple-testing correction.

Top-10 recovery remained enriched after topology and chemistry matching: approximately 4.90-fold for both the four-site coordinator and five-site essential benchmarks, with adjusted p values of 0.0369 and 0.00550. Conservation and confidence matching weakened corrected cutoff evidence, although mean-rank tests retained support. N127 and D47 remained approximately at the 95th and 94th percentiles within their confidence- and conservation-matched pools.

No diagnostic NULL 5 result survived correction. That null matched pre-structure features without matching geometry, but allowed only nine possible sets for each narrow benchmark. Geometry’s independent contribution was therefore inconclusive, not disproven. The evidence supports recovery beyond simple membrane-location and chemistry priors without establishing that every computational layer added independent information.

## Failures and limitations

The workflow did not identify any triplet or quadruplet satisfying its fixed all-pairs 6 Å coordination criterion. Cavity localization was imperfect, and a single AlphaFold conformation did not reproduce precise metal geometry or transport dynamics. Experimental structure modeling itself used AlphaFold2 initialization, so backbone similarity was not an independent model validation.

H244A remains a genuine mutation-level failure. E25, S39, I291, C93, and M44 were omitted from the final panel for different ranking or selection reasons. D280, S50, N85, S282, E339, and D136 remain experimentally untested predictions for their proposed substitutions, rather than demonstrated errors. No protein language model, metal docking, or molecular dynamics was used. A single retrospective target and a small positive benchmark cannot establish general predictive performance.

## What I learned

The central methodological lesson is to preserve the distinction between a plausible explanation and a frozen prediction. Intermediate scores, unsuccessful geometric tests, and exact mutation outcomes are as important as the final overlap. A high whole-protein enrichment factor becomes more informative only after the background is made biologically realistic.

The project also shows why AI-assisted implementation requires scientific oversight: validating sequence numbering, recognizing correlated evidence, inspecting null-model support, and retaining negative findings materially affect the conclusion. The resulting capability is reproducible hypothesis generation, with transparent uncertainty and an experimental handoff.

## Next prospective test

The next test should apply the frozen workflow, without retuning, to an independent transporter whose experimental answer remains hidden until prediction lock. It should assay the complete proposed panel, including controls, and separate transport effects from expression or trafficking changes. Any improvements motivated by this case should be evaluated as a new workflow rather than retroactively credited to the original blind prediction.

[Read the full technical report](SLC30A10_AI4SCIENCE_TECHNICAL_REPORT.md), including tables, figures, methods, limitations, and artifact provenance.
