# Step 4: blind topology and sequence context

Two independent single-sequence predictors were used. No functional residue annotations, homolog retrieval, experimental comparison, structures, or disorder prediction were used.

## Predictor methods and provenance

- Phobius normal HMM service: https://phobius.sbc.su.se/api ; retrieved 2026-09-13T08:45:39.416969+00:00. Exact engine/build version not exposed. Orientation: i12-32o44-61i82-105o117-145i241-266o278-299i. No signal peptide predicted. Raw JSON contains a posterior SVG; numerical confidence not supplied/extracted.
- SCAMPI2 SCAMPI-single: https://scampi.bioinfo.se/pred/help/ ; retrieved 2026-09-13T08:46:19.098735+00:00. Exact service build not exposed. Orientation states I/O/M preserved in the consensus TSV. No numerical confidence supplied. Forced new single-sequence job; no MSA mode.
- Both predictors place N and C termini inside. These are predictions, not measured orientations.

```json
{
  "phobius_ranges": [
    [
      12,
      32
    ],
    [
      44,
      61
    ],
    [
      82,
      105
    ],
    [
      117,
      145
    ],
    [
      241,
      266
    ],
    [
      278,
      299
    ]
  ],
  "scampi_ranges": [
    [
      8,
      28
    ],
    [
      42,
      62
    ],
    [
      86,
      106
    ],
    [
      121,
      141
    ],
    [
      245,
      265
    ],
    [
      279,
      299
    ]
  ],
  "strict_ranges": [
    [
      12,
      28
    ],
    [
      44,
      61
    ],
    [
      86,
      105
    ],
    [
      121,
      141
    ],
    [
      245,
      265
    ],
    [
      279,
      299
    ]
  ],
  "union_ranges": [
    [
      8,
      32
    ],
    [
      42,
      62
    ],
    [
      82,
      106
    ],
    [
      117,
      145
    ],
    [
      241,
      266
    ],
    [
      278,
      299
    ]
  ],
  "TM_disagreement_positions": [
    8,
    9,
    10,
    11,
    29,
    30,
    31,
    32,
    42,
    43,
    62,
    82,
    83,
    84,
    85,
    106,
    117,
    118,
    119,
    120,
    142,
    143,
    144,
    145,
    241,
    242,
    243,
    244,
    266,
    278
  ],
  "agreement_fraction": 0.9381443298969072,
  "strict_union_spearman": 0.9701189063534671,
  "top20_shared": 13,
  "strict_only_top20": [
    18,
    28,
    50,
    93,
    95,
    135,
    277
  ],
  "union_only_top20": [
    8,
    9,
    10,
    30,
    43,
    144,
    244
  ],
  "highly_sensitive_positions": [
    6,
    8,
    9,
    10,
    18,
    28,
    30,
    32,
    34,
    35,
    36,
    37,
    38,
    42,
    43,
    50,
    67,
    77,
    79,
    80,
    93,
    95,
    113,
    115,
    135,
    142,
    144,
    145,
    147,
    148,
    149,
    150,
    236,
    237,
    238,
    239,
    241,
    242,
    243,
    244,
    271,
    277
  ],
  "step3_top20_shared": [
    136,
    277,
    282,
    293
  ],
  "top20": [
    "D136",
    "D280",
    "S282",
    "E99",
    "S46",
    "E25",
    "E108",
    "D248",
    "D47",
    "S293",
    "C52",
    "T284",
    "Q135",
    "S50",
    "C277",
    "S28",
    "T18",
    "T95",
    "Y278",
    "C93"
  ],
  "sequence_sha256": "6a297b6de2a94fb567e5eb450032cd90807705ab8eef5fc0727136b15a9c9448",
  "software": {
    "numpy": "2.4.6",
    "matplotlib": "3.11.1"
  }
}
```

## Fixed scoring formulas and categories

# Step 4 methods fixed before scoring

Predictors: Phobius normal single-sequence HMM prediction and SCAMPI2 SCAMPI-single (no MSA/homolog search), submitted only the frozen sequence with neutral header. Independent algorithms, not independent proof of correctness. Use returned boundaries without manual editing. Primary consensus TM is the strict intersection of their TM masks; union used for sensitivity. A two-predictor tie is disagreement, not confident non-TM. Helix numbers are contiguous TM runs in the selected mask, numbered N to C. Boundary uncertainty is predictor disagreement or within 5 residues of any predicted start/end. No per-residue probability is invented where not returned.

Physicochemical classes: acidic DE; basic KRH; polar uncharged STNQC; aromatic FWY; aliphatic/hydrophobic AVILM; special GP. Charge: DE negative, KR positive, H titratable, all others neutral nominally. Polar/charged set DEKRHSTNQCY includes Y even though its primary class is aromatic. Kyte-Doolittle hydropathy (1982), verified against https://web.expasy.org/protscale/pscale/Hphob.Doolittle.html. Sliding mean uses 19 centered residues, clipped at sequence termini. Sequence context is +/-5, clipped. Density is fraction in the polar/charged set in +/-4, including the central residue, with clipped denominator.

Long non-TM region: contiguous non-TM run of >=40 residues in the selected mask; terminal status separately recorded. This is a length proxy, NOT a disorder prediction. A boundary residue is within distance <=5 of a TM start/end, either inside or outside.

Categories are nonexclusive flags: A TM polar/charged; B TM hydrophobic (AVILMFW); C within 5 of a boundary; D non-TM polar/charged; E long non-TM. Add 'other/special' when none apply so GP and short nonpolar loops are not falsely called hydrophobic. All original Step 3 scores and percentiles are copied, never replaced.

Secondary transport score T = Iorth * (0.5+0.5*S) * L * K * (0.5+0.5*D) * P.
Iorth is Step 3 non-gap ortholog identity; S is original specificity score; D is local polar/charged density. Location L=1 inside selected TM mask, 0.6 outside but within 5 of a boundary, 0.1 otherwise. Chemistry K=1 for DEH; 0.6 for NQSTCY; 0.5 for KR; 0.05 for all other residues. These are explicitly heuristic chemical priors, not measured coordination probabilities. Long-region multiplier P=0.25 in a >=40-residue non-TM run, otherwise 1. No fitted weights or residue-specific adjustments. Low conservation, chemically implausible isolated residues and long non-TM regions are penalized. Do not call long regions disordered without a disorder predictor.

Percentiles use average ascending ranks: 100*(rank-1)/(485-1). Top 20 sorted descending T, with residue number tie-break. Recompute location, boundaries and long-region status under union mask; chemistry and Step 3 scores fixed. Compare strict/union Spearman, shared top20 count, absolute percentile shifts. Highly sensitive = >10 percentile-point shift, or enters/leaves top20. Report all such positions and highlight top20 changes. Compare primary top20 with original Step3 top20, without experimental interpretation.


## Primary top 20 (strict consensus)

| Residue | Assignment | Score | Ortholog identity | Step3 percentile | Chemical rationale |
|---|---|---:|---:|---:|---|
| D136 | TM4 | 0.60148 | 0.9333 | 98.347 | acidic/His chemical prior; TM4; local polar/charged fraction 0.333 |
| D280 | TM6 | 0.41667 | 1.0000 | 3.926 | acidic/His chemical prior; TM6; local polar/charged fraction 0.667 |
| S282 | TM6 | 0.41191 | 0.9667 | 98.864 | polar donor/acceptor chemical prior; TM6; local polar/charged fraction 0.444 |
| E99 | TM3 | 0.40016 | 0.8667 | 54.855 | acidic/His chemical prior; TM3; local polar/charged fraction 0.333 |
| S46 | TM2 | 0.37600 | 0.9833 | 86.157 | polar donor/acceptor chemical prior; TM2; local polar/charged fraction 0.444 |
| E25 | TM1 | 0.37346 | 1.0000 | 43.905 | acidic/His chemical prior; TM1; local polar/charged fraction 0.222 |
| E108 | boundary | 0.36692 | 0.8500 | 93.285 | acidic/His chemical prior; boundary; local polar/charged fraction 0.556 |
| D248 | TM5 | 0.33333 | 1.0000 | 3.926 | acidic/His chemical prior; TM5; local polar/charged fraction 0.333 |
| D47 | TM2 | 0.32500 | 0.9000 | 3.926 | acidic/His chemical prior; TM2; local polar/charged fraction 0.444 |
| S293 | TM6 | 0.32211 | 0.9167 | 98.037 | polar donor/acceptor chemical prior; TM6; local polar/charged fraction 0.222 |
| C52 | TM2 | 0.30686 | 0.8667 | 87.397 | polar donor/acceptor chemical prior; TM2; local polar/charged fraction 0.333 |
| T284 | TM6 | 0.30410 | 0.9833 | 69.008 | polar donor/acceptor chemical prior; TM6; local polar/charged fraction 0.333 |
| Q135 | TM4 | 0.29672 | 0.8167 | 91.839 | polar donor/acceptor chemical prior; TM4; local polar/charged fraction 0.333 |
| S50 | TM2 | 0.29250 | 0.9000 | 64.463 | polar donor/acceptor chemical prior; TM2; local polar/charged fraction 0.444 |
| C277 | boundary | 0.28333 | 1.0000 | 96.694 | polar donor/acceptor chemical prior; boundary; local polar/charged fraction 0.667 |
| S28 | TM1 | 0.27939 | 0.7833 | 89.256 | polar donor/acceptor chemical prior; TM1; local polar/charged fraction 0.333 |
| T18 | TM1 | 0.27726 | 0.9167 | 91.219 | polar donor/acceptor chemical prior; TM1; local polar/charged fraction 0.111 |
| T95 | TM3 | 0.27089 | 0.7667 | 86.777 | polar donor/acceptor chemical prior; TM3; local polar/charged fraction 0.333 |
| Y278 | boundary | 0.26667 | 1.0000 | 88.430 | polar donor/acceptor chemical prior; boundary; local polar/charged fraction 0.667 |
| C93 | TM3 | 0.26575 | 0.7833 | 81.715 | polar donor/acceptor chemical prior; TM3; local polar/charged fraction 0.333 |

## Boundary sensitivity

Strict/union Spearman: 0.970119; shared top20: 13/20. Highly sensitive means >10 percentile points or any top20 membership change. Full per-residue results are in SLC30A10_topology_boundary_sensitivity.tsv.

| Sensitive residue | Strict percentile | Union percentile | Top20 membership change |
|---|---:|---:|---|
| G6 | 44.835 | 80.165 | False |
| T8 | 95.248 | 99.380 | True |
| C9 | 94.835 | 98.554 | True |
| R10 | 93.182 | 96.488 | True |
| T18 | 96.694 | 94.421 | True |
| S28 | 96.901 | 94.628 | True |
| Y30 | 94.215 | 97.314 | True |
| G32 | 75.000 | 85.537 | False |
| S34 | 76.033 | 88.017 | False |
| I35 | 34.504 | 65.083 | False |
| A36 | 33.884 | 61.364 | False |
| L37 | 38.636 | 69.421 | False |
| L38 | 28.099 | 52.066 | False |
| F42 | 72.211 | 85.124 | False |
| N43 | 95.041 | 98.967 | True |
| S50 | 97.314 | 95.455 | True |
| G67 | 29.442 | 54.752 | False |
| A77 | 34.091 | 62.810 | False |
| V79 | 32.025 | 60.124 | False |
| V80 | 36.157 | 66.736 | False |
| C93 | 96.074 | 93.802 | True |
| T95 | 96.488 | 94.008 | True |
| P113 | 28.719 | 53.719 | False |
| L115 | 35.950 | 66.529 | False |
| Q135 | 97.521 | 95.661 | True |
| A142 | 31.818 | 60.950 | False |
| C144 | 89.463 | 98.347 | True |
| L145 | 15.702 | 32.231 | False |
| G147 | 2.686 | 26.653 | False |
| R148 | 43.182 | 77.479 | False |
| S149 | 26.240 | 41.529 | False |
| R150 | 36.777 | 67.355 | False |
| L236 | 21.488 | 35.124 | False |
| N237 | 58.884 | 86.777 | False |
| I238 | 27.066 | 41.942 | False |
| R239 | 45.661 | 81.405 | False |
| V241 | 43.802 | 81.921 | False |
| L242 | 45.248 | 83.884 | False |
| L243 | 40.702 | 76.240 | False |
| H244 | 89.256 | 97.831 | True |
| D271 | 72.211 | 87.603 | False |
| C277 | 97.107 | 94.835 | True |

## Comparison with Step 3

Original specificity scores and percentiles are unchanged. Shared top20 positions: [136, 277, 282, 293]. Secondary ranking adds chemical and location priors; it is not a replacement for Step 3.

## Limitations

Predictor agreement is not calibrated confidence. TM intersection can shorten helices; the union sensitivity quantifies this choice but does not sample all possible topologies. Sequence chemical groups suggest possible roles only; geometry, protonation, oligomerization and transport function are untested. Long non-TM is a length proxy and must not be read as predicted disorder. Equal sequence weighting and provisional orthology from earlier steps remain limitations. Service model versions are not exposed, so archived outputs define exact reproducibility.

Commands: `python3 -B scripts/fetch_topology_predictions.py` (public services), then `scripts/remote_run.sh "python -B scripts/analyze_residue_context.py"` (remote scoring). No new software installed.
