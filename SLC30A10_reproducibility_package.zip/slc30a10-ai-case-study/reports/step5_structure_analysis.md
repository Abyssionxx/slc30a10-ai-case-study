# Step 5: blind sequence-predicted structural analysis

No experimental SLC30A10 structure, residue annotation, mutation information, literature comparison or docking was used. AlphaFold predictions may have training/template influences; this is not a de novo model trained without historical structural data.

## Source and model QC

Model AF-Q6XR72-F1, version 6; resource describes pipeline as AlphaFold Monomer v2.0 pipeline. PDB: https://alphafold.ebi.ac.uk/files/AF-Q6XR72-F1-model_v6.pdb. Exact retrieval URLs/dates/checksums: data/raw/structure/retrieval_provenance.json. PDB, mmCIF, pLDDT JSON and PAE JSON preserved. No linked substitution annotations or MSA assets retrieved.

```json
{
  "model_id": "AF-Q6XR72-F1",
  "model_version": 6,
  "coverage": 1.0,
  "residues": 485,
  "missing_residues": [],
  "numbering_sequence_exact": true,
  "mean_pLDDT": 67.48080412371135,
  "median_pLDDT": 80.06,
  "below70": 205,
  "TM_helix_confidence": {
    "1": {
      "mean": 87.70588235294117,
      "median": 89.5,
      "min": 77.94,
      "count": 17
    },
    "2": {
      "mean": 85.33666666666666,
      "median": 86.03,
      "min": 81.69,
      "count": 18
    },
    "3": {
      "mean": 91.825,
      "median": 92.185,
      "min": 86.94,
      "count": 20
    },
    "4": {
      "mean": 72.92952380952381,
      "median": 79.44,
      "min": 34.56,
      "count": 21
    },
    "5": {
      "mean": 87.99666666666668,
      "median": 90.31,
      "min": 71.75,
      "count": 21
    },
    "6": {
      "mean": 90.65142857142857,
      "median": 91.94,
      "min": 83.12,
      "count": 21
    }
  },
  "step4_top20_confidence": {
    "T18": 83.0,
    "E25": 93.25,
    "S28": 93.06,
    "S46": 86.62,
    "D47": 82.5,
    "S50": 84.06,
    "C52": 86.12,
    "C93": 91.0,
    "T95": 93.62,
    "E99": 93.06,
    "E108": 84.75,
    "Q135": 67.5,
    "D136": 59.12,
    "D248": 82.56,
    "C277": 86.88,
    "Y278": 91.56,
    "D280": 91.94,
    "S282": 94.06,
    "T284": 93.88,
    "S293": 90.31
  },
  "pLDDT_JSON_match": true
}
```

## Pre-specified algorithms and formula

# Step 5 methods fixed before structural ranks

Input is the sequence-matched AlphaFold DB model AF-Q6XR72-F1 version 6, not experimental coordinates. Frozen Step1 sequence and Step3/4 output hashes verified. Preserve original sequence scores. All coordinates are the model coordinates; no literature orientation.

Residue representative: CB, or CA for glycine. No fallback for missing non-glycine CB: stop QC. Polar/ion-interacting classes fixed as DE (acidic), KR (basic), HNQSTCY (polar/coordination-capable). Exclude self from neighborhood counts. All distance counts use representative atoms, not coordinating heteroatoms; they cannot establish coordination geometry. Count DEKRHNQSTCY within 4,6,8 A; DE within6; HNQSTCY within6. Nearest other-TM distance is minimum representative distance to residues in another core TM helix, excluding the residue's assigned helix. Near-TM: <=5 sequence positions from a boundary. Associate near residues with closest helix by sequence distance, ties to smaller helix number, while reporting core helix=0 for non-TM positions.

Confidence: CA B-factor pLDDT, cross-check official JSON. Primary uses all residues with continuous pLDDT/100 score attenuation. Low-confidence exclusion sensitivity removes residues with pLDDT<70 from graphs, neighbor evidence and candidate scoring. PAE is reported for cluster pairs to qualify relative-placement uncertainty; not a fitted scoring term.

Membrane coordinate frame: PCA axis of CA coordinates within each strict-consensus TM helix; sum axis outer products and take principal eigenvector for unsigned approximate membrane normal. Origin is the mean TM CA position. Sign is arbitrary, not cytosolic direction. The +/-15 A slab around that center is an assumed geometric window, not a measured membrane.

SASA: existing Biopython ShrakeRupley, probe radius1.4 A, 100 sphere points per atom; residue sum in A^2. No lipid environment modeled. Secondary structure: coarse backbone dihedral heuristic, helix if phi[-100,-30] and psi[-80,-5] degrees, extended if phi[-180,-70] and psi[70,180] or [-180,-120], otherwise coil; missing angles=unknown. This is NOT DSSP and does not assign hydrogen-bond patterns.

Graph: nodes polar/ion-interacting residues within core TM or <=5 boundary positions. Edges Euclidean representative distance <=6 A primary, 5 and8 A sensitivity. Connected components qualify if actual core residues represent >=2 TM helices. Near residues may join but cannot alone supply additional represented helices. Connected components need not be compact; report size, mean/max pairwise distance and PAE. Cluster membership is geometry-only.

Cavity fallback (no installed fpocket/P2Rank found): 2 A axis-aligned grid within the convex hull of strict-TM CA atoms and approximate +/-15 A membrane slab. Protein exclusion uses heavy-atom van der Waals radii C1.70,N1.55,O1.52,S1.80 plus1.4 A probe (other elements1.70). For each free grid point, cast 14 fixed rays (+/-Cartesian axes and 8 unit body diagonals), samples every1 A up to10 A. A ray is blocked if a sample intersects inflated protein atoms. Internal/pocket grid points require >=10 blocked rays; retain 6-connected components >=3 voxels (>=24 A^3) with lining residues from >=2 actual strict TM helices. Lining residues have a heavy atom <=4.5 A from a retained voxel center. Volume is grid-point count*8 A^3 of probe-center accessible space, NOT a calibrated fpocket cavity volume. This can identify enclosed voids or buried clefts, can miss narrow/water/ion channels, depends on probe/grid, and may produce zero cavities. Never force a cavity. Preserve cavity voxel coordinates. A monomer model cannot represent missing oligomer interfaces or lipids.

Structure score S5 = Iorth * (0.5+0.5*T4) * L * (0.4+0.2*N+0.2*C+0.2*V) * (pLDDT/100).
Iorth is Step3 non-gap ortholog identity; T4 is original Step4 transport score (unmodified). L=1 core TM,0.6 outside but <=5 boundary,0.1 elsewhere. N=min(number of polar/charged representatives from a different ACTUAL core TM helix within graph threshold /3,1); self and own associated helix excluded. C=1 for qualified internal polar cluster membership,0 otherwise. V=1 for lining a geometry-detected cavity,0 otherwise. Equal fixed evidence increments; no parameter tuning. High-pLDDT is not validation. No chemical factor beyond permitted Step4 score/graph classes is added.

Rank percentiles use mean ranks, 100*(rank-1)/484. Tie-break smaller residue number. Sensitivity: full factorial 3 distances (5/6/8), 3 topology masks (Phobius,SCAMPI,strict), and all vs pLDDT>=70 (18 variants including baseline). Original T4 fixed. Recompute graph/helix associations/location and confidence exclusion; cavities remain baseline geometry, with excluded residues unable to contribute cavity status. This tests ranking/cluster evidence, not alternate model conformations or cavity reruns. Report Spearman, top20 overlap, cluster count, clustered-residue Jaccard and best cluster Jaccard matches against baseline. Excluded positions score0. Flag >10 percentile changes or top20 changes.

Coordination constellations: enumerate all triplets/quadruplets of DEHNQSTCY members in the same primary qualified cluster; >=2 actual core TM helices; all representative pair distances <=6 A. A shared cluster satisfies the same-cluster/cavity criterion; shared cavity membership recorded separately and may be empty. Score = (1-dmax/6)*mean(Iorth)*(0.5+0.5*mean(T4)), geometry/conservation/T4 only. Do not claim metal binding. Report all combinations, max/mean distances and scores; representative atoms cannot show convergent side-chain donor geometry.


## Geometric results

```json
{
  "primary_cluster_count": 2,
  "cavity_count": 5,
  "constellation_count": 0,
  "triplets": 0,
  "quadruplets": 0,
  "top20": [
    "D248",
    "N127",
    "D280",
    "D47",
    "S50",
    "E25",
    "S252",
    "T284",
    "S46",
    "S294",
    "I291",
    "T18",
    "A295",
    "S28",
    "I290",
    "L89",
    "N85",
    "L298",
    "S282",
    "G54"
  ],
  "top10": [
    "D248",
    "N127",
    "D280",
    "D47",
    "S50",
    "E25",
    "S252",
    "T284",
    "S46",
    "S294"
  ],
  "top5": [
    "D248",
    "N127",
    "D280",
    "D47",
    "S50"
  ],
  "membrane_center": [
    2.1008643813557546,
    5.378313582958811,
    -14.304567904290506
  ],
  "membrane_normal_unsigned": [
    -0.8943839355434499,
    0.049342046834594366,
    0.4445702849448919
  ],
  "software": {
    "python": "3.11.16",
    "biopython": "1.88",
    "numpy": "2.4.6",
    "scipy": "1.17.1",
    "matplotlib": "3.11.1"
  }
}
```

### Primary 6 A polar clusters

- strict_6A_all_C1: E25;S28;S39;D40;S41;N43;S46;D47;S50;S84;N85;N127;H244;D248;S252;T284; helices 1;2;4;5;6; mean/max pair distance 12.69/29.24 A; pLDDT 87.6; mean/max PAE 3.37/9.00 A.
- strict_6A_all_C2: T258;D280; helices 5;6; mean/max pair distance 4.94/4.94 A; pLDDT 92.0; mean/max PAE 2.00/2.00 A.

### Cavities
5 grid-defined internal pockets found. This is the specified geometry fallback, not fpocket/P2Rank.
- V1: probe-center volume 48 A^3; lining L11;L15;L51;L55; helices 1;2; mean pLDDT 78.7; Step4 overlap .
- V2: probe-center volume 256 A^3; lining D47;S50;L51;G54;A82;N85;A86;L89;L236;N237;G240;V241;H244;S294;A295;L298; helices 2;3;6; mean pLDDT 76.7; Step4 overlap D47;S50.
- V3: probe-center volume 64 A^3; lining L11;M14;L15;T18;L51;F134;V241;H244;V245; helices 1;2;4;5; mean pLDDT 74.1; Step4 overlap T18.
- V4: probe-center volume 24 A^3; lining M14;L17;T18;V126;N127;G130;F134;D248; helices 1;4;5; mean pLDDT 80.9; Step4 overlap T18;D248.
- V5: probe-center volume 24 A^3; lining L243;G247;I290;I291;S294;A295; helices 5;6; mean pLDDT 82.3; Step4 overlap .

## Top 20 blind structure-aware candidates

First 5 and first 10 rows define top5/top10; ties use residue number.

| Rank | Residue | Core/near helix | S3 | S4 | S5 | Cluster | Cavity | pLDDT | Nearest polar neighbors |
|---:|---|---|---:|---:|---:|---|---|---:|---|
| 1 | D248 | 5/5 | 0.0000 | 0.3333 | 0.4770 | strict_6A_all_C1 | V4 | 82.6 | N127:4.736A;S252:6.492A;N43:6.546A;H244:6.859A;D47:6.960A |
| 2 | N127 | 4/4 | 0.1111 | 0.1852 | 0.4718 | strict_6A_all_C1 | V4 | 85.3 | D248:4.736A;S252:5.315A;T18:8.917A;D40:9.475A;H244:10.505A |
| 3 | D280 | 6/6 | 0.0000 | 0.4167 | 0.4342 | strict_6A_all_C2 |  | 91.9 | T258:4.942A;S34:5.883A;T284:6.490A;C277:7.285A;R103:7.339A |
| 4 | D47 | 2/2 | 0.0000 | 0.3250 | 0.3935 | strict_6A_all_C1 | V2 | 82.5 | S50:4.854A;H244:5.027A;S46:5.109A;N43:6.566A;D248:6.960A |
| 5 | S50 | 2/2 | 0.5000 | 0.2925 | 0.3911 | strict_6A_all_C1 | V2 | 84.1 | N85:4.660A;D47:4.854A;S46:6.241A;H244:6.620A;C52:7.329A |
| 6 | E25 | 1/1 | 0.2222 | 0.3735 | 0.3842 | strict_6A_all_C1 |  | 93.2 | S41:3.765A;S28:5.580A;D40:5.647A;S252:8.685A;S39:9.451A |
| 7 | S252 | 5/5 | 0.2222 | 0.2241 | 0.3685 | strict_6A_all_C1 |  | 90.3 | N127:5.315A;D40:5.893A;D248:6.492A;E25:8.685A;N43:9.674A |
| 8 | T284 | 6/6 | 0.5463 | 0.3041 | 0.3612 | strict_6A_all_C1 |  | 93.9 | S39:5.005A;D280:6.490A;S282:7.213A;R103:7.938A;E99:8.358A |
| 9 | S46 | 2/2 | 0.7648 | 0.3760 | 0.3516 | strict_6A_all_C1 |  | 86.6 | D47:5.109A;N43:5.471A;S50:6.241A;C93:8.086A;N85:8.183A |
| 10 | S294 | 6/6 | 0.4444 | 0.2648 | 0.3171 |  | V2;V5 | 83.6 | S293:5.341A;C93:9.956A;H244:9.960A;R239:10.308A;T90:10.681A |
| 11 | I291 | 6/6 | 0.7648 | 0.0265 | 0.2950 |  | V5 | 87.7 | C93:5.496A;S294:5.723A;N43:7.045A;S293:7.333A;T90:9.062A |
| 12 | T18 | 1/1 | 0.8148 | 0.2773 | 0.2915 |  | V3;V4 | 83.0 | D47:7.490A;D248:7.988A;N127:8.917A;H244:10.130A;E25:10.260A |
| 13 | A295 | 6/6 | 0.8889 | 0.0289 | 0.2900 |  | V2;V5 | 84.6 | S294:5.300A;T90:5.673A;C93:7.137A;S293:7.447A;N85:9.328A |
| 14 | S28 | 1/1 | 0.7833 | 0.2794 | 0.2798 | strict_6A_all_C1 |  | 93.1 | E25:5.580A;Y30:7.379A;S34:7.950A;S41:8.053A;D112:8.210A |
| 15 | I290 | 6/6 | 0.8741 | 0.0282 | 0.2762 |  | V5 | 91.1 | S293:5.813A;S294:6.535A;C93:9.952A;T284:10.851A;N43:11.232A |
| 16 | L89 | 3/3 | 0.5093 | 0.0231 | 0.2735 |  | V2 | 87.5 | S46:5.042A;T90:5.356A;C93:6.094A;N85:6.227A;S50:7.159A |
| 17 | N85 | 0/3 | 0.6444 | 0.1749 | 0.2569 | strict_6A_all_C1 | V2 | 87.0 | S50:4.660A;S84:5.285A;S46:8.183A;T302:8.879A;D47:9.017A |
| 18 | L298 | 6/6 | 0.6667 | 0.0301 | 0.2569 |  | V2 | 83.1 | E301:5.820A;T302:6.294A;K300:7.295A;S294:7.606A;R239:8.513A |
| 19 | S282 | 6/6 | 0.9667 | 0.4119 | 0.2568 |  |  | 94.1 | Y278:5.389A;T284:7.213A;D280:7.441A;T258:9.324A;R103:9.454A |
| 20 | G54 | 2/2 | 0.6667 | 0.0278 | 0.2540 |  | V2 | 82.4 | S56:5.945A;S50:6.634A;C52:6.896A;N85:6.989A;E78:7.661A |

## Candidate ion-coordination constellations

0 total combinations. These are close representative-atom constellations, not evidence that donor atoms coordinate an ion. The first 20 are shown; all are in the TSV.

| Members | Helices | Max distance A | Score | Shared cavity |
|---|---|---:|---:|---|

## Robustness

| Variant | Spearman | Shared top20 | Clusters | Clustered-residue Jaccard | Best cluster Jaccard | >10 percentile shifts |
|---|---:|---:|---:|---:|---|---:|
| strict_5A_all | 0.9987 | 17 | 2 | 0.222 | 0.5625 | 3 |
| strict_5A_pLDDT70 | 0.8801 | 17 | 2 | 0.222 | 0.5625 | 134 |
| strict_6A_all | 1.0000 | 20 | 2 | 1.000 | 1.0 | 0 |
| strict_6A_pLDDT70 | 0.8813 | 20 | 2 | 1.000 | 1.0 | 132 |
| strict_8A_all | 0.9978 | 16 | 1 | 0.439 | 0.21951219512195122 | 1 |
| strict_8A_pLDDT70 | 0.8792 | 16 | 1 | 0.450 | 0.225 | 133 |
| Phobius_5A_all | 0.9816 | 18 | 3 | 0.389 | 0.59375 | 39 |
| Phobius_5A_pLDDT70 | 0.8736 | 18 | 3 | 0.389 | 0.59375 | 160 |
| Phobius_6A_all | 0.9811 | 18 | 2 | 0.947 | 0.8333333333333333 | 32 |
| Phobius_6A_pLDDT70 | 0.8732 | 18 | 2 | 0.947 | 0.8333333333333333 | 156 |
| Phobius_8A_all | 0.9800 | 15 | 1 | 0.383 | 0.19148936170212766 | 28 |
| Phobius_8A_pLDDT70 | 0.8719 | 15 | 1 | 0.400 | 0.2 | 152 |
| SCAMPI_5A_all | 0.9916 | 17 | 2 | 0.222 | 0.5625 | 19 |
| SCAMPI_5A_pLDDT70 | 0.8772 | 17 | 2 | 0.222 | 0.5625 | 145 |
| SCAMPI_6A_all | 0.9929 | 19 | 2 | 1.000 | 1.0 | 16 |
| SCAMPI_6A_pLDDT70 | 0.8784 | 19 | 2 | 1.000 | 1.0 | 142 |
| SCAMPI_8A_all | 0.9881 | 15 | 2 | 0.346 | 0.21428571428571427 | 16 |
| SCAMPI_8A_pLDDT70 | 0.8757 | 15 | 1 | 0.439 | 0.21951219512195122 | 142 |

## Limitations

The single predicted monomer and its low-confidence regions may place loops incorrectly. pLDDT measures local confidence, and PAE qualifies relative positioning. TM constraints provide an approximate unsigned axis, not a validated membrane orientation. SASA is water-probe accessibility, not lipid exposure. Dihedral secondary structure is coarse because DSSP is unavailable. Pocket volumes depend on probe/grid and are not physical ion-accessibility measurements. Connected polar networks can span a large distance; compact constellations use an all-pairs criterion. Heuristic scores are hypotheses and may prioritize nonliganding scaffold residues; original S3/S4 scores remain preserved. No experimental or literature comparison has been made.

Commands: `python3 -B scripts/fetch_predicted_structure.py`; `scripts/remote_run.sh "python -B scripts/find_transmembrane_polar_clusters.py"`. The latter invokes analyze_structure_qc.py. No installations or local AlphaFold run.
