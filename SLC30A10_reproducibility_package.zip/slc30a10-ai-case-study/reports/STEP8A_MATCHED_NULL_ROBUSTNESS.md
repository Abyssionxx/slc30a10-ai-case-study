# Step 8A — matched-null robustness benchmark

## Conclusion

The frozen predictions clearly outperform uniform and simple topology/chemistry backgrounds. Evidence beyond conservation and pLDDT is more selective: some essential-site cutoff tests survive conservation matching, and rank-based tests for coordinators and essential sites survive confidence matching. **No NULL 5 result survives its pre-specified multiple-test correction.** That diagnostic is also severely constrained by singleton strata, so it neither demonstrates a unique geometry contribution nor proves that geometry has no value.

## Integrity and fixed design

Before analysis, git was clean at `2a9cbac6a2a4d0eca963918648fdfddd46ecbeca`. Both blind manifests passed; the immutable checkpoint remains `008b7ad7a436fc02898292ec7d0441cf0df6c390`. Verification and constituent hashes are in `comparison/matched_null/preanalysis_verification.json`. Methods were written before p-values, then hashed into the input and runtime records. No Steps 1–7 artifact, score, rank, tier, mutation panel, or benchmark was changed.

The benchmark definitions are copied unchanged from Step 7: A = D40,N127,D248,S252; B = D40,D47,N127,D248,S252; C = E25,S39,D40,M44,D47,C93,N127,H244,D248,S252,I291. H244 is substitution-dependent: its presence in C does not turn H244A into a successful panel prediction. M44 and I291 are outside the nine-amino-acid chemistry pool, so C tests under NULL 2–4 are retained but explicitly out-of-support. C is not silently reduced to nine sites.

Surrogate benchmark sets are sampled against fixed prediction cutoffs. For NULL 0 this is equivalent to the Step 7 hypergeometric experiment; NULL 1–5 use the same label-randomization orientation. Experimental residues are allowed in control pools, which is necessary for an unconditioned random-label null. Each of 18 benchmark/null combinations supplies 1,000,000 independent accepted draws to all five cutoffs and all four rank summaries: 90 cutoff tests and 72 rank tests. Reuse across cutoffs creates correlated tests, not fewer than one million observations per test.

The sampling-only preflight projected 153.6 seconds; the full computation took 29.9 seconds on one CPU thread. Master seed 2026091308, NumPy 2.4.6, SciPy 1.17.1, Python 3.11.16. No software was installed. An initial cutoff-dictionary indexing error stopped before simulation; its implementation-only correction is documented in `implementation_notes.json`.

## Matching pools and sampling

NULL 0 has 485 candidates; NULL 1 has 178 TM/within-five-boundary candidates; NULL 2 has 49 of those with D,E,H,N,Q,S,T,C,Y chemistry. NULL 3 and 4 retain the 49-residue base and match per-site conservation and then pLDDT. NULL 5 matches exact frozen topology and six-class chemical categories, global conservation quintile, confidence category, and Step 4 score quintile; it does not use any geometry variable.

Global conservation quintile cutpoints: [0.47824858757062155, 0.6833333333333333, 0.85, 0.9666666666666667]. Deciles failed the feature-only minimum-pool rule (at least eleven eligible controls in every decile). Score quintile cutpoints: [0.0005064800117577894, 0.0034076838681600585, 0.009495501150868382, 0.024792455418381355]. Confidence bins: <70, 70–<90, >=90. Tied values stay together, with cutpoint equality assigned to the upper interval. No fallback was required for any benchmark or individual-site stratum.

Each proposal independently draws uniformly from every target slot and is rejected in full if a residue repeats. This avoids order-dependent depletion bias. Distinct pools in this dataset are identical or disjoint, permitting an independent exact convolution of hypergeometric distributions; all 90 recovery distributions passed that cross-check. Candidate lists, stratum sizes, rejected proposals, accepted counts, RNG seeds and draw hashes are preserved. Singleton pools are not weakened after seeing significance.

| benchmark | distinct_possible_unordered_sets | singleton_slots | forced_target_slots |
| --- | --- | --- | --- |
| A | 9 | 2 | D40;D248 |
| B | 9 | 3 | D40;D47;D248 |
| C | 2160 | 4 | S39;D40;D47;D248 |

For A, NULL 5 fixes D40 and D248; for B it additionally fixes D47. Only N127 and S252 have alternatives (three candidates each), yielding just nine distinct unordered sets. Every A/B NULL 5 control is already inside the frozen top 20, so top-20 recovery is guaranteed and p=1. One million valid independent draws estimate this small distribution precisely but do not create one million distinct biological alternatives. C has 2,160 distinct possible sets. These support limitations are central to interpreting NULL 5.

## Top-10 results

| benchmark | null | observed | expected | fold | p | MC95 | Holm |
| --- | --- | --- | --- | --- | --- | --- | --- |
| A | 0 | 4 | 0.082 | 48.60 | 1e-06 | [0, 3.689e-06] | 7.5e-05 |
| A | 1 | 4 | 0.225 | 17.77 | 6e-06 | [1.623e-06, 1.167e-05] | 0.000318 |
| A | 2 | 4 | 0.817 | 4.90 | 0.001014 | [0.0009516, 0.001077] | 0.03686 |
| A | 3 | 4 | 1.523 | 2.63 | 0.01189 | [0.01168, 0.01211] | 0.2297 |
| A | 4 | 4 | 1.616 | 2.48 | 0.01822 | [0.01796, 0.01848] | 0.2438 |
| A | 5 | 4 | 2.667 | 1.50 | 0.1112 | [0.1106, 0.1119] | 1 |
| B | 0 | 5 | 0.103 | 48.41 | 1e-06 | [0, 3.689e-06] | 7.5e-05 |
| B | 1 | 5 | 0.282 | 17.76 | 1e-06 | [0, 3.689e-06] | 7.5e-05 |
| B | 2 | 5 | 1.022 | 4.89 | 0.000128 | [0.0001059, 0.0001511] | 0.005504 |
| B | 3 | 5 | 1.667 | 3.00 | 0.00161 | [0.001531, 0.00169] | 0.05474 |
| B | 4 | 5 | 1.839 | 2.72 | 0.004089 | [0.003964, 0.004215] | 0.1104 |
| B | 5 | 5 | 3.666 | 1.36 | 0.111 | [0.1104, 0.1116] | 1 |
| C | 0 | 7 | 0.227 | 30.87 | 1e-06 | [0, 3.689e-06] | 7.5e-05 |
| C | 1 | 7 | 0.619 | 11.32 | 1e-06 | [0, 3.689e-06] | 7.5e-05 |
| C | 2 | 7 | 2.244 | 3.12 | 0.000357 | [0.00032, 0.000395] | 0.01464 |
| C | 3 | 7 | 3.333 | 2.10 | 0.004217 | [0.00409, 0.004345] | 0.1104 |
| C | 4 | 7 | 3.676 | 1.90 | 0.01159 | [0.01138, 0.0118] | 0.2297 |
| C | 5 | 7 | 5.166 | 1.36 | 0.05533 | [0.05489, 0.05578] | 0.83 |

p is the upper-tail plus-one estimator (k+1)/(1,000,001). MC95 is the exact two-sided Clopper–Pearson interval for the underlying null tail probability. With zero exceedances, p≈1e-6 and the upper 95% bound is approximately 3.69e-6; there is no p=0 claim. Holm correction covers 75 primary cutoff tests and 15 diagnostic tests separately. Raw and corrected thresholds are both shown rather than selecting whichever is favorable.

## Answers to the scientific questions

1. **Does enrichment survive topology matching? Yes.** A/B top-10 observed recovery is approximately 17.8-fold above the topology-only expectation, and both survive correction. This result exceeds random sampling among membrane/near-membrane positions, not merely all 485 residues.
2. **Does it survive topology plus chemistry? Yes for the central A/B result.** Top-10 enrichment is approximately 4.90-fold for both, with Holm p=0.0369 for A and 0.00550 for B. This supports information beyond simple membrane location and the fixed ion-interacting residue set. C must retain its out-of-support warning.
3. **Does it survive conservation matching? Partly, depending on endpoint.** For B, top 5, Tier 1, and Tier 1+2 survive primary cutoff correction (Holm p≈0.0369, 0.0369 and 0.0309). B top-10 p≈0.00161 becomes 0.0547 after correction. No A cutoff survives correction, although several are nominally significant. A/B mean-rank and normalized-loss tests, and both MRR tests, survive the separate rank-test correction.
4. **Does it survive confidence matching? In rank-based tests, but not corrected cutoff tests.** A mean-rank/normalized-loss Holm p≈0.0390; B mean-rank/normalized-loss p≈0.00572 and MRR p≈0.0115. No A/B cutoff survives the 75-test correction. A/B top-10 raw p≈0.0182/0.00409 should not be presented as globally corrected significance.
5. **Does it survive the geometry-blind feature-matched null? No corrected result does.** A/B top-10 raw p≈0.111 and adjusted p=1; their rank-based raw p values are also generally ≈0.111 or larger. C finite mean/median rank tests have nominal p≈0.021–0.022 but adjusted p≈0.248. NULL 5 is diagnostic, partly forced, and low-support; failure to reject is not proof that geometry is uninformative.
6. **Which sites remain exceptional?** N127 and D47 have the highest NULL 4 reference percentiles (95.45 and 94.44), followed by D248 (86.36), D40 (83.33) and S252 (72.22). These percentiles describe positions within small matched pools, not causal importance or individually corrected p-values. M44 remains NA, never a fabricated rank.
7. **How much success is consistent with obvious priors?** The expected A top-10 recovery rises from 0.082 under NULL 0 to 1.616 under NULL 4 and 2.667 under NULL 5, versus four observed hits. For B it rises from 0.103 to 1.839 to 3.666, versus five observed. Corresponding fold enrichment shrinks from about 48.6 to 2.48 to 1.50 (A), and 48.4 to 2.72 to 1.36 (B). These are conditional expectation contrasts, not percentages of variance explained or causal contributions. NULL 5 forcing makes the last comparison particularly conservative.
8. **How much is attributable to structure-aware ranking?** The A/B rank tests suggest residual predictive association beyond topology, broad chemistry, conservation and pLDDT. However, NULL 5 supplies no corrected evidence uniquely attributable to spatial geometry. The analysis cannot separate geometry from Step 6 eligibility, detailed chemistry, nonlinear score construction, correlated evidence, or the coarse score quintiles. It is therefore not defensible to assign a numerical fraction of success to geometry.
9. **What limitations remain?** Small nested benchmarks; a retrospectively selected protein and assays; untested candidates rather than known negatives; imperfect orthology/topology/confidence covariates; broad strata and tied quantiles; Step 6 eligibility censoring; overlapping evidence and repeated conservation weighting; multiple correlated endpoints; chemistry mismatch in C; singleton strata and forced recovery in NULL 5; pretraining/template provenance; and no causal mechanistic inference. The evaluation does not establish prospective generalization.

## Rank-based results and censoring

| benchmark | null | statistic | observed | p | Holm |
| --- | --- | --- | --- | --- | --- |
| A | 3 | mean_frozen_rank | 3.5 | 0.000648 | 0.0149 |
| A | 3 | mean_reciprocal_rank | 0.4667 | 0.002185 | 0.03904 |
| A | 4 | mean_frozen_rank | 3.5 | 0.002055 | 0.03904 |
| A | 4 | mean_reciprocal_rank | 0.4667 | 0.003565 | 0.05704 |
| A | 5 | mean_frozen_rank | 3.5 | 0.1112 | 0.9992 |
| A | 5 | mean_reciprocal_rank | 0.4667 | 0.1112 | 0.9992 |
| B | 3 | mean_frozen_rank | 3.6 | 4.9e-05 | 0.001715 |
| B | 3 | mean_reciprocal_rank | 0.4233 | 0.000169 | 0.004732 |
| B | 4 | mean_frozen_rank | 3.6 | 0.000212 | 0.005724 |
| B | 4 | mean_reciprocal_rank | 0.4233 | 0.000478 | 0.01147 |
| B | 5 | mean_frozen_rank | 3.6 | 0.111 | 0.9992 |
| B | 5 | mean_reciprocal_rank | 0.4233 | 0.111 | 0.9992 |
| C | 3 | mean_frozen_rank | 9.5 | 0.3189 | 1 |
| C | 3 | mean_reciprocal_rank | 0.2293 | 0.004242 | 0.06363 |
| C | 4 | mean_frozen_rank | 9.5 | 0.2167 | 1 |
| C | 4 | mean_reciprocal_rank | 0.2293 | 0.01032 | 0.1057 |
| C | 5 | mean_frozen_rank | 9.5 | 0.02067 | 0.2481 |
| C | 5 | mean_reciprocal_rank | 0.2293 | 0.1301 | 0.9992 |

Step 6 ranks only 215 residues. A has finite mean/median rank 3.5/3.5; B 3.6/4. C has ten ranked sites with finite mean/median 9.5/6.5 and one unranked site (M44), so full-set raw mean/median is undefined. Mean/median tests use the pre-specified lexicographic criterion: fewer unranked positions first, then smaller finite rank summary. MRR assigns zero reciprocal contribution to unranked sites; normalized loss assigns them loss 1 and uses (r−1)/215 for ranked sites. These are evaluation statistics, not new frozen residue ranks. Holm correction uses 60 primary and 12 diagnostic rank tests. All statistics, null expectations, Monte Carlo intervals and signed z-scores (where meaningful) appear in `rank_based_enrichment.tsv`.

## Residue-wise matched standing

| residue | rank | N0 | N1 | N2 | N3 | N4 | N4_pool |
| --- | --- | --- | --- | --- | --- | --- | --- |
| E25 | 7 | 98.66 | 96.35 | 86.73 | 73.81 | 61.11 | 9 |
| S39 | 14 | 97.22 | 92.42 | 72.45 | 45.24 | 38.89 | 9 |
| D40 | 5 | 99.07 | 97.47 | 90.82 | 83.33 | 83.33 | 9 |
| M44 | NA | NA | NA | NA | NA | NA | 9 |
| D47 | 4 | 99.28 | 98.03 | 92.86 | 96.43 | 94.44 | 9 |
| C93 | 28 | 94.33 | 84.55 | 50.00 | 75.00 | 50.00 | 3 |
| N127 | 1 | 99.90 | 99.72 | 98.98 | 97.62 | 95.45 | 11 |
| H244 | 10 | 98.04 | 94.66 | 80.61 | 64.29 | 68.18 | 11 |
| D248 | 2 | 99.69 | 99.16 | 96.94 | 92.86 | 86.36 | 11 |
| S252 | 6 | 98.87 | 96.91 | 88.78 | 78.57 | 72.22 | 9 |
| I291 | 18 | 96.39 | 90.17 | 65.31 | 42.86 | 45.45 | 11 |

Higher percentile means a better stored rank than more members of the reference pool; ties use the midpoint. Unranked background sites sit below ranked sites for this evaluation only. Site reference strata are constructed per site and do not change with benchmark composition. I291 N2–N4 percentiles are descriptive comparisons to a pool that excludes its chemistry; M44 percentiles are NA. Exact/effective sizes, eligibility and fallback radii are supplied for every column.

## Validation, files and reproduction

`validate_matched_null.py` checks byte identity of all blind-manifest inputs, membership against Step 7 curated evidence, stored rank agreement with the original mutation table, feature-source whitelisting, exact rebuilding of fixed pools, no execution of blind scoring, plus-one p-values and confidence intervals for all 162 tests, effective permutation counts, and 90 independent exact recovery cross-checks. `validation.json` records the result. The feature builder reads only frozen Step 3–5 features; ground truth defines labels and matching targets but never enters scoring. All existing files are also checked against the starting git commit before the Step 8A commit.

Required tables: `null_model_definitions.tsv`, `matched_null_permutation_results.tsv`, `residue_matched_percentiles.tsv`, `rank_based_enrichment.tsv`, `null_sampling_diagnostics.tsv`. Additional provenance includes `METHODS_PRESPECIFIED.md`, `input_manifest.json`, `sampling_pools.json`, `strata.json`, `runtime_preflight.json`, `execution_summary.json`, recovery histograms, support summary and exact-distribution checks. All are under `comparison/matched_null/`.

New figures: `figures/matched_null_enrichment.png`, `figures/matched_null_empirical_pvalues.png`, `figures/experimental_residue_matched_percentiles.png`. The p-value figure labels finite Monte Carlo resolution and shows Holm-adjusted values; it does not turn a simulation floor into an exact bound.

Remote commands (from the remote project directory; one thread):

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /path/to/conda/envs/slc30a10_ai/bin/python -B comparison/matched_null/matched_null.py prepare
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /path/to/conda/envs/slc30a10_ai/bin/python -B comparison/matched_null/matched_null.py analyze
OPENBLAS_NUM_THREADS=1 /path/to/conda/envs/slc30a10_ai/bin/python -B comparison/matched_null/validate_matched_null.py
MPLCONFIGDIR=comparison/matched_null/cache OPENBLAS_NUM_THREADS=1 /path/to/conda/envs/slc30a10_ai/bin/python -B comparison/matched_null/render_report.py
```

`prepare` refuses to redefine pools after results exist. To reproduce this checkpoint, use the committed pools and input manifest and rerun `analyze` only within a separate copy of Step 8A outputs; do not touch Steps 1–7. `STEP8A_FILES.sha256` covers all versioned Step 8A artifacts except itself, runtime cache and OS metadata. Final local/remote hash and git-scope checks are recorded in `final_integrity.json`. Stop here; no prediction-pipeline revision or optimization was performed.
