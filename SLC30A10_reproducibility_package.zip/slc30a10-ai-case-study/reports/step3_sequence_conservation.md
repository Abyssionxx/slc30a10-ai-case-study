# Step 3: blind sequence conservation

Sequence-only analysis; no experimental or structural comparison. Top residues are computational candidates, not established functional sites.

## Alignment provenance

```text
2026-09-13T08:40:11Z
/path/to/conda/envs/slc30a10_ai/bin/mafft
v7.526 (2024/Apr/26)
Python 3.11.16
64b78dd2e96eb8756b32ee7ed5b16b1912bb1671788ecba8959b05c7207fd6c4  scripts/run_step3_alignments.sh
b2e33d9da9b6e9d801ef21f7bf4802111ba67d2eb1032e1dde739f92a29136f1  scripts/analyze_sequence_conservation.py
2b0830ee2e9a41626eb01044719a9b44b576ad52dcdc324b2a978d4078b994a8  data/processed/step3_prespecified_methods.md
timeout 1200s mafft --auto --thread 8 --threadit 0 sequences/SLC30A10_orthologs.fasta > alignments/SLC30A10_orthologs_mafft.fasta 2> logs/SLC30A10_orthologs_mafft.stderr.txt
48fc8c6dad50604e00fb1a94a8abb04776de3758489ccd6dd298741fd5267463  alignments/SLC30A10_orthologs_mafft.fasta
2026-09-13T08:40:14Z
timeout 1200s mafft --auto --thread 8 --threadit 0 sequences/human_SLC30_family.fasta > alignments/human_SLC30_family_mafft.fasta 2> logs/human_SLC30_family_mafft.stderr.txt
0f13a79f7eb7fa727d27a8cf2853b4241937517edd2ca4fe4f405e265b0d733b  alignments/human_SLC30_family_mafft.fasta
2026-09-13T08:40:16Z
```

## Dataset and alignment QC

- SLC30A10_orthologs: 60 records; 639 columns. Every input ID occurs once; all ungapped sequences exactly match inputs; frozen human target present.
- human_SLC30_family: 10 records; 1041 columns. Every input ID occurs once; all ungapped sequences exactly match inputs; frozen human target present.

485 human positions mapped independently in each MSA.

## Pre-specified scoring and limitations

# Step 3 methods fixed before alignment/scoring

Inputs: frozen Step 1 canonical FASTA and Step 2 ortholog/family FASTAs, verified by SHA256. No external scientific data or literature.

Separate MAFFT commands (MAFFT 7.526):

    mafft --auto --thread 8 --threadit 0 sequences/SLC30A10_orthologs.fasta > alignments/SLC30A10_orthologs_mafft.fasta
    mafft --auto --thread 8 --threadit 0 sequences/human_SLC30_family.fasta > alignments/human_SLC30_family_mafft.fasta

Each command is wrapped in GNU timeout 1200s; stdout and stderr preserved separately. Iterative-refinement multithreading is disabled for reproducibility. No random sampling or random seed is used.

Map each non-gap character of the aligned frozen human target to consecutive 1-based human positions, verifying the entire ungapped sequence equals the frozen target. Ortholog statistics include all 60 records (including the human target). Main family statistics include all 10 human paralogs. Also calculate family statistics excluding SLC30A10 (9 records) for specificity to avoid self-identity inflation.

For n records and k non-gap residues: coverage C=k/n; identity I=number identical to the human residue/k; Shannon entropy H=-sum(p_a log2 p_a) over non-gap amino-acid frequencies; consensus frequency=max(p_a); ties in consensus resolved alphabetically. Report distinct amino-acid count. All-gap columns: coverage 0, identity 0, entropy 0, consensus '-', consensus frequency 0; undefined biological statistics are flagged by k=0.

Specificity S = C_orth * I_orth * C_other9 * (1-I_other9). Equal multiplicative factors, no fitted weights, score in [0,1]. High values indicate conserved ortholog residues with covered but nonidentical other paralogs. Entropies are reported but do not enter the score. Report all-10 family identity/coverage separately from other-9 identity/coverage. No residue identity or functional annotation affects selection.

Percentile = 100*(average ascending rank - 1)/(485-1); ties receive their mean rank. Larger percentiles indicate larger score/conservation. Top-20 tie-breaker: smaller human residue number. Ties do not imply a biological ordering.

Sensitivity: remove A0ACM8BIL7 from the fixed ortholog alignment without realigning, rescore all columns and specificity with the original family alignment unchanged. Compare ortholog identity and specificity using Pearson and Spearman (average ranks), maximum absolute value changes, and count positions with absolute percentile changes >10 points. Operational substantial-effect flag, fixed beforehand: specificity Spearman <0.95 OR >10% of positions moving >10 specificity percentile points. Primary analysis retains lamprey; any flag prompts caution and presentation of the sensitivity output, without silently replacing the primary dataset. This test measures membership sensitivity, not alignment sensitivity.

Limitations: gene-name-based orthology remains provisional; equal sequence weights are not phylogenetic weights; uneven clade sampling can bias conservation. Divergent family alignments and gappy columns may be uncertain. This is a blind sequence signal, not evidence of transport or binding function.


## Lamprey sensitivity

```json
{
  "ortholog_identity": {
    "pearson": 0.9996142265501827,
    "spearman": 0.9983449101474365,
    "maximum_absolute_change": 0.024621212121212155,
    "positions_rank_change_gt10": 2
  },
  "specificity": {
    "pearson": 0.9998886227874959,
    "spearman": 0.9998153970439171,
    "maximum_absolute_change": 0.01638418079096049,
    "positions_rank_change_gt10": 0
  },
  "method": "Drop lamprey from fixed MSA; no realignment",
  "substantial_effect": false
}
```

Primary alignment retains sea lamprey. Membership sensitivity does not test how realignment would change columns.

## Top 20 blind sequence-specificity candidates

| Position | Residue | Score | Percentile | Ortholog identity | Ortholog coverage | Other-9 identity | Other-9 coverage |
|---:|:---:|---:|---:|---:|---:|---:|---:|
| 6 | G | 1.000000 | 99.793 | 1.0000 | 1.0000 | 0.0000 | 1.0000 |
| 22 | F | 1.000000 | 99.793 | 1.0000 | 1.0000 | 0.0000 | 1.0000 |
| 32 | G | 1.000000 | 99.793 | 1.0000 | 1.0000 | 0.0000 | 1.0000 |
| 91 | A | 0.983333 | 99.277 | 0.9833 | 1.0000 | 0.0000 | 1.0000 |
| 242 | L | 0.983333 | 99.277 | 0.9833 | 1.0000 | 0.0000 | 1.0000 |
| 282 | S | 0.966667 | 98.864 | 0.9667 | 1.0000 | 0.0000 | 1.0000 |
| 309 | M | 0.966667 | 98.864 | 0.9667 | 1.0000 | 0.0000 | 1.0000 |
| 339 | E | 0.950000 | 98.554 | 0.9500 | 1.0000 | 0.0000 | 1.0000 |
| 136 | D | 0.933333 | 98.347 | 0.9333 | 1.0000 | 0.0000 | 1.0000 |
| 80 | V | 0.916667 | 98.037 | 0.9167 | 1.0000 | 0.0000 | 1.0000 |
| 293 | S | 0.916667 | 98.037 | 0.9167 | 1.0000 | 0.0000 | 1.0000 |
| 9 | C | 0.900000 | 97.727 | 0.9000 | 1.0000 | 0.0000 | 1.0000 |
| 3 | R | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.1111 | 1.0000 |
| 4 | Y | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.1111 | 1.0000 |
| 120 | G | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.1111 | 1.0000 |
| 238 | I | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.0000 | 0.8889 |
| 262 | F | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.1111 | 1.0000 |
| 277 | C | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.0000 | 0.8889 |
| 283 | L | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.1111 | 1.0000 |
| 287 | M | 0.888889 | 96.694 | 1.0000 | 1.0000 | 0.1111 | 1.0000 |

The rank-20 boundary score is shared by 9 residues. Ties are ordered by residue number only.

Software: {"python": "3.11.16", "numpy": "2.4.6", "matplotlib": "3.11.1"}
