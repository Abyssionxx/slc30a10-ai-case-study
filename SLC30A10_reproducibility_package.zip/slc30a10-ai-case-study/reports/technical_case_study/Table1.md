| Dataset or QC item | Frozen result | Interpretive boundary |
| --- | --- | --- |
| Canonical human input | UniProt Q6XR72; reviewed canonical; 485 aa; one record | Sequence-only database fields |
| Candidate orthologs | 60 sequences; 60 species; 393–486 aa; median 465 aa | Gene-based candidates, not tree-validated orthology |
| Vertebrate coverage | 28 mammals; 10 ray-finned fishes; 8 birds; 7 lepidosaurs; 4 turtles; 1 amphibian; 1 crocodilian; 1 cyclostome | Diverse sampling, not phylogenetic weighting |
| Human SLC30 family | 10 reviewed paralogs; one species; 369–765 aa; median 445 aa | Separate family comparison |
| Sequence integrity | No ambiguous residues or duplicate sequences in either dataset; unique accessions | Species unique only for ortholog set |
| Ortholog / family MSA | 60 × 639 / 10 × 1,041 alignment columns | All input sequences preserved ungapped |
| Lamprey exclusion sensitivity | Identity Spearman 0.998345; specificity Spearman 0.999815 | Fixed alignment; no realignment |
| Topology agreement | 455/485 positions (93.8%); six helices | 30 boundary disagreements |
| Predicted model | 485/485 residues; mean pLDDT 67.48; median 80.06; 205 below 70 | Full coverage is not uniformly high confidence |
