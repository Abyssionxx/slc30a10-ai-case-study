"""Reporting only: copy stored values into tables and render figures; never score residues."""
from pathlib import Path
import csv,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'reports/technical_case_study'
def read(p):
 with (ROOT/p).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def table(headers,rows):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
ranks={r['residue']:r for r in read('comparison/frozen_residue_ranks.tsv')}
panel=read('comparison/panel_experimental_status.tsv')
perms=read('comparison/matched_null/matched_null_permutation_results.tsv')
tables={}
tables[1]=table(['Dataset or QC item','Frozen result','Interpretive boundary'],[
['Canonical human input','UniProt Q6XR72; reviewed canonical; 485 aa; one record','Sequence-only database fields'],
['Candidate orthologs','60 sequences; 60 species; 393–486 aa; median 465 aa','Gene-based candidates, not tree-validated orthology'],
['Vertebrate coverage','28 mammals; 10 ray-finned fishes; 8 birds; 7 lepidosaurs; 4 turtles; 1 amphibian; 1 crocodilian; 1 cyclostome','Diverse sampling, not phylogenetic weighting'],
['Human SLC30 family','10 reviewed paralogs; one species; 369–765 aa; median 445 aa','Separate family comparison'],
['Sequence integrity','No ambiguous residues or duplicate sequences in either dataset; unique accessions','Species unique only for ortholog set'],
['Ortholog / family MSA','60 × 639 / 10 × 1,041 alignment columns','All input sequences preserved ungapped'],
['Lamprey exclusion sensitivity','Identity Spearman 0.998345; specificity Spearman 0.999815','Fixed alignment; no realignment'],
['Topology agreement','455/485 positions (93.8%); six helices','30 boundary disagreements'],
['Predicted model','485/485 residues; mean pLDDT 67.48; median 80.06; 205 below 70','Full coverage is not uniformly high confidence']])
tables[2]=table(['Residue','Experimental category','Step 3','Step 4','Step 5','Step 6','Blind tier'],[[s,'Direct coordination' if s!='D47' else 'Transport-essential, not direct ligand',*[ranks[s]['Step%d_rank'%i] for i in range(3,7)],'Tier 2' if s=='D40' else 'Tier 1'] for s in ['D40','N127','D248','S252','D47']])
tables[3]=table(['Mutation','Frozen tier','Predicted effect','Experimental effect','Assessment'],[[r['mutation'],r['tier'],r['frozen_predicted_effect'],r['experimental_effect'],r['classification']] for r in panel])
tables[4]=table(['Benchmark','Null','Observed top-10 hits','Expected','Fold','Raw p','Holm-adjusted p'],[[r['benchmark'],r['null_model'],r['observed_recovery'],f"{float(r['null_expected']):.3f}",f"{float(r['fold_enrichment']):.2f}",f"{float(r['empirical_p']):.6g}",f"{float(r['holm_p']):.6g}"] for r in perms if r['cutoff']=='Top 10' and r['benchmark'] in ['A','B']])
tables[5]=table(['Limitation','Consequence for interpretation','Appropriate next test'],[
['One retrospective target','No estimate of general-purpose performance','Independent hidden-answer transporter'],
['Internal blinding and model provenance','Does not exclude pretraining exposure','External holdout and training-date audit'],
['Candidate orthology','Paralogy or uneven species sampling may affect conservation','Independent phylogenetic validation'],
['Single-state model and AF-initialized experimental modeling','Backbone agreement is not independent validation','Independent structural and functional assays'],
['Coarse cavities and CB graph','Neighborhoods do not specify a coordination shell','Pre-specified donor geometry with uncertainty'],
['Repeated and correlated features','Ablations do not uniquely assign causal credit','Independent targets and fixed comparator models'],
['NULL 5: nine A/B sets','Limited ability to distinguish geometry-specific signal','Larger independent benchmark, fixed matching design'],
['Small, selectively tested positive set','Known-positive fraction is not full panel precision','Test the complete proposed panel'],
['Substitution-specific phenotypes','H244N/D cannot validate H244A','Evaluate exact substitutions'],
['Untested candidates and controls','No positive or negative adjudication','Measure transport and expression separately']])
for n,t in tables.items():(OUT/f'Table{n}.md').write_text(t+'\n')
ledger={'rank_trajectories':{s:{k:v for k,v in ranks[s].items()} for s in ['D40','N127','D248','S252','D47']},'panel_rows':panel,'top10_matched_null_rows':[r for r in perms if r['cutoff']=='Top 10' and r['benchmark'] in ['A','B']],'source_files':['comparison/frozen_residue_ranks.tsv','comparison/panel_experimental_status.tsv','comparison/matched_null/matched_null_permutation_results.tsv']}
(OUT/'claim_ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
if __name__=='__main__' and '--figures' in __import__('sys').argv:
 import numpy as np
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.patches import FancyBboxPatch
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','savefig.dpi':220})
 dest=ROOT/'figures/technical_case_study';dest.mkdir(exist_ok=True)
 def save(fig,n):
  fig.savefig(dest/f'Figure{n}.png',bbox_inches='tight',facecolor='white');fig.savefig(dest/f'Figure{n}.svg',bbox_inches='tight',facecolor='white');plt.close(fig)
 colors=['#0072B2','#D55E00','#009E73','#CC79A7','#7A6300']
 fig,ax=plt.subplots(figsize=(12,5.5));ax.set(xlim=(0,12),ylim=(0,5.5));ax.axis('off')
 labels=[['Canonical sequence','Candidate orthologs','Human paralogs','Conservation'],['Membrane topology','Residue chemistry','AlphaFold DB model','Clusters / cavities'],['Mutation panel','Prediction freeze','Ground-truth reveal','Matched-null tests']]
 for j,row in enumerate(labels):
  for i,label in enumerate(row):
   x=.2+i*3;y=4.4-j*1.65;c='#e3f0f6' if j<2 or i<2 else '#f7e8d7'
   ax.add_patch(FancyBboxPatch((x,y),2.55,.72,boxstyle='round,pad=0.10',facecolor=c,edgecolor='#52606b'))
   ax.text(x+1.275,y+.36,label,ha='center',va='center',fontsize=10)
   if i<3:ax.annotate('',xy=(x+2.88,y+.36),xytext=(x+2.68,y+.36),arrowprops={'arrowstyle':'->','color':'#52606b'})
  if j<2:
   ax.plot([11.86,11.96,11.96,1.475],[y+.36,y+.36,y-.4,y-.4],color='#9aa4ac',lw=1)
   ax.annotate('',xy=(1.475,y-.83),xytext=(1.475,y-.4),arrowprops={'arrowstyle':'->','color':'#9aa4ac'})
 ax.text(6,.12,'Internal blind phase → immutable reporting checkpoint → retrospective evaluation\nSHA256 and Git provide provenance; no scores or tiers changed after the freeze.',ha='center',va='bottom',fontsize=10)
 ax.set_title('Figure 1 | Blind design, prediction freeze and experimental reveal',loc='left',pad=14,weight='bold');save(fig,1)
 fig,axes=plt.subplots(1,5,figsize=(13,4.7),sharey=True)
 for ax,s,c in zip(axes,['D40','N127','D248','S252','D47'],colors):
  v=[int(ranks[s]['Step%d_rank'%i]) for i in range(3,7)];ax.plot(range(4),v,'o-',color=c,lw=2.3)
  for x,y in enumerate(v):ax.annotate(str(y),(x,y),xytext=(0,8 if y>15 else -16),textcoords='offset points',ha='center',color=c,weight='bold')
  ax.set_yscale('log');ax.set_ylim(600,.65);ax.set_xticks(range(4),['3','4','5','6']);ax.set_xlabel('Frozen step');ax.set_title(s,weight='bold');ax.grid(axis='y',alpha=.15);ax.axhline(20,color='gray',ls=':',lw=.7)
 axes[0].set_yticks([1,5,20,100,485],['1','5','20','100','485']);axes[0].set_ylabel('Stored rank (lower is better; log scale)')
 fig.suptitle('Figure 2 | Ranking trajectories of retrospectively identified experimental sites',x=.03,ha='left',weight='bold');fig.text(.5,.005,'Steps 3–5: 485 positions. Step 6: 215 eligible positions. Sites selected for display only after reveal.',ha='center',fontsize=9);fig.tight_layout(rect=(0,.03,1,.91));save(fig,2)
 topo=read('data/processed/SLC30A10_topology_consensus.tsv');strict=json.loads((ROOT/'results/step4_qc.json').read_text())['strict_ranges']
 ca={}
 for line in (ROOT/'structures/predicted/AF-Q6XR72-F1-model_v6.pdb').read_text().splitlines():
  if line.startswith('ATOM') and line[12:16].strip()=='CA':ca[int(line[22:26])]=[float(line[30:38]),float(line[38:46]),float(line[46:54])]
 fig=plt.figure(figsize=(11,6));ax=fig.add_subplot(121,projection='3d');b=fig.add_subplot(122)
 # Original AF Cartesian coordinates; no alignment, orientation fit or geometry analysis.
 xyz=np.array([ca[i] for i in range(1,486)]);ax.plot(*xyz.T,color='#bdc2c6',alpha=.42,lw=.6)
 for lo,hi in strict:
  p=np.array([ca[i] for i in range(lo,hi+1)]);ax.plot(*p.T,color='#456d89',lw=2.5)
 for sites,c,label in [(['N127','D248','D280','D47','S252'],'#0072B2','Tier 1'),(['D40','S50','N85','H244'],'#D55E00','Tier 2')]:
  p=np.array([ca[int(s[1:])] for s in sites]);ax.scatter(*p.T,c=c,s=35,label=label,depthshade=False)
 ax.set_box_aspect(np.ptp(xyz,axis=0));ax.view_init(elev=20,azim=-60);ax.set_axis_off();ax.legend(loc='lower left',fontsize=9);ax.set_title('Frozen AlphaFold model\nFull-chain Cα trace; dark segments = strict TM')
 b.hlines(0,1,485,color='#aeb8c0')
 for h,(lo,hi) in enumerate(strict,1):b.broken_barh([(lo,hi-lo+1)],(-.1,.2),facecolors='#456d89');b.text((lo+hi)/2,.15,str(h),ha='center',fontsize=8)
 for j,(s,c) in enumerate([(s,'#0072B2') for s in ['N127','D248','D280','D47','S252']]+[(s,'#D55E00') for s in ['D40','S50','N85','H244']]):
  pos=int(s[1:]);y=.7+j*.42;b.plot([pos,pos],[0,y],color=c,lw=.7,alpha=.6);b.scatter([pos],[y],c=c,s=25);b.text(pos+5,y,s,va='center',fontsize=9,color=c)
 b.set(xlim=(0,485),ylim=(-.4,4.6),xlabel='Human residue number',yticks=[]);b.set_title('Blind tiers on sequence-derived topology');b.spines['left'].set_visible(False)
 fig.suptitle('Figure 3 | Predicted topology and structure with frozen blind candidates',x=.03,ha='left',weight='bold');fig.tight_layout(rect=(0,0,1,.94));save(fig,3)
 fig,ax=plt.subplots(figsize=(9,4.8));labels=['Top 5','Top 10','Top 20','Tier 1','Tier 1 + Tier 2'];x=np.arange(5)
 for off,bench,den,c,label in [(-.18,'A',4,'#0072B2','A: direct coordinators (4)'),(.18,'B',5,'#D55E00','B: transport-essential (5)')]:
  vals=[int(next(r['observed_recovery'] for r in perms if r['benchmark']==bench and r['null_model']=='0' and r['cutoff']==cut)) for cut in labels]
  ax.bar(x+off,np.array(vals)/den,width=.33,color=c,label=label)
  for xx,v in zip(x+off,vals):ax.text(xx,v/den+.015,f'{v}/{den}',ha='center',fontsize=10)
 ax.set_xticks(x,labels);ax.set(ylim=(0,1.26),ylabel='Fraction of experimental benchmark recovered');ax.set_yticks([0,.25,.5,.75,1],['0','0.25','0.50','0.75','1.00']);ax.legend(loc='upper center',bbox_to_anchor=(.5,1.02),ncol=2,frameon=False);ax.set_title('Figure 4 | Recovery at frozen cutoffs and tiers',loc='left',weight='bold',pad=20);save(fig,4)
 fig,axes=plt.subplots(2,2,figsize=(11,7),sharex=True)
 for j,bench in enumerate(['A','B']):
  rows=sorted([r for r in perms if r['benchmark']==bench and r['cutoff']=='Top 10'],key=lambda r:int(r['null_model']))
  folds=[float(r['fold_enrichment']) for r in rows];ps=[float(r['empirical_p']) for r in rows];qs=[float(r['holm_p']) for r in rows]
  axes[0,j].plot(range(6),folds,'o-',color=colors[j]);axes[0,j].set_yscale('log');axes[0,j].axhline(1,color='gray',ls=':');axes[0,j].set_title(('A: four direct coordinators' if bench=='A' else 'B: five transport-essential sites'))
  for k,v in enumerate(folds):axes[0,j].annotate(f'{v:.2f}×',(k,v),xytext=(0,7),textcoords='offset points',ha='center',fontsize=8)
  axes[0,j].set_ylim(.8,95)
  axes[1,j].plot(range(6),-np.log10(ps),'o--',color=colors[j],alpha=.5,label='Raw p');axes[1,j].plot(range(6),-np.log10(qs),'s-',color=colors[j],label='Holm-adjusted p');axes[1,j].axhline(-np.log10(.05),color='gray',ls=':',label='0.05 reference');axes[1,j].set_ylim(-.2,6.5);axes[1,j].set_xticks(range(6),['N0','N1','N2','N3','N4','N5*']);axes[1,j].legend(frameon=False,fontsize=8)
 axes[0,0].set_ylabel('Top-10 fold enrichment (log scale)');axes[1,0].set_ylabel('−log10(p)');fig.suptitle('Figure 5 | Enrichment weakens with increasingly strict matching',x=.03,ha='left',weight='bold');fig.text(.5,.015,'1,000,000 draws per test. N0–4: primary correction family. N5*: diagnostic family; only nine A/B matched sets.',ha='center',fontsize=9);fig.tight_layout(rect=(0,.04,1,.94));save(fig,5)
 fig,ax=plt.subplots(figsize=(10,7));statuscolors={'confirmed hit':'#0072B2','experimentally negative':'#D55E00','experimentally untested':'#9aa4ac'}
 for i,r in enumerate(panel):
  y=len(panel)-1-i;c=statuscolors[r['classification']];ax.scatter([0],[y],c=c,s=75,marker='s');ax.text(.2,y,r['mutation'],va='center',weight='bold');ax.text(1.8,y,r['tier'],va='center');ax.text(3.2,y,r['frozen_predicted_effect'],va='center');ax.text(4.6,y,r['experimental_effect'],va='center',color=c)
 ax.set(xlim=(-.2,7.2),ylim=(-1,len(panel)+1));ax.axis('off')
 for x,t in [(.2,'Mutation'),(1.8,'Frozen tier'),(3.2,'Predicted effect'),(4.6,'Experimental effect')]:ax.text(x,len(panel),t,weight='bold')
 ax.set_title('Figure 6 | Exact-substitution outcomes: 6 supported, 1 negative, 9 untested',loc='left',weight='bold',pad=15);fig.text(.5,.025,'Six supported substitutions represent five sites. Both proposed negative controls remain experimentally untested.',ha='center',fontsize=9);save(fig,6)
 print('Rendered six reporting-only figures in PNG and SVG.')
