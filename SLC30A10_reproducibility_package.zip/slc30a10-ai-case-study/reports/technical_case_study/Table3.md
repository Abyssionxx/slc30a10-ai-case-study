| Mutation | Frozen tier | Predicted effect | Experimental effect | Assessment |
| --- | --- | --- | --- | --- |
| N127A | Tier 1 | strong | abolished | confirmed hit |
| D248A | Tier 1 | strong | abolished | confirmed hit |
| D280A | Tier 1 | strong | not tested | experimentally untested |
| D47A | Tier 1 | strong | abolished | confirmed hit |
| S252A | Tier 1 | strong | abolished | confirmed hit |
| D40A | Tier 2 | strong | abolished | confirmed hit |
| S50A | Tier 2 | strong | not tested | experimentally untested |
| N85A | Tier 2 | strong | not tested | experimentally untested |
| H244A | Tier 2 | strong | unchanged | experimentally negative |
| S282A | Tier 3 | strong | not tested | experimentally untested |
| E339A | Tier 3 | moderate | not tested | experimentally untested |
| D136A | Tier 3 | strong | not tested | experimentally untested |
| D248N | Tier 1 | strong | abolished | confirmed hit |
| D280N | Tier 1 | strong | not tested | experimentally untested |
| S56T | control | weak | not tested | experimentally untested |
| T90S | control | weak | not tested | experimentally untested |
