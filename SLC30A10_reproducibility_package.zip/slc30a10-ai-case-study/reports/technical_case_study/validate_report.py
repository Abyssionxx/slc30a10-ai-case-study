"""Read-only validation of source analyses; writes only new reporting validation JSON."""
from pathlib import Path
import csv,json,hashlib,re,subprocess,datetime,math
R=Path(__file__).resolve().parents[2];O=R/'reports/technical_case_study'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
 with (R/p).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def js(p):return json.loads((R/p).read_text())
checks=[]
def check(name,condition,source='',details=None):
 checks.append({'check':name,'passed':bool(condition),'source':source,'details':details})
 if not condition:raise AssertionError(name)
audit=js('reports/technical_case_study/source_audit.json')
changed=[p for p,h in audit['tracked_sha256'].items() if not (R/p).exists() or sha(R/p)!=h]
check('All pre-existing tracked files byte-identical',not changed,'source_audit.json',{'count':len(audit['tracked_sha256']),'changed':changed})
freeze='008b7ad7a436fc02898292ec7d0441cf0df6c390'
check('Blind checkpoint still resolves to exact commit',subprocess.check_output(['git','rev-parse',freeze],cwd=R).decode().strip()==freeze,'git')
check('Blind checkpoint remains an ancestor',subprocess.run(['git','merge-base','--is-ancestor',freeze,'HEAD'],cwd=R).returncode==0,'git')
manifest_results={}
for name in audit['manifests']:
 pairs=[]
 for line in (R/name).read_text().splitlines():
  if line.strip():h,p=line.split(maxsplit=1);pairs.append((h,p.lstrip('* ')))
 bad=[p for h,p in pairs if sha(R/p)!=h]
 check('Manifest '+name,not bad,name,{'entries':len(pairs),'mismatches':bad})
 if name.startswith('results/'):
  diff=subprocess.check_output(['git','diff',freeze,'HEAD','--',name,*[p for h,p in pairs]],cwd=R)
  check('Blind manifest members unchanged from checkpoint: '+name,not diff,name)
 manifest_results[name]={'entries':len(pairs),'sha256':sha(R/name),'passed':True}
report=R/'reports/SLC30A10_AI4SCIENCE_TECHNICAL_REPORT.md';summary=R/'reports/SLC30A10_AI4SCIENCE_TECHNICAL_REPORT_SUMMARY.md'
text=report.read_text();short=summary.read_text()
def wordcount(s):
 s=re.sub(r'```.*?```','',s,flags=re.S);s=re.sub(r'\[([^\]]+)\]\([^)]*\)',r'\1',s)
 return len(re.findall(r"\b[\w]+(?:[-’'][\w]+)*\b",s))
counts={'full_report':wordcount(text),'summary':wordcount(short),'abstract':wordcount(text.split('# Abstract\n')[1].split('# 1. Introduction')[0])}
check('Requested word limits',6000<=counts['full_report']<=10000 and 800<=counts['summary']<=1200 and 250<=counts['abstract']<=350,details=counts)
for n in range(1,6):check('Table embedded exactly: '+str(n),(O/f'Table{n}.md').read_text().strip() in text,f'Table{n}.md')
seq=''.join(x.strip() for x in (R/'sequences/SLC30A10_human_canonical.fasta').read_text().splitlines() if not x.startswith('>'))
check('Canonical target checksum quoted',sha(R/'sequences/SLC30A10_human_canonical.fasta') in text and len(seq)==485,'sequences/SLC30A10_human_canonical.fasta')
# Match biological residue tokens (positions >= 18); small symbolic graph/score names are excluded.
residue_tokens=sorted(set(re.findall(r'\b([ACDEFGHIKLMNPQRSTVWY](?:[1-9][0-9]{1,2}))(?:[ACDEFGHIKLMNPQRSTVWY])?\b',text+'\n'+short)))
residue_tokens=[s for s in residue_tokens if int(s[1:])>=18] # excludes family shorthand A10 and small symbolic identifiers
bad=[s for s in residue_tokens if int(s[1:])>485 or seq[int(s[1:])-1]!=s[0]]
check('All named biological residues match canonical numbering',not bad,'canonical FASTA',{'tokens':residue_tokens,'mismatches':bad})
ranks={r['residue']:r for r in rows('comparison/frozen_residue_ranks.tsv')}
expected={'D40':[269,21,21,5],'N127':[339,36,2,1],'D248':[461,8,1,2],'S252':[273,27,7,6],'D47':[447,9,4,4]}
for s,v in expected.items():check('Four-step trajectory '+s,[int(ranks[s]['Step%d_rank'%i]) for i in range(3,7)]==v and ('| '+' | '.join(map(str,v))+' |') in (O/'Table2.md').read_text(),'comparison/frozen_residue_ranks.tsv',v)
for s,v in {'E25':'7','S39':'14','I291':'18','C93':'28','M44':'NA'}.items():check('Reported omitted-site rank '+s,ranks[s]['Step6_rank']==v,'comparison/frozen_residue_ranks.tsv')
panel=rows('comparison/panel_experimental_status.tsv');frozen=rows('results/tables/SLC30A10_final_blind_mutation_panel.tsv')
check('Exact panel unchanged',[(r['mutation'],r['tier']) for r in panel]==[(r['mutation'],r['tier']) for r in frozen],'panel comparison + blind panel')
status={k:sum(r['classification']==k for r in panel) for k in ['confirmed hit','experimentally negative','experimentally untested']}
check('Panel outcome counts',list(status.values())==[6,1,9],'comparison/panel_experimental_status.tsv',status)
check('H244A failure preserved',any(r['mutation']=='H244A' and r['classification']=='experimentally negative' for r in panel) and 'H244A is a genuine mutation-level failure' in text,'panel outcomes')
for tier,sites in {'Tier 1':['N127','D248','D280','D47','S252'],'Tier 2':['D40','S50','N85','H244'],'Tier 3':['S282','E339','D136']}.items():
 actual=list(dict.fromkeys(r['residue'] for r in frozen if r['tier']==tier));check('Frozen '+tier,actual==sites,'blind panel',actual)
for name,expectedqc in [('data/processed/SLC30A10_orthologs_qc.json',{'sequence_count':60,'species_count':60,'length_min':393,'length_max':486,'length_median':465.0,'ambiguous_sequence_count':0,'duplicate_sequence_count':0}),('data/processed/human_SLC30_family_qc.json',{'sequence_count':10,'species_count':1,'length_min':369,'length_max':765,'length_median':445.0,'ambiguous_sequence_count':0,'duplicate_sequence_count':0}),('results/step5_model_qc.json',{'residues':485,'below70':205,'median_pLDDT':80.06}),('results/step5_analysis_qc.json',{'primary_cluster_count':2,'cavity_count':5,'triplets':0,'quadruplets':0})]:
 q=js(name);check('Numerical QC claims '+name,all(q[k]==v for k,v in expectedqc.items()),name,expectedqc)
q=js('results/step4_qc.json');check('Topology agreement and sensitivity',round(q['agreement_fraction']*485)==455 and q['top20_shared']==13,'results/step4_qc.json')
q=js('results/step3_qc.json');check('Alignment dimensions and lamprey stability',q['SLC30A10_orthologs']['alignment_length']==639 and q['human_SLC30_family']['alignment_length']==1041 and not q['sensitivity']['substantial_effect'],'results/step3_qc.json')
perms=rows('comparison/matched_null/matched_null_permutation_results.tsv');ranktests=rows('comparison/matched_null/rank_based_enrichment.tsv')
check('Permutation counts and plus-one probabilities',len(perms)==90 and len(ranktests)==72 and all(int(r['permutations'])==1000000 and math.isclose(float(r['empirical_p']),(int(r['exceedances'])+1)/1000001,rel_tol=1e-12) for r in perms+ranktests),'matched-null TSVs',{'cutoff_tests':90,'rank_tests':72,'permutations_each':1000000})
check('No NULL 5 corrected significance',all(float(r['holm_p'])>=.05 for r in perms+ranktests if r['null_model']=='5'),'matched-null TSVs')
check('Topology/chemistry A/B top10 corrected support',all(float(r['holm_p'])<.05 for r in perms if r['benchmark'] in ['A','B'] and r['null_model']=='2' and r['cutoff']=='Top 10'),'matched-null permutation TSV')
check('Confidence-matched A/B cutoff limitation',all(float(r['holm_p'])>=.05 for r in perms if r['benchmark'] in ['A','B'] and r['null_model']=='4'),'matched-null permutation TSV')
check('Confidence-matched mean-rank support',all(float(r['holm_p'])<.05 for r in ranktests if r['benchmark'] in ['A','B'] and r['null_model']=='4' and r['statistic']=='mean_frozen_rank'),'rank_based_enrichment.tsv')
uniform=rows('comparison/permutation_enrichment.tsv');check('Step7 permutation count and seed',all(r['permutations']=='100000' and r['seed']=='20260913' for r in uniform),'comparison/permutation_enrichment.tsv')
# Curated methodological quantities checked against their existing reports; no analysis re-executed.
method_sources=['reports/step3_sequence_conservation.md','reports/step4_topology_sequence_context.md','data/processed/step5_prespecified_methods.md','reports/FINAL_BLIND_PREDICTION.md','comparison/matched_null/METHODS_PRESPECIFIED.md','reports/STEP7_GROUND_TRUTH_COMPARISON.md','reports/STEP8A_MATCHED_NULL_ROBUSTNESS.md']
style={}
for label,pattern in {'unsupported_superlatives':r'\b(?:remarkable|revolutionary|astonishing)\b|AI discovered','null5_context':r'[^\n]*NULL 5[^\n]*','false_positive_context':r'[^\n]*false positives?[^\n]*'}.items():style[label]=re.findall(pattern,text+'\n'+short,flags=re.I)
check('No unsupported superlatives',not style['unsupported_superlatives'])
check('Explicit NULL5 inconclusive wording','No NULL 5 test survived multiple-testing correction' in text and 'independent statistical contribution of geometry could not be resolved' in text)
check('Untested is not disproven wording','They cannot be labeled false positives' in text and 'controls cannot establish specificity' in text)
broken=[]
for p in [report,summary]:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not target.startswith(('http://','https://','#')) and not (p.parent/target.split('#')[0]).exists() and not target.endswith('SLC30A10_TECHNICAL_REPORT_VALIDATION.json'):broken.append(target)
check('Internal artifact links',not broken,details=broken)
check('Six main figures in PNG and SVG',all((R/f'figures/technical_case_study/Figure{n}.{ext}').is_file() for n in range(1,7) for ext in ['png','svg']))
remote=js('reports/technical_case_study/remote_integrity.json')
check('Local/remote report figure hashes agree',all(sha(R/p)==h for p,h in remote['figure_sha256'].items()) and len(remote['figure_sha256'])==12,'remote_integrity.json')
check('Remote frozen manifests verified',all(not v['mismatches'] for v in remote['manifest_verification'].values()),'remote_integrity.json')
support=rows('comparison/matched_null/support_summary.tsv')
check('NULL5 support sizes and no fallbacks',all(r['distinct_possible_unordered_sets']==('2160' if r['benchmark']=='C' else '9') for r in support if r['null_model']=='5') and all(r['fallback_radius']=='0' for r in support),'support_summary.tsv')
q=js('results/step5_model_qc.json');check('Reported mean pLDDT',round(q['mean_pLDDT'],2)==67.48,'results/step5_model_qc.json')
q=js('comparison/matched_null/execution_summary.json');check('Matched-null seed and runtime',q['master_seed']==2026091308 and round(q['seconds'],1)==29.9,'execution_summary.json')
structure={r['model_chain']:r for r in rows('comparison/structural_alignment_metrics.tsv')}
check('Reported structure RMSDs',round(float(structure['9KVX_A']['TM_CA_RMSD_A']),1)==1.8 and round(float(structure['9KVY_B']['TM_CA_RMSD_A']),1)==3.2,'structural_alignment_metrics.tsv')
site={r['residue']:r for r in rows('comparison/matched_null/residue_matched_percentiles.tsv')}
check('Matched site percentiles',round(float(site['N127']['NULL4_percentile']),2)==95.45 and round(float(site['D47']['NULL4_percentile']),2)==94.44,'residue_matched_percentiles.tsv')
check('Mutation library dimensions',len(rows('results/tables/SLC30A10_mutation_prioritization.tsv'))==430 and len(set(r['residue_position'] for r in rows('results/tables/SLC30A10_mutation_prioritization.tsv')))==215,'mutation_prioritization.tsv')
assets={str(p.relative_to(R)):sha(p) for d in [O,R/'figures/technical_case_study'] for p in sorted(d.glob('*')) if p.is_file() and p.suffix in ['.py','.md','.json','.png','.svg']}
assets.update({str(p.relative_to(R)):sha(p) for p in [report,summary]})
result={'status':'PASS','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reporting_only':True,'analysis_rerun':False,'blind_checkpoint':freeze,'source_checkpoint':audit['head'],'word_counts':counts,'word_count_definition':'Unicode word tokens including numbers and table text; Markdown link destinations and fenced command blocks excluded.','manifests':manifest_results,'checks':checks,'manual_review':{'methods_and_quantities_crosschecked_against':method_sources,'all_six_figures_visually_reviewed':True,'rank_and_panel_tables_source_transcribed':True,'NULL5_context_review':'All occurrences describe diagnostic design, absent corrected significance, or inconclusive independent geometry contribution.','untested_context_review':'No untested prediction labeled a false positive; exact H244A failure preserved.','limitations':'Text interpretation and method descriptions manually audited; automated checks cover listed key quantitative claims, not semantic proof of every sentence.'},'wording_scan':style,'new_artifact_sha256':assets}
(R/'reports/SLC30A10_TECHNICAL_REPORT_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(checks),'word_counts':counts,'prior_tracked_files':len(audit['tracked_sha256'])},indent=2))
