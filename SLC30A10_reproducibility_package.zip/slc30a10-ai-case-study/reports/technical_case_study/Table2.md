| Residue | Experimental category | Step 3 | Step 4 | Step 5 | Step 6 | Blind tier |
| --- | --- | --- | --- | --- | --- | --- |
| D40 | Direct coordination | 269 | 21 | 21 | 5 | Tier 2 |
| N127 | Direct coordination | 339 | 36 | 2 | 1 | Tier 1 |
| D248 | Direct coordination | 461 | 8 | 1 | 2 | Tier 1 |
| S252 | Direct coordination | 273 | 27 | 7 | 6 | Tier 1 |
| D47 | Transport-essential, not direct ligand | 447 | 9 | 4 | 4 | Tier 1 |
