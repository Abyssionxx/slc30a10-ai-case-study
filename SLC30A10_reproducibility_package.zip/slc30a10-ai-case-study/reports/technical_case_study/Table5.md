| Limitation | Consequence for interpretation | Appropriate next test |
| --- | --- | --- |
| One retrospective target | No estimate of general-purpose performance | Independent hidden-answer transporter |
| Internal blinding and model provenance | Does not exclude pretraining exposure | External holdout and training-date audit |
| Candidate orthology | Paralogy or uneven species sampling may affect conservation | Independent phylogenetic validation |
| Single-state model and AF-initialized experimental modeling | Backbone agreement is not independent validation | Independent structural and functional assays |
| Coarse cavities and CB graph | Neighborhoods do not specify a coordination shell | Pre-specified donor geometry with uncertainty |
| Repeated and correlated features | Ablations do not uniquely assign causal credit | Independent targets and fixed comparator models |
| NULL 5: nine A/B sets | Limited ability to distinguish geometry-specific signal | Larger independent benchmark, fixed matching design |
| Small, selectively tested positive set | Known-positive fraction is not full panel precision | Test the complete proposed panel |
| Substitution-specific phenotypes | H244N/D cannot validate H244A | Evaluate exact substitutions |
| Untested candidates and controls | No positive or negative adjudication | Measure transport and expression separately |
