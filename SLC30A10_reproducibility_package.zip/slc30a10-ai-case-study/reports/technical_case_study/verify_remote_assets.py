"""Read-only remote integrity check. JSON is printed, never written remotely."""
from pathlib import Path
import hashlib,json,datetime,platform
R=Path(__file__).resolve().parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((R/'reports/technical_case_study/source_audit.json').read_text());checks={}
for name in a['manifests']:
 bad=[];n=0
 for line in (R/name).read_text().splitlines():
  if not line.strip():continue
  h,p=line.split(maxsplit=1);p=p.lstrip('* ');n+=1
  if sha(R/p)!=h:bad.append(p)
 checks[name]={'entries':n,'mismatches':bad,'manifest_sha256':sha(R/name)}
assert not any(v['mismatches'] for v in checks.values())
figs={str(p.relative_to(R)):sha(p) for p in sorted((R/'figures/technical_case_study').glob('Figure*')) if p.suffix in ['.png','.svg']}
print(json.dumps({'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hostname':platform.node(),'manifest_verification':checks,'figure_sha256':figs},indent=2))
