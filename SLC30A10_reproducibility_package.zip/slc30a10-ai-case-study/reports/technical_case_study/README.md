# Technical case-study reporting assets

These are new reporting artifacts. They do not replace or rerun Steps 1–8A.

- `Table1.md`–`Table5.md`: standalone versions of the five tables embedded in the full report.
- `build_assets.py`: reads stored TSV/JSON values and original predicted Cα coordinates; writes only new table/ledger and figure files. It does not calculate scores, ranks, permutations, structural fits, or benchmark membership.
- `claim_ledger.json`: source rows for central rank trajectories, exact panel outcomes, and matched-null results.
- `source_audit.json`: clean starting commit, manifest checks, and SHA256 snapshot of all 245 pre-existing tracked files.
- `validate_report.py`: verifies source integrity and key numerical/reporting claims without running scientific analyses.
- `remote_integrity.json`: remote manifest verification and figure hashes compared with local copies.

The report figures are `figures/technical_case_study/Figure1`–`Figure6`, each in PNG and editable SVG. Figure 1 is conceptual; Figures 2 and 4–6 transcribe stored results; Figure 3 renders unchanged AlphaFold coordinates and frozen topology/tier assignments. Plot viewing angles are presentation choices, not structure analysis or membrane orientation.

Reporting commands, executed from the project root:

```sh
python3 -B reports/technical_case_study/build_assets.py
MPLCONFIGDIR=reports/technical_case_study/render_cache OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /path/to/conda/envs/slc30a10_ai/bin/python -B reports/technical_case_study/build_assets.py --figures
python3 -B reports/technical_case_study/validate_report.py
```

The rendering command ran on `slc-server`; table preparation and validation ran locally. No software was installed. The first rendering reused the existing Matplotlib cache location; subsequent rendering used a new reporting-only cache. No prior tracked artifact changed. Runtime font caches are not report deliverables and are not committed.

The initial figure review identified arrows crossing workflow labels; routing was corrected before final validation. Figure 3 uses equal Cartesian scale. All six final PNGs were visually inspected. The residue-token validator excludes the family shorthand A10 and small symbolic identifiers; biological residue identities are checked against the frozen canonical sequence. These are reporting implementation checks, not changes to prior analysis.

Word counts exclude fenced command blocks and Markdown link destinations, and include table text and numerical tokens. The validation JSON describes the automated checks and the scope of manual numerical/method review. It is an audit record, not a proof of every scientific interpretation.
