# Blind computational prioritization of the Mn2+ transport site in human SLC30A10 using evolutionary, membrane-topology and structure-aware modeling

# Abstract

Identifying transport-critical residues in membrane proteins requires distinguishing conserved structural features from chemistry that may support substrate interaction and transport. Human SLC30A10, a manganese efflux transporter, provides a concrete test of whether an interpretable computational workflow can reduce a full protein sequence to useful mutagenesis hypotheses. We implemented an AI-assisted, human-defined workflow using a frozen canonical sequence, candidate vertebrate orthologs, human SLC30 paralogs, independent membrane-topology predictions, residue chemistry, and an AlphaFold Database model. Sequence, topology, structure, and mutation-priority scores were retained separately. Predictions and a 16-substitution panel were frozen with SHA256 manifests and a Git checkpoint before the target experimental paper was accessed within the workflow. This information-blind design was conducted retrospectively, after the paper’s publication, and does not establish historical independence of pretrained models.

Ground-truth disclosure showed that all four experimentally identified Mn2+-coordinating residues occurred within the first six eligible positions in the frozen mutation ranking. The panel also contained the additional narrowly defined transport-essential residue D47. Sequence-specificity ranks alone were poor for the four coordinators; topology and physicochemical context produced the first substantial improvements, followed by structural-network and mutation-level prioritization. Six proposed substitutions at five sites had supported disruptive effects, H244A was experimentally unchanged, and nine substitutions remained untested.

Enrichment persisted after topology and chemistry matching: top-10 recovery of coordinating and transport-essential sites survived Holm correction. Evidence became weaker under increasingly strict matching. Conservation- and confidence-matched rank tests retained support, whereas corrected cutoff results were limited. The independent contribution of geometry under the diagnostic NULL 5 was inconclusive: no corrected test was significant, and only nine matched sets were possible for the two narrow benchmarks. The workflow also failed to identify a complete coordination constellation under its fixed geometric criterion. These results support reproducible candidate prioritization, rather than mechanistic proof, calibrated mutation prediction, or general performance across transporters.

# 1. Introduction

Human SLC30A10 mediates Mn2+ efflux, making its transport-related molecular features a useful target for computational hypothesis generation. A residue-level prediction is more demanding than recognizing that a protein is a membrane transporter. A useful workflow must distinguish positions that are merely conserved, buried, or hydrophobic from positions whose substitution is likely to perturb substrate interaction or transport. It must also distinguish direct coordination from supporting roles in packing, hydrogen-bond networks, accessibility, and conformational change. The experimental reference used after disclosure was the study by [Shen and colleagues, *Nature Communications* (2025)](https://www.nature.com/articles/s41467-025-63616-7). Biological statements attributed to that study in this report are post-disclosure evidence, not inputs to the blind ranking.

Evolutionary information offers a natural starting point. Conservation among homologous proteins can identify positions under constraint, but the reason for that constraint is often ambiguous. A conserved position may stabilize a fold, preserve an interaction, or participate in transport. Conversely, a position that differs between related transporters may reflect substrate specialization, lineage-specific regulation, or less consequential divergence. Comparing conservation within candidate orthologs with differences across paralogs therefore provides useful context, but does not by itself identify an ion-binding site. In particular, a transport determinant shared across a family may score poorly on a measure explicitly rewarding family divergence.

Membrane topology and residue chemistry can narrow the hypothesis space. Polar groups located within or near a hydrophobic membrane segment are plausible participants in aqueous pathways and polar networks. These are broad biological priors, however, and a ranking based on them should be compared with similarly plausible membrane-associated residues. Predicted three-dimensional structures add spatial relationships that sequence adjacency cannot capture. They may reveal contacts between different helices or suggest internal voids, but model confidence, conformational state, and simplified geometric assumptions constrain interpretation.

An AI4Science case study should also make its information flow inspectable. Reading an experimental answer first and subsequently assembling a plausible computational explanation is different from generating a fixed prediction before disclosure. Here, the target paper, reported mutations, disease variants, experimental SLC30A10 structures, and residue-level functional annotations were prohibited during Steps 1–6. The resulting rankings and mutation panel were then frozen. Ground-truth extraction and statistical evaluation occurred in separate stages and directories.

This arrangement provides a prospective-style test within a retrospective case study. It is not a claim that the predictions preceded publication of the experimental work, nor that a coding agent or pretrained structural model had no possible prior exposure to related biology. The computational question is narrower: can a reproducible workflow combining evolutionary information, membrane topology, residue chemistry, and predicted spatial context prioritize experimentally important SLC30A10 residues without consulting the target paper during prediction generation?

# 2. Study design and blind-analysis framework

The workflow separated prediction, disclosure, and retrospective evaluation. Step 1 resolved and froze a canonical protein sequence. Step 2 constructed distinct candidate-ortholog and human-paralog datasets. Step 3 aligned those datasets separately and quantified within-ortholog conservation and family-level specificity. Step 4 added two sequence-based topology predictions and local physicochemical features. Step 5 used a sequence-predicted structure to describe confidence, polar neighborhoods, and geometry-defined cavities. Step 6 translated the accumulated evidence into residue hypotheses and a mutation panel. Step 7 compared unchanged predictions with experimental evidence. Step 8A evaluated robustness against increasingly restrictive matched nulls.

![Figure 1. Blind workflow and disclosure design.](../figures/technical_case_study/Figure1.png)

**Figure 1.** Conceptual workflow from canonical sequence to matched-null evaluation. Ortholog and paralog data were maintained separately even though they contributed to a combined specificity measure. The freeze separates prediction generation from access to the target paper. The arrows summarize information flow; they do not imply that every adjacent operation generated an independent evidence source.

The conceptual pipeline was: canonical sequence → ortholog dataset → paralog dataset → sequence conservation → membrane topology → residue chemistry → AlphaFold DB structure → polar clusters and cavities → mutation prioritization → frozen predictions → ground-truth reveal → matched-null benchmark. Each new score supplemented rather than overwrote its predecessor. Thus, a later successful rank does not erase an earlier unsuccessful rank, and retrospective diagnostics can examine where a site entered the candidate set.

Raw database responses, predictor outputs, model files, command logs, processed tables, and reports were retained. SHA256 checksums identify exact file contents, while Git records the committed state. The immutable blind checkpoint is `008b7ad7a436fc02898292ec7d0441cf0df6c390`. The lock records a UTC freeze time of `2026-09-13T09:18:36.523132+00:00`; it references the preceding checkpoint, with the subsequent commit containing the lock itself. Step 7 records pre-access verification before source retrieval. The matched-null checkpoint is `5af7e3e53e36e91f47c884da9932e37aa4b44f05`.

These mechanisms support auditing and reproducibility. They do not prevent a malicious actor from editing files, replacing manifests, or rewriting repository history. Nor does a checksum establish what a model knew during training. The evidential claim is that the preserved workflow records distinguish the files generated before and after disclosure, and that the present report leaves both sets unchanged. The target paper was published in September 2025, whereas the internal freeze occurred in September 2026. Consequently, “blind” refers to the documented information restrictions during this computational exercise, not to historical priority.

The computing architecture also supported traceability. A local Mac held the working repository; scientific execution occurred on a Linux server through SSH alias `slc-server`, in a project-specific Conda environment. Synchronization and checksum comparisons connected local and remote artifacts. MAFFT used at most eight threads; later lightweight statistical evaluation used one thread. Codex served as the coding and analysis agent implementing a human-defined workflow. This report attributes the result to that AI-assisted computational process, not to an autonomous scientist or an independently demonstrated language-model inference of a binding site.

One procedural qualification is relevant to preregistration language. Mutation classes and score formulas were specified before their final ranks were inspected, but negative-control selection underwent a documented correction before freezing. Initial control candidates did not satisfy the intended low-priority condition and were replaced. The ranking and tier assignments were not refitted. This report therefore describes a frozen blind workflow with pre-specified scoring, rather than claiming that every implementation and panel-selection decision was fixed before any output inspection.

# 3. Results

## 3.1 A frozen canonical SLC30A10 input and comparative sequence dataset

The sequence query resolved UniProt accession **Q6XR72**, a reviewed canonical human SLC30A10 entry containing **485 amino acids**. The accession was selected from a database query rather than hard-coded from prior biological knowledge. The FASTA contained exactly one record, standard amino acids, and no stop or ambiguous symbols. Its SHA256 was `6a297b6de2a94fb567e5eb450032cd90807705ab8eef5fc0727136b15a9c9448`; local and remote verification agreed. This exact sequence remained the numbering reference for every later residue table and structural comparison.

The comparative dataset comprised **60 candidate SLC30A10 orthologs from 60 species**, with lengths of 393–486 residues and a median of 465. Sampling included mammals, ray-finned fishes, birds, lepidosaurs, turtles, an amphibian, a crocodilian, and a cyclostome. Twenty-eight sequences were mammalian; the remainder extended coverage beyond closely related mammalian proteins. Only two entries were reviewed, so “candidate orthologs” is the appropriate description: gene-based retrieval and sequence QC did not establish orthology through a reconciled phylogeny.

The separate human family dataset contained the ten reviewed SLC30A1–A10 paralogs. Their length range, 369–765 residues, was broader than that of the candidate orthologs. Family members were retained without filtering on known metal specificity. Both datasets had unique accessions, no ambiguous sequences, and no identical sequence duplicates. Species uniqueness was required for the ortholog set, not for the deliberately human-only family set.

**Table 1. Frozen datasets and quality control.**

| Dataset or QC item | Frozen result | Interpretive boundary |
| --- | --- | --- |
| Canonical human input | UniProt Q6XR72; reviewed canonical; 485 aa; one record | Sequence-only database fields |
| Candidate orthologs | 60 sequences; 60 species; 393–486 aa; median 465 aa | Gene-based candidates, not tree-validated orthology |
| Vertebrate coverage | 28 mammals; 10 ray-finned fishes; 8 birds; 7 lepidosaurs; 4 turtles; 1 amphibian; 1 crocodilian; 1 cyclostome | Diverse sampling, not phylogenetic weighting |
| Human SLC30 family | 10 reviewed paralogs; one species; 369–765 aa; median 445 aa | Separate family comparison |
| Sequence integrity | No ambiguous residues or duplicate sequences in either dataset; unique accessions | Species unique only for ortholog set |
| Ortholog / family MSA | 60 × 639 / 10 × 1,041 alignment columns | All input sequences preserved ungapped |
| Lamprey exclusion sensitivity | Identity Spearman 0.998345; specificity Spearman 0.999815 | Fixed alignment; no realignment |
| Topology agreement | 455/485 positions (93.8%); six helices | 30 boundary disagreements |
| Predicted model | 485/485 residues; mean pLDDT 67.48; median 80.06; 205 below 70 | Full coverage is not uniformly high confidence |

Removing the uncertain sea-lamprey candidate A0ACM8BIL7 from the fixed ortholog alignment had little effect on the principal sequence signal. Ortholog identity retained Pearson correlation 0.999614 and Spearman correlation 0.998345; its maximum absolute change was 0.02462. Specificity retained Spearman correlation 0.999815, and no specificity position shifted by more than ten percentile points. Two positions exceeded that threshold for identity percentiles. The pre-specified substantial-effect rule was not triggered, so the lamprey candidate remained in the primary analysis. This sensitivity test addresses membership in a fixed alignment, not the effect of realigning the remaining sequences.

## 3.2 Sequence specificity alone did not recover the central transport site

Step 3 quantified ortholog conservation separately from family divergence. The specificity score multiplied ortholog coverage and identity by other-paralog coverage and one minus identity across the nine non-SLC30A10 family members. It therefore favored positions conserved in candidate SLC30A10 orthologs but different in the other human SLC30 proteins. This is an interpretable specialization hypothesis, not a general score for transport importance.

For retrospective illustration, four sites later identified experimentally had frozen Step 3 ranks of **269 for D40, 339 for N127, 461 for D248, and 273 for S252**. These names are annotations added after disclosure; they were not used to choose or tune the score. Their experimental status is introduced formally in Section 3.6. All four had ortholog identity 1.0, demonstrating that the poor ranks reflected the family-specificity criterion rather than lack of evolutionary conservation. D47 similarly ranked 447 despite ortholog identity 0.90.

The result is a substantive limitation of the sequence-only hypothesis. A residue can be essential to transport while sharing chemistry with other family members. Rewarding divergence may instead elevate lineage-specific loops or other specialized features. Step 3 remained useful as a separate evidence track and generated exploratory candidates, but its specificity ranking did not locate the subsequently revealed central site. The score was preserved unchanged rather than retrospectively redefined as a pure conservation measure.

## 3.3 Membrane topology and physicochemical constraints substantially narrowed the search

Phobius and SCAMPI each predicted six transmembrane helices. Phobius ranges were **12–32, 44–61, 82–105, 117–145, 241–266, and 278–299**; SCAMPI ranges were **8–28, 42–62, 86–106, 121–141, 245–265, and 279–299**. The strict intersection was **12–28, 44–61, 86–105, 121–141, 245–265, and 279–299**. The predictors agreed on TM status at **455 of 485 positions, or 93.8%**, leaving 30 boundary disagreements.

The topology-aware score combined conservation, the unchanged specificity score, membrane proximity, broad chemical plausibility, and local polar density. Acidic and histidine positions received a stronger chemical prior than hydrophobic positions. Non-TM positions far from a boundary were downweighted, particularly in long non-TM sequence runs. This did not constitute a disorder prediction: run length was a sequence-context proxy.

The retrospective trajectories show the first major narrowing of the search. D40 improved from 269 to 21, N127 from 339 to 36, D248 from 461 to 8, and S252 from 273 to 27. D47 improved from 447 to 9. These changes arose before the experimental labels were available within the workflow. They show the value of combining conservation with membrane-associated chemistry, but do not establish an independent statistical contribution from every component of the multiplicative score.

Boundary uncertainty mattered. Rankings calculated using strict and union topology masks had Spearman correlation 0.9701, yet shared only 13 of their top 20 positions. High global correlation therefore did not imply complete stability of a small experimental panel. The strict topology later categorized D40 near a boundary rather than within a core helix, influencing its hypothesis group and tier. Boundaries were not adjusted using the experimental structure.

![Figure 2. Frozen ranking trajectories.](../figures/technical_case_study/Figure2.png)

**Figure 2.** Stored ranks for five sites selected for visualization after ground-truth disclosure. Lower ranks are better; the logarithmic axis preserves visibility of both poor initial and high final ranks. Steps 3–5 rank all 485 positions, whereas Step 6 ranks 215 mutation-eligible sites. The plot is a transcription of frozen ranks, not a new scoring analysis.

## 3.4 Three-dimensional structural context concentrated candidates into polar networks

Step 5 used AlphaFold DB model **AF-Q6XR72-F1, version 6**, with complete sequence and residue-number agreement across 485 positions. Confidence was heterogeneous: mean pLDDT was **67.48**, median **80.06**, and **205 residues were below 70**. Full sequence coverage should therefore not be read as a uniformly reliable structural model. The membrane core was generally better supported than many extended regions, although individual segments and candidates still had local uncertainty.

A fixed proximity graph identified **two cross-helix polar clusters**. The larger cluster contained 16 residues spanning several helices, while the second comprised T258 and D280. The primary graph connected representative side-chain positions within 6 Å, requiring a cluster to include at least two actual TM helices. Such connected components can be extended networks: the larger cluster’s maximum pairwise separation was 29.24 Å. Membership did not imply that all residues directly contacted one another or a common ion.

A geometry-only grid fallback identified **five pockets** because a suitable dedicated cavity package was unavailable. The structure-aware score combined conserved and topology-supported positions with cross-helix polar neighbors, cluster membership, cavity lining, and model confidence. N127 moved from Step 4 rank 36 to Step 5 rank 2, D248 from 8 to 1, and S252 from 27 to 7. D40 remained at rank 21. These differences demonstrate that spatial context promoted some candidates more strongly than others.

The negative geometric result is equally important: **no triplet or quadruplet satisfied the pre-specified all-pairs 6 Å coordination-constellation criterion**. The workflow did not identify a complete compact ligand assembly under its own rule. That criterion was not relaxed after the experimental answer was known. Connected-network recovery and coordination-shell recovery are different outcomes, and only the former was obtained.

The model represented a single predicted conformation without an explicit Mn2+ ion, membrane simulation, or side-chain relaxation around a metal. Grid pockets represented probe-center voids rather than validated physical cavity volumes. These simplifications made the computation lightweight and reproducible, but limited its capacity to identify exact ion geometry, conformational energetics, or transport pathways.

![Figure 3. Frozen topology and model context.](../figures/technical_case_study/Figure3.png)

**Figure 3.** Original AlphaFold coordinates and strict sequence-derived TM segments, with frozen Tier 1 and Tier 2 candidates. The full-chain Cα trace includes low-confidence regions; this is a visual context display, not an experimental membrane orientation or a structural fit. The sequence panel shows the topology assignments that informed blind grouping. No experimental ligand annotation enters this figure.

## 3.5 Blind mutation prioritization produced a compact experimental panel

Step 6 converted residue evidence into mechanistically interpretable substitutions. Alanine substitutions tested removal of side-chain functionality, while selected amide or conservative substitutions offered chemically narrower contrasts. The score favored conserved, structurally supported sites whose proposed substitutions removed plausible polar or ion-interacting functionality. It did not predict quantitative transport rates or assert that a candidate directly bound manganese.

Three hypothesis groups were retained. Group 1 emphasized possible direct ion interaction at conserved internal TM polar sites. Group 2 represented possible transport networks and cross-helix connections, including near-boundary positions. Group 3 retained SLC30A10-specific regulatory or specificity hypotheses outside the central structural network. Separating these groups prevented a single score from silently equating coordination, network support, and regulation, although the grouping rules also constrained panel selection.

The frozen tiers were **Tier 1: N127, D248, D280, D47, S252; Tier 2: D40, S50, N85, H244; Tier 3: S282, E339, D136**. Negative-control positions were **S56 and T90**. The final panel contained 16 substitutions at 14 positions: N127A, D248A, D280A, D47A, S252A, D40A, S50A, N85A, H244A, S282A, E339A, D136A, D248N, D280N, S56T, and T90S. The controls tested conservative changes; they were not assumed experimentally inert.

The archived control-selection correction replaced I291V and L89I because their mutation-priority standing was inconsistent with the intended low-priority controls. The corrected selection used conservative mutations in well-modeled TM contexts from the lower part of the matched mutation distribution. This change occurred before the blind freeze, was preserved in the record, and did not alter primary scores or tiers. It limits any claim of complete panel-rule preregistration but does not invalidate the subsequent frozen-panel comparison.

Frozen leave-one-layer analyses showed high overall rank stability: Spearman correlations were approximately 0.99996 without specificity, 0.94007 without topology, 0.99924 without cluster evidence, and 0.99893 without cavity evidence. Top-10 overlaps were 10, 9, 8, and 7, respectively. These are sensitivity results for the specified scoring implementation; correlated upstream features remained, so they are not fully independent causal ablations.

The predictions, panel, reports, and supporting files were frozen **before the target paper was read within the workflow**. The subsequent comparisons below use those unchanged outputs. Neither successful experimental overlap nor failures were used to revise the panel.

## 3.6 Ground-truth disclosure revealed recovery of all four experimentally identified Mn2+-coordinating residues

After integrity checks, the target paper and supplementary sources were read and curated. The experimental study identified **D40, N127, D248, and S252** as Mn-coordinating residues. All four occurred within the **first six distinct Step 6 residues**. D47, an additional transport-essential site in the narrow assay benchmark, was also in the final prediction panel but was not classified as a directly coordinating ligand.

**Table 2. Experimentally validated residues and frozen computational ranks.**

| Residue | Experimental category | Step 3 | Step 4 | Step 5 | Step 6 | Blind tier |
| --- | --- | --- | --- | --- | --- | --- |
| D40 | Direct coordination | 269 | 21 | 21 | 5 | Tier 2 |
| N127 | Direct coordination | 339 | 36 | 2 | 1 | Tier 1 |
| D248 | Direct coordination | 461 | 8 | 1 | 2 | Tier 1 |
| S252 | Direct coordination | 273 | 27 | 7 | 6 | Tier 1 |
| D47 | Transport-essential, not direct ligand | 447 | 9 | 4 | 4 | Tier 1 |

The evidence categories must remain distinct. Benchmark A contains four directly demonstrated coordinators. Benchmark B contains five residues whose individually tested mutations were described as abolishing transport: the four coordinators plus D47. Benchmark C contains eleven individually mutation-sensitive residues under the Step 7 curated definition, including partially impaired and substitution-dependent effects. Structural proximity, disease association, and combination-only experiments were not silently added to these positive sets.

Tier 1 recovered **four of five transport-essential sites**, giving 80% recall of Benchmark B and a 4/5 known-positive fraction within that tier. It contained three of the four direct coordinators; D40 was in Tier 2. Tier 1 plus Tier 2 recovered all five essential sites and all four coordinators, with known-positive fractions of 5/9 and 4/9, respectively. These fractions are not fully measured precision because several selected sites remain untested.

The distinction between rank and tier is informative. D40 was fifth in the mutation ranking but assigned to Tier 2 because of its boundary-based hypothesis group. D280 was Tier 1 and ranked highly, yet remained experimentally untested in the reference. The workflow successfully proposed useful substitutions without perfectly separating direct ligands from other transport hypotheses.

![Figure 4. Recovery at fixed cutoffs.](../figures/technical_case_study/Figure4.png)

**Figure 4.** Recall of the four-site coordination and five-site transport-essential benchmarks at stored cutoffs and tiers. Labels give recovered sites divided by benchmark size, not the number tested in the prediction set. Top 5 and Tier 1 have equal benchmark recovery but are distinct frozen sets.

**Table 3. Final blind mutation panel compared with exact experimental substitutions.**

| Mutation | Frozen tier | Predicted effect | Experimental effect | Assessment |
| --- | --- | --- | --- | --- |
| N127A | Tier 1 | strong | abolished | confirmed hit |
| D248A | Tier 1 | strong | abolished | confirmed hit |
| D280A | Tier 1 | strong | not tested | experimentally untested |
| D47A | Tier 1 | strong | abolished | confirmed hit |
| S252A | Tier 1 | strong | abolished | confirmed hit |
| D40A | Tier 2 | strong | abolished | confirmed hit |
| S50A | Tier 2 | strong | not tested | experimentally untested |
| N85A | Tier 2 | strong | not tested | experimentally untested |
| H244A | Tier 2 | strong | unchanged | experimentally negative |
| S282A | Tier 3 | strong | not tested | experimentally untested |
| E339A | Tier 3 | moderate | not tested | experimentally untested |
| D136A | Tier 3 | strong | not tested | experimentally untested |
| D248N | Tier 1 | strong | abolished | confirmed hit |
| D280N | Tier 1 | strong | not tested | experimentally untested |
| S56T | control | weak | not tested | experimentally untested |
| T90S | control | weak | not tested | experimentally untested |

The six supported substitutions represent five sites because both D248A and D248N were proposed and supported. Seven panel substitutions had directly comparable experimental outcomes: six disruptive and one unchanged. Agreement within this selected tested subset cannot estimate performance for the nine untested substitutions, nor the prospective probability of success for a new candidate.

## 3.7 Uniform-random enrichment was strong but represented a permissive null model

Against the narrow transport-essential benchmark, frozen top-5, top-10, and top-20 recovery was **4/5, 5/5, and 5/5**. Uniform sampling from all 485 positions gave enrichment factors of **77.6×, 48.5×, and 24.25×**. In Step 7, 100,000 random sets produced no recovery at least as strong as the observed counts at these cutoffs. The plus-one empirical probability was approximately 1 × 10⁻⁵, reflecting Monte Carlo resolution rather than a zero probability.

This comparison is useful as a baseline but permissive. A random residue drawn from the whole protein can lie in an extended low-confidence region, have chemistry unlike an ion-interacting side chain, or sit far from the membrane core. The blind workflow deliberately used precisely such biological distinctions. Strong uniform enrichment therefore cannot establish that the final ranking outperformed knowledgeable selection of polar residues near TM helices.

The 77.6-fold value is consequently not the final statistical claim. It describes a specific top-5 comparison to a broad reference distribution. Step 8A addressed the more demanding question: whether recovery persisted among residues matched for progressively more plausible prior features, while keeping both the predictions and experimental benchmark unchanged.

## 3.8 Matched-null testing showed enrichment beyond simple topology and chemistry priors

The matched-null design compared surrogate experimental sets with the fixed Step 6 ranking. NULL 0 sampled all 485 residues. NULL 1 restricted the pool to 178 TM or within-five-boundary positions. NULL 2 further restricted it to 49 positions with D, E, H, N, Q, S, T, C, or Y chemistry. NULL 3 matched each experimental site’s global ortholog-conservation quintile within that pool. NULL 4 additionally matched pLDDT category. NULL 5 was diagnostic: it matched topology class, broad chemical class, conservation bin, confidence bin, and Step 4 transport-score quintile without using Step 5 geometry variables.

Every reported Step 8A test used **1,000,000 accepted permutations**. Draws were shared across endpoints for each benchmark/null combination, creating correlated tests rather than independent biological replicates. Holm correction was applied separately to 75 primary cutoff tests and 15 diagnostic cutoff tests; rank-based tests had separate primary and diagnostic families. All numerical probabilities below are stored results, not new simulations.

**Table 4. Top-10 matched-null results for the narrow benchmarks.** A denotes direct coordinators; B denotes transport-essential sites. Observed recovery is four for A and five for B. Raw probabilities use plus-one correction; Holm families differ for NULL 5.

| Benchmark | Null | Observed top-10 hits | Expected | Fold | Raw p | Holm-adjusted p |
| --- | --- | --- | --- | --- | --- | --- |
| A | 0 | 4 | 0.082 | 48.60 | 9.99999e-07 | 7.49999e-05 |
| A | 1 | 4 | 0.225 | 17.77 | 5.99999e-06 | 0.000318 |
| A | 2 | 4 | 0.817 | 4.90 | 0.001014 | 0.03686 |
| A | 3 | 4 | 1.523 | 2.63 | 0.011895 | 0.22972 |
| A | 4 | 4 | 1.616 | 2.48 | 0.018221 | 0.24376 |
| A | 5 | 4 | 2.667 | 1.50 | 0.11124 | 1 |
| B | 0 | 5 | 0.103 | 48.41 | 9.99999e-07 | 7.49999e-05 |
| B | 1 | 5 | 0.282 | 17.76 | 9.99999e-07 | 7.49999e-05 |
| B | 2 | 5 | 1.022 | 4.89 | 0.000128 | 0.00550399 |
| B | 3 | 5 | 1.667 | 3.00 | 0.00161 | 0.0547399 |
| B | 4 | 5 | 1.839 | 2.72 | 0.004089 | 0.110403 |
| B | 5 | 5 | 3.666 | 1.36 | 0.11102 | 1 |

Topology-only matching retained approximately 17.8-fold top-10 enrichment for both narrow benchmarks. With topology and chemistry matching, enrichment was approximately **4.90-fold**, and top-10 recovery survived Holm correction: adjusted p = **0.0369 for A** and **0.00550 for B**. The result therefore exceeds a baseline consisting simply of ion-interacting residue types near transmembrane segments.

Conservation matching weakened cutoff-based support. Under NULL 3, Benchmark B retained corrected support at top 5, Tier 1, and Tier 1 plus Tier 2, but its top-10 adjusted p was 0.0547. No Benchmark A cutoff survived the primary correction. Rank-based evidence was stronger: mean-rank and normalized-loss tests retained support for both narrow benchmarks, as did their mean reciprocal ranks under NULL 3.

Adding confidence matching further limited corrected cutoff claims. Under NULL 4, no A/B cutoff survived the 75-test correction. However, mean-rank and normalized-loss tests remained significant after their separate correction, with adjusted mean-rank p approximately **0.0390 for A** and **0.00572 for B**. Benchmark B mean reciprocal rank also retained support, whereas the corresponding Benchmark A adjusted value, approximately 0.0570, did not. “Robust under confidence matching” must therefore specify the endpoint rather than imply that every test remained significant.

N127 and D47 had the highest residue-wise NULL 4 standings, approximately the **95.45th and 94.44th percentiles**. D248, D40, and S252 followed at 86.36, 83.33, and 72.22. These are descriptive positions within small matched reference pools, not independently corrected site-level significance tests. Their discretization is part of the uncertainty.

**No NULL 5 test survived multiple-testing correction.** For A and B, only **nine distinct matched sets** were possible. D40 and D248 were forced by singleton strata; Benchmark B additionally forced D47. Only the slots corresponding to N127 and S252 had three alternatives each. Every possible A/B NULL 5 set was already within the frozen top 20, making that endpoint uninformative. One million draws estimate this small distribution precisely but do not create additional biological alternatives.

The independent statistical contribution of geometry could not be resolved under this strictest design because the eligible matched space became extremely small. Failure to reject NULL 5 is not evidence that geometry had no value. Conversely, earlier ranking improvements do not prove an independent geometry contribution. The available evidence supports performance beyond simple topology and chemistry priors, but does not establish that every added layer contributed independent information.

Benchmark C adds a further qualification: M44 and I291 fall outside the fixed NULL 2–4 chemistry pool. Those tests retained all eleven benchmark sites and explicitly flagged the support mismatch. They should not be treated as fully exchangeable chemistry-matched comparisons. NULL 5 had 2,160 possible C sets and no corrected significance. The narrow A/B results therefore provide the clearest matched-background interpretation.

![Figure 5. Matched-null robustness.](../figures/technical_case_study/Figure5.png)

**Figure 5.** Stored top-10 enrichment and raw versus Holm-adjusted probabilities for A and B. The two correction families are identified explicitly. The decreasing fold enrichment reflects increasing null expectations, not a measured fraction of causal explanatory power. NULL 5 is marked as diagnostic and sparse.

## 3.9 Error analysis identifies both genuine failures and unresolved predictions

H244A is a genuine mutation-level failure. The blind panel predicted a strong effect, whereas the experimental assay reported unchanged transport. Other H244 substitutions impaired transport, but they do not validate the alanine prediction. The residue’s presence in the broader mutation-sensitive benchmark must not be used to conceal this exact-substitution disagreement. Chemistry, cluster membership, and cavity proximity were insufficient to determine the consequence of removing this side chain.

Several experimentally affected sites were omitted from the final panel. E25 ranked seventh in Step 6, making it a panel-selection miss rather than a low-ranking failure. S39 ranked fourteenth and I291 eighteenth; both were excluded by the compact group-based selection. C93 ranked twenty-eighth, outside the top 20. M44 had no Step 6 rank because it did not pass mutation eligibility, despite Step 5 rank 48. Its hydrophobic supporting role illustrates how chemistry-centered gates can miss second-shell contributions.

D280, S50, N85, S282, E339, and D136 remain **experimentally untested predictions** for the proposed substitutions in the target paper. D280A and D280N test the separate small polar cluster; S50A and N85A test the larger network; S282A, E339A, and D136A represent exploratory specificity hypotheses. Their ranking drivers are inspectable, but their biological outcomes are unresolved. They cannot be labeled false positives merely because the paper did not assay them.

The two controls, S56T and T90S, also remain untested. A weak-effect prediction is not a validated negative control until measured. Thus, the report neither counts controls as successful predictions nor merges them with experimentally unchanged H244A. The experimental panel remains incomplete as a test of specificity, sensitivity, and negative predictive performance.

![Figure 6. Exact-substitution error analysis.](../figures/technical_case_study/Figure6.png)

**Figure 6.** Six supported disruptive substitutions, one experimentally negative disruptive prediction, and nine untested substitutions. Experimental status is assigned to the exact mutation. The figure preserves the original predicted qualitative effects, including the H244A disagreement and unvalidated control predictions.

## 3.10 Predicted and experimental structures show partial agreement but are not an independent benchmark

The Step 7 comparison aligned unchanged model coordinates to experimental structures using shared residue numbers and separately fitted strict TM Cα atoms. The AlphaFold model had approximately **1.8 Å TM-domain RMSD** to the inward-facing state and **3.2 Å** to the outward-facing protomer. The corresponding shared-Cα values were about 2.2 and 4.0 Å. Experimental protomers resolved only 288–295 residues, so these are not full-length 485-residue RMSDs.

The four coordinating residues belonged to the same frozen polar network, but their representative-atom separations ranged from 4.74 to 9.47 Å. The model placed them in a common neighborhood without reproducing precise Mn-binding geometry. Frozen cavity V4 included N127 and D248 as lining residues but not D40 or S252; its nearest probe center remained approximately 7.25 Å from the experimental Mn position after alignment. Cavity overlap therefore did not accurately localize the ion.

The comparison also has an important dependence: the experimental structural modeling used **AlphaFold2 initialization** before map-based refinement. Predicted-versus-experimental backbone similarity is consequently not an independent validation of the AlphaFold model. It is useful for describing conformational resemblance and local discrepancies, but should not be promoted as a separate major prediction success. The blind single-state workflow did not predict the observed inward/outward transition or helix movements.

# 4. Discussion

## 4.1 What worked?

The strongest result was practical prioritization. A 485-residue protein was reduced to a compact panel containing all four subsequently disclosed coordinating-site alanine substitutions, plus D47A and the D248N contrast. This is a useful experimental starting point even though the workflow did not determine the complete mechanism. The information separation and retained intermediate scores make that outcome more interpretable than an explanation assembled after reading the experimental answer.

Topology and chemistry produced the first large improvements for the eventual experimental sites. Structural context then concentrated several conserved polar positions into a cross-helix neighborhood. Mutation-level chemical loss promoted D40 into the top six despite its strict-boundary classification. Different sites benefited at different stages, arguing for retaining multiple evidence views rather than treating the final score as a complete explanation.

Matched-null testing strengthens the conclusion beyond whole-protein random enrichment. Recovery exceeded selection among membrane-associated positions with a fixed ion-interacting chemistry set. This is more informative than stating that the workflow favored plausible residues over arbitrary positions. Nevertheless, complementary evidence sources are not statistically independent: conservation recurs in several formulas, and topology constrains both graph construction and subsequent scoring.

## 4.2 What did not work?

Sequence specificity alone was a weak locator of the central site. The complete geometric coordination constellation was not recovered, and the cavity detector did not locate the experimental metal position accurately. H244A was a concrete false expectation for an exact substitution. E25 was highly ranked but lost during quota-based panel selection, while M44 was excluded by eligibility rules emphasizing polar networks. These failures address different parts of the workflow and should not be combined into a single accuracy number.

Frozen ablations further constrain interpretation. Removing specificity left narrow-benchmark cutoff recovery unchanged. Removing cluster evidence reduced top-10 coordinator recovery from four to three and essential-site recovery from five to four, with S252 dropping below the cutoff. Removing cavity evidence improved coordinator top-5 recovery from three to four while leaving essential top-10 recovery unchanged. The cavity contribution was therefore not uniformly beneficial. These are retrospective observations from already-frozen sensitivity outputs; none was used to optimize the primary ranking.

## 4.3 What does the matched-null analysis change?

The defensible interpretation is: **the frozen ranking remained enriched against biologically matched backgrounds, but support weakened with increasingly strict matching and did not establish an independent geometry effect**. This replaces a headline centered on “77-fold better than random” with a conditional statement tied to explicit reference populations and correction families.

Under topology and chemistry matching, top-10 recovery remained significant after correction. Under conservation and confidence matching, support depended on whether recovery was summarized by a cutoff or the ranks of the whole benchmark. Under NULL 5, forced matches and a tiny combinatorial space sharply limited discrimination. It would be incorrect either to treat its nonsignificance as proof of no geometry contribution or to dismiss it and claim geometry was independently validated.

The null expectations also show how much the baseline matters. For direct coordinators, expected top-10 recovery rose from 0.082 under NULL 0 to 1.616 under NULL 4 and 2.667 under NULL 5, against four observed. These are conditional expectations, not percentages of success explained. Coarse matching, score eligibility, correlated features, and small positive sets prevent a numerical decomposition of predictive credit.

## 4.4 Could this workflow have suggested useful experiments prospectively?

Yes, in the restricted sense of suggesting a compact, testable panel. The frozen list contained substitutions at all four experimentally identified coordinators and the additional essential D47 site before target-paper disclosure within this exercise. It also proposed untested network and specificity candidates whose outcomes remain falsifiable. The workflow would have provided an organized experimental agenda rather than an exhaustive scan of every residue.

No, it could not establish which residues directly coordinate manganese from ranking alone. D47 was placed in the direct-interaction hypothesis group without being an experimental ligand, while D40 was relegated to a network-oriented tier by a topology boundary. A disruptive mutation could affect folding, expression, trafficking, or conformational coupling rather than direct ion binding. Appropriate experimental controls and orthogonal structural or biochemical evidence remain necessary.

## 4.5 Generalization

This is one retrospectively selected transporter, evaluated against a small and selectively assayed positive set. It does not establish general-purpose accuracy, calibrated confidence, or reliable negative prediction. The use of a language-model coding agent also does not isolate a contribution from the language model’s biological reasoning; substantial evidence came from conventional sequence analysis, topology prediction, AlphaFold coordinates, and explicitly programmed statistical calculations.

The appropriate next test is to apply the frozen workflow without retuning to an independent transporter whose experimental answer remains hidden until predictions are locked. That study should define the assay endpoint, exact mutation panel, matched backgrounds, and information restrictions in advance. Any future improvements motivated by this case must be evaluated separately rather than applied back to these predictions and described as blind success.

# 5. Methods

## 5.1 Source acquisition, sequence QC, and comparative sampling

UniProtKB was queried with `(gene_exact:SLC30A10) AND (organism_id:9606)`. The recorded response contained seven entries; the reviewed canonical human entry was selected and its accession recorded. Requested fields were restricted to identifiers, gene and organism information, review status, length, and sequence. Retrieval occurred on 13 September 2026 from UniProt release 2026_03. The FASTA, metadata TSV, raw response, query, date, and checksum were retained. Residue numbering was anchored to the single 485-aa sequence throughout.

Candidate vertebrate orthologs were retrieved using `(gene_exact:SLC30A10) AND (taxonomy_id:7742)`, producing 482 records before filtering and sampling. The family query was `(gene:SLC30*) AND (organism_id:9606) AND (reviewed:true)`. Candidate selection excluded fragments, ambiguous sequences, obvious partials, and unsuitable gene assignments; it preferred reviewed representatives and reasonable full-length sequences. An initiator methionine and the 80–120% human-length window informed ortholog QC. Deterministic clade sampling favored phylogenetic breadth and new genera, with one representative per species and a target of 60 including the frozen human sequence.

These filters are documented sequence-selection rules, not a demonstration of orthology. Raw responses and exclusion metadata permit later independent review without replacing the frozen dataset. Human paralogs were not subjected to the same length restriction because family length diversity was an intended part of that comparison. The ortholog FASTA checksum is `d0796892c45df1f842c34a845bf268abd6fcb43943c1c4a4d63b7493e0aafdc4`; the family FASTA checksum is `1e38e48396fadcf1fbe97c0344e896c549f561f4d839c1685622492d15107d31`.

Pairwise identity QC used Biopython global alignment with match 2, mismatch −1, gap opening −5, and extension −0.5, taking the first optimal alignment. Identity divided matches by all aligned columns, including gaps. The candidate-ortholog range was approximately 37.68–100%. This QC measure is distinct from column-wise identity calculated after multiple alignment.

## 5.2 Multiple alignment and conservation

MAFFT version 7.526, dated 26 April 2024, was run separately on each frozen dataset. The recorded commands were:

```sh
timeout 1200s mafft --auto --thread 8 --threadit 0 sequences/SLC30A10_orthologs.fasta > alignments/SLC30A10_orthologs_mafft.fasta 2> logs/SLC30A10_orthologs_mafft.stderr.txt
timeout 1200s mafft --auto --thread 8 --threadit 0 sequences/human_SLC30_family.fasta > alignments/human_SLC30_family_mafft.fasta 2> logs/human_SLC30_family_mafft.stderr.txt
```

All input identifiers occurred exactly once, and removing alignment gaps reproduced every input sequence. Ortholog and family alignments contained 639 and 1,041 columns, respectively. Human ungapped coordinates were mapped independently in each alignment. The human record was retained in descriptive ortholog statistics; family specificity explicitly excluded SLC30A10 from its nine-paralog denominator.

For each human-mapped column, coverage was the fraction of sequences with a non-gap residue. Identity was the fraction of non-gap residues matching the human amino acid. Shannon entropy was `H = −Σ p(a) log2 p(a)` over non-gap amino acids. Distinct-residue count and consensus frequency were also retained; alphabetical ordering resolved consensus ties. Empty comparison columns used documented zero values and flags rather than an invented consensus.

The Step 3 specificity formula was:

`S = C_orth × I_orth × C_other9 × (1 − I_other9)`.

Here `C` denotes coverage and `I` identity to the human target. Entropy was reported but did not enter this score. Percentiles used average ascending ranks, scaled as `100 × (rank − 1) / 484`; ordinal ties used lower residue position. The lamprey sensitivity removed A0ACM8BIL7 from the fixed alignment without realignment. Substantial effect was pre-defined as specificity Spearman correlation below 0.95 or more than 10% of positions changing by over ten specificity percentile points.

## 5.3 Topology and physicochemical scoring

Phobius and SCAMPI-single were queried on 13 September 2026. Raw service responses were preserved. Exact server engine build identifiers were not supplied and cannot be recovered from the recorded outputs; the report therefore identifies the services and retrieval dates without inventing version strings. Both predicted internal termini. Numerical per-residue prediction confidence was not available as a calibrated shared metric.

Strict consensus used the intersection of predicted TM positions, while the union supported boundary sensitivity. The near-TM category extended five residues outside a TM boundary. Chemistry classes were acidic DE, basic KRH, polar uncharged STNQC, aromatic FWY, aliphatic/hydrophobic AVILM, and special GP. Charge annotations distinguished acidic negative residues, KR positive residues, and titratable histidine. Local polar density counted DEKRHSTNQCY within a centered nine-position window, clipped at termini; the center was included. Context windows extended five residues on either side. Kyte–Doolittle hydropathy and a centered 19-residue average described hydrophobicity; these were context features, not experimentally assigned topology.

The Step 4 transport score was:

`T = I_orth × (0.5 + 0.5S) × L × K × (0.5 + 0.5d) × P`.

`L` was 1 inside TM, 0.6 within five residues outside a boundary, and 0.1 otherwise. Chemical weight `K` was 1 for DEH, 0.6 for NQSTCY, 0.5 for KR, and 0.05 for other residues. `d` was local polar density. `P` was 0.25 for a non-TM run of at least 40 residues and 1 otherwise. This long-region penalty must not be interpreted as measured disorder. Strict-versus-union ranking sensitivity retained the formula and weights.

## 5.4 Predicted structure and geometric features

The AlphaFold DB API for Q6XR72 supplied model AF-Q6XR72-F1 version 6. PDB, mmCIF, confidence, and predicted-aligned-error files were archived on 13 September 2026. The PDB source was `https://alphafold.ebi.ac.uk/files/AF-Q6XR72-F1-model_v6.pdb`; its SHA256 was `d989f7e7bc2e59049ee994ed4dcac4c1c24bb3e0afc09299a1f9ede070ad9e10`. Sequence and numbering were checked before feature extraction. No local AlphaFold prediction or experimental SLC30A10 structure was used during the blind phase.

Representative coordinates were Cβ, or Cα for glycine. A missing non-glycine Cβ was an error condition. The graph included DEKRHNQSTCY residues inside or within five sequence positions of a predicted TM segment. Primary edges connected representative atoms at most 6 Å apart, with 5 and 8 Å sensitivity thresholds. Qualifying connected components required residues in at least two actual core helices; boundary association did not by itself satisfy that requirement. Cross-helix neighbor counts excluded self contacts.

An unsigned membrane frame was estimated from predicted helix Cα axes, using the principal direction of their summed outer products and the mean TM coordinate as origin. A ±15 Å slab was an assumption, not an experimentally measured membrane placement. Solvent accessibility used Biopython Shrake–Rupley with a 1.4 Å probe and 100 sphere points, without explicit lipid. DSSP was unavailable; secondary structure used a documented coarse backbone-angle heuristic and should not be described as a DSSP assignment.

The cavity fallback used a 2 Å grid within the strict-TM Cα convex hull and assumed slab. Heavy atoms excluded probe centers using van der Waals radii plus 1.4 Å. Fourteen rays—six axial and eight body-diagonal—were tested in 1 Å steps out to 10 Å. Points with at least ten blocked rays were grouped by six-neighbor connectivity. Components required at least three voxels and lining from at least two core helices. Lining heavy atoms lay within 4.5 Å of a retained probe center. Reported volumes of 48, 256, 64, 24, and 24 Å³ were grid probe-center volumes, not calibrated cavity measurements.

The Step 5 score was:

`G = I_orth × (0.5 + 0.5T) × L × (0.4 + 0.2N + 0.2C + 0.2V) × (pLDDT/100)`.

`N = min(n_cross-helix/3, 1)`; `C` and `V` were binary qualifying-cluster and cavity-lining indicators. The location factor used the same 1/0.6/0.1 definition. Robustness crossed three distance thresholds, three topology masks, and inclusion/exclusion of pLDDT below 70. Baseline cavities and the stored Step 4 score were retained, so these variants did not represent complete independent pipeline reruns.

Candidate constellations used acidic/polar DEHNQSTCY residues in a common cluster, at least two actual TM helices, and all pairwise representative distances at most 6 Å. The pre-specified ranking combined compactness, mean conservation, and Step 4 support. Because no triplet or quadruplet qualified, no constellation ranking was interpreted or threshold relaxed.

## 5.5 Mutation classes, scoring, and freeze

The mutation library included D→A/N, E→A/Q, N→A/Q, Q→A/N, S→A/T, T→A/S, C→A/S, and H→A/N. Selected basic and aromatic alternatives were also documented. Hydrophobic candidates required strong existing network support, core-TM location, pLDDT at least 70, conservation at least 0.8, cluster or cavity membership, and a cross-helix polar neighbor. The final table contained 430 mutations at 215 eligible sites; unlisted sites were not assigned fictitious mutation ranks.

The mutation-priority formula was:

`M = G × I_orth × (0.25 + 0.75F) × (0.5 + 0.25C + 0.25V) × (0.5 + 0.5N)`.

`F` represented the pre-specified chemical-loss prior. Examples were 1 for acidic alanine substitutions, 0.8 for acidic-to-amide changes, 1 for H/C→A, 0.6 for H→N or C→S, 0.75 for NQSTY→A, and 0.25 for selected conservative polar exchanges. These are heuristic weights, not measured energies or binding probabilities. Charge, polarity, size, and potential heteroatom loss remained explicit features. Residue ranking used the best eligible mutation under the frozen ordering; the report reads its archived ranks rather than recalculating them.

Group 1 required appropriate polar chemistry, core-TM location, conservation at least 0.8, pLDDT at least 70, and cluster or cavity support. Group 2 used conserved, well-modeled polar positions in or near TM segments with cross-helix or nearby Group 1 support. Group 3 required conservation at least 0.8 and specificity percentile at least 90. Fixed group selection produced five, four, and three primary residues, plus two amide contrasts and two controls. No suitable installed protein language model was available; this optional component was skipped without downloading weights.

The final report, mutation panel, and Step 3–5 rankings were hashed, with a broader manifest covering 137 blind artifacts. The lock and Git commit recorded the unchanged prediction state. Frozen leave-one-layer outputs were later evaluated diagnostically; the original formulas, ranks, and tiers were not revised after disclosure.

## 5.6 Experimental extraction and structural comparison

Step 7 verified a clean repository and blind manifests before accessing the paper, supplement, source workbook, and deposited experimental structures. Seventy evidence records were curated, including repeated residues across categories; this number is not a count of independent functional positives. Exact substitutions and source locations were preserved. The narrow transport-essential set required individually tested mutations described as abolishing transport. The broader eleven-site set retained significantly impaired individual variants, including substitution-dependent H244 outcomes. Combination-only and disease-only evidence did not define benchmark positives.

The transport assay interpretation followed the paper’s endpoint intracellular-Mn readout and normalization. “Abolished” denotes the curated experimental description, not a newly inferred numerical zero or a directly measured single-turnover rate. Exact-panel outcomes were compared separately from residue-level benchmark membership. Experimental structures were aligned by shared Cα atoms using unweighted Kabsch fits, separately for all shared residues and frozen strict TM spans, without outlier trimming. No new fit or structural calculation was performed for this report.

## 5.7 Uniform and matched-null statistics

Step 7 used 100,000 uniform random sets and seed 20260913. Recovery was the count of benchmark sites within a fixed prediction set. Enrichment divided observed recovery by its random expectation. Empirical upper-tail probabilities used `(k + 1)/(N + 1)`, where `k` counted draws at least as favorable as observed. Zero exceedances therefore yielded finite Monte Carlo resolution, not p = 0.

Step 8A fixed methods before p-value calculation. Deciles failed a feature-only minimum-pool feasibility rule, so global conservation quintiles were used, with cutpoints 0.4782485876, 0.6833333333, 0.85, and 0.9666666667. Ties were kept together and assigned to the upper interval at equality. Confidence categories were below 70, 70 to below 90, and at least 90. NULL 5 additionally used frozen Step 4 score quintiles, with cutpoints 0.0005064800, 0.0034076839, 0.0094955012, and 0.0247924554, alongside exact topology and chemical classes.

Matched slots were sampled uniformly, rejecting an entire proposed tuple if any residue repeated. This avoided order-dependent depletion and maintained sampling without replacement. Experimental residues were eligible controls under the random-label design. A deterministic nearest-bin fallback was specified for infeasible strata, but no fallback was required. Candidate pools, singleton slots, rejected proposals, seeds, and accepted counts were archived.

The master seed was 2026091308, with benchmark/null streams derived through NumPy SeedSequence; a separate preflight seed was 2026091309. Eighteen benchmark/null combinations each supplied one million accepted draws to five cutoff and four rank endpoints: 90 cutoff tests and 72 rank tests. Execution took approximately 29.9 seconds on one CPU thread. Recorded versions were Python 3.11.16, NumPy 2.4.6, and SciPy 1.17.1; the project also recorded Biopython 1.88 and Matplotlib 3.11.1. Exact distribution cross-checks passed for all 90 recovery endpoints.

Monte Carlo confidence intervals used the two-sided Clopper–Pearson interval for the underlying tail probability. With zero exceedances in one million draws, the plus-one estimate is approximately 10⁻⁶ and the upper 95% bound approximately 3.69 × 10⁻⁶. Holm adjustment covered 75 primary and 15 diagnostic cutoff tests separately, and 60 primary and 12 diagnostic rank tests separately. These families must accompany any claim of corrected significance.

Rank endpoints included mean, median, mean reciprocal rank, and normalized rank loss. Step 6 eligibility leaves 270 positions unranked. Mean/median comparisons first favored fewer unranked sites, then the smaller finite summary; reciprocal rank assigned zero to an unranked site, and normalized loss assigned one. For ranked sites, normalized loss used `(rank − 1)/215`. These are evaluation conventions, not changes to frozen ranks. Residue-wise percentiles counted worse-ranked or unranked reference positions plus half of ties, divided by pool size. M44 retained NA rather than receiving an invented ordinal rank.

# 6. Limitations

**Table 5. Major limitations and implications.**

| Limitation | Consequence for interpretation | Appropriate next test |
| --- | --- | --- |
| One retrospective target | No estimate of general-purpose performance | Independent hidden-answer transporter |
| Internal blinding and model provenance | Does not exclude pretraining exposure | External holdout and training-date audit |
| Candidate orthology | Paralogy or uneven species sampling may affect conservation | Independent phylogenetic validation |
| Single-state model and AF-initialized experimental modeling | Backbone agreement is not independent validation | Independent structural and functional assays |
| Coarse cavities and CB graph | Neighborhoods do not specify a coordination shell | Pre-specified donor geometry with uncertainty |
| Repeated and correlated features | Ablations do not uniquely assign causal credit | Independent targets and fixed comparator models |
| NULL 5: nine A/B sets | Limited ability to distinguish geometry-specific signal | Larger independent benchmark, fixed matching design |
| Small, selectively tested positive set | Known-positive fraction is not full panel precision | Test the complete proposed panel |
| Substitution-specific phenotypes | H244N/D cannot validate H244A | Evaluate exact substitutions |
| Untested candidates and controls | No positive or negative adjudication | Measure transport and expression separately |

Several limitations constrain the scope of the findings beyond the summary table. First, a single transporter and small nested positive sets do not support performance estimates across protein families. Second, the study is retrospective despite internal blinding, and pretrained-model or template exposure cannot be excluded. Third, candidate orthology was not fully validated phylogenetically, and species were not weighted through a formal evolutionary model. Fourth, alignment and topology uncertainty can change local context even when overall correlations are high.

Fifth, the AlphaFold model describes one predicted state with many low-confidence residues. Sixth, the experimental model’s AlphaFold2 initialization makes structural similarity non-independent. Seventh, the simplified cavity detector and Cβ graph do not model solvent, ion coordination, protonation, or side-chain rotamer uncertainty adequately. Eighth, no explicit metal docking was performed. Ninth, no molecular dynamics or conformational free-energy calculation was performed. Tenth, the optional protein language model analysis was unavailable and omitted.

Eleventh, the strictest matched null had only nine possible A/B sets, limiting inference about geometry-specific value. Twelfth, experimental positives were few and selectively assayed, with an out-of-support chemistry issue for the broader benchmark. Thirteenth, different substitutions at the same site are not interchangeable experiments. Finally, untested predictions cannot be labeled false positives, and untested controls cannot establish specificity. Together these constraints support a hypothesis-generation conclusion, not a claim of mechanistic discovery, calibrated clinical interpretation, or complete mutational prediction.

# 7. Conclusions

A provenance-controlled, internally blind computational workflow reduced a 485-residue transporter to a compact mutation panel containing all four subsequently disclosed Mn2+-coordinating residues and the additional narrowly defined transport-essential D47 site. Sequence specificity alone was insufficient. Topology and physicochemical context produced substantial ranking improvements, and predicted spatial organization helped concentrate several key candidates before the final freeze.

Recovery exceeded simple topology- and chemistry-matched backgrounds. More restrictive matching weakened cutoff-based statistical support, while some rank-based evidence persisted after conservation and confidence matching. The strictest diagnostic design did not resolve an independent contribution from geometry because the matched space was extremely sparse. The workflow also retained concrete failures: no valid pre-specified coordination constellation, imperfect cavity localization, an incorrect H244A effect prediction, and omitted experimental sites.

The study supports reproducible, AI-assisted prioritization of falsifiable experiments. It does not replace experimental validation or demonstrate general predictive performance. An independent hidden-answer transporter, analyzed without retuning and with the complete panel subsequently tested, is the appropriate next prospective evaluation.

## Source and artifact guide

This report synthesizes existing analyses without generating new scientific scores or statistics. The primary internal sources are [the final blind prediction](FINAL_BLIND_PREDICTION.md), [the blind lock](BLIND_PHASE_LOCKED.txt), [Step 3](step3_sequence_conservation.md), [Step 4](step4_topology_sequence_context.md), [Step 5](step5_structure_analysis.md), [Step 7](STEP7_GROUND_TRUTH_COMPARISON.md), and [Step 8A](STEP8A_MATCHED_NULL_ROBUSTNESS.md). Exact numerical comparison sources include [stored ranks](../comparison/frozen_residue_ranks.tsv), [panel outcomes](../comparison/panel_experimental_status.tsv), [ablation performance](../comparison/ablation_performance.tsv), [structural metrics](../comparison/structural_alignment_metrics.tsv), [matched permutations](../comparison/matched_null/matched_null_permutation_results.tsv), and [rank-based tests](../comparison/matched_null/rank_based_enrichment.tsv).

Experimental statements derive from the Step 7 archived article, supplementary material, source workbook, and evidence table, with the published source available at [Shen et al., “Molecular mechanisms of SLC30A10-mediated manganese transport”](https://www.nature.com/articles/s41467-025-63616-7). Prediction-resource provenance is retained with the [UniProt sequence metadata](../data/processed/SLC30A10_sequence_metadata.tsv), [topology consensus](../data/processed/SLC30A10_topology_consensus.tsv), and [AlphaFold model](../structures/predicted/AF-Q6XR72-F1-model_v6.pdb). New table transcriptions, plotting source, claim ledger, and integrity audit are under [technical_case_study](technical_case_study/). The accompanying [validation record](SLC30A10_TECHNICAL_REPORT_VALIDATION.json) documents reporting-only checks.
