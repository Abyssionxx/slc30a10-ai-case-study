# Step 7 — frozen blind prediction versus experimental ground truth

## Checkpoint integrity and scope

The clean working tree and HEAD `008b7ad7a436fc02898292ec7d0441cf0df6c390` were verified before source access. Both `results/FINAL_BLIND_PREDICTION.sha256` (5 entries) and `results/BLIND_PHASE_FILES.sha256` (137 entries) passed. The pre-access UTC time, manifest hashes and constituent hashes are in `comparison/step7_comparison_provenance.json`. New comparison code verifies these manifests again before evaluating anything. The blind lock and all Steps 1–6 outputs remain unchanged. Final post-analysis verification is recorded in `comparison/final_integrity_verification.json`.

The reference is [Shen et al., Nature Communications (2025)](https://www.nature.com/articles/s41467-025-63616-7), including all Results, relevant Methods, Supplementary Information and the source workbook. The full article XML, 23-page supplement, source data and deposited structures are archived under `ground_truth/raw/`. Supplementary figures were rendered for visual reading. Five evidence categories remain separate: direct Mn coordination, transport assays, nearby structural context, clinical association, and conformational/gating inference. There are 70 evidence records, including repeated residues across categories and combination/clinical variants; this is not 70 independently validated residues.

The target-paper comparison is retrospective despite information blinding: the freeze occurred in September 2026 and the paper was published in September 2025. Neither file integrity nor this exercise demonstrates that pretrained models were historically independent of all prior SLC30A10 biology.

## Recovery of the experimental site

All **four direct Mn coordinators** were recovered within the first **six distinct Step 6 residues**. The same final panel recovered all five narrow transport-essential sites, including non-ligand D47. “Direct ligand” and “essential for transport” are not interchangeable. Sources: Fig. 2b/e/j, Supplementary Figs. 7 and 9; cellular support in Fig. 4 and Supplementary Fig. 13.

| residue | Step3_rank | Step4_rank | Step5_rank | Step6_rank | first_top20_step |
| --- | --- | --- | --- | --- | --- |
| D40 | 269 | 21 | 21 | 5 | Step6 |
| D47 | 447 | 9 | 4 | 4 | Step4 |
| N127 | 339 | 36 | 2 | 1 | Step5 |
| D248 | 461 | 8 | 1 | 2 | Step4 |
| S252 | 273 | 27 | 7 | 6 | Step5 |

Step 3 ranks are sequence-specificity ranks, not pure ortholog-conservation ranks. D40/N127/D248/S252 all have ortholog identity 1.0, but rank poorly by divergence from other family members. D47 has identity 0.90. Ties use the frozen ascending-position convention. Steps 3–5 rank 485 residues; Step 6 ranks only its 215 eligible sites. M44 has no Step 6 mutation and remains NA rather than receiving a fabricated bottom rank.

Tier 1 contains five sites: N127, D248, D280, D47 and S252. Four are assay-supported transport-essential (4/5 = 80% known-positive fraction), three are direct ligands (3/5 = 60%), and D280 is untested. Tier 2 contains D40, S50, N85 and H244. Its exact panel substitutions give one supported site (D40A), one experimentally negative mutation (H244A) and two untested sites. Tier 1 + Tier 2 recover all five essential sites (5/9 = 55.6% known-positive fraction; 100% recall) and all four ligands (4/9 = 44.4%; 100% recall). Untested sites are not called false positives.

## Quantitative performance and permutation enrichment

The pre-calculation protocol is `comparison/methods_prespecified.md`. Primary benchmark: D40,D47,N127,D248,S252 (individual mutations described as abolishing transport). Secondary direct-ligand benchmark: D40,N127,D248,S252. Broader mutation-sensitive benchmark: E25,S39,D40,M44,D47,C93,N127,H244,D248,S252,I291. H244 positivity depends on substitution; it must not inflate exact-panel success. Combination-only G251/V254 and disease-only associations are excluded.

| prediction_set | hits | set_size | recall | precision_known_positive_fraction | enrichment |
| --- | --- | --- | --- | --- | --- |
| Top 5 | 4 | 5 | 0.8 | 0.8 | 77.6 |
| Top 10 | 5 | 10 | 1 | 0.5 | 48.5 |
| Top 20 | 5 | 20 | 1 | 0.25 | 24.25 |
| Tier 1 | 4 | 5 | 0.8 | 0.8 | 77.6 |
| Tier 1 + Tier 2 | 5 | 9 | 1 | 0.5556 | 53.89 |

For the essential benchmark the frozen ranks have mean 3.6, median 4, best 1 and worst 6. For direct ligands: mean/median 3.5, best 1, worst 6. The broader set has mean 9.5, median 6.5, best 1 and worst finite rank 28 among ten ranked sites; M44 is unranked. Its top-20 recovery is 9/11 (81.8%), with known-positive fraction 9/20 (45%). Full metrics for every step and benchmark are in `comparison/performance_metrics.tsv`.

| top_k | observed_hits | permutations | exceedances | monte_carlo_p | exact_hypergeometric_p |
| --- | --- | --- | --- | --- | --- |
| 5 | 4 | 100000 | 0 | 1e-05 | 1.1e-08 |
| 10 | 5 | 100000 | 0 | 1e-05 | 1.15e-09 |
| 20 | 5 | 100000 | 0 | 1e-05 | 7.08e-08 |

Uniform sampling used 100,000 actual residue sets from all 485 positions, seed 20260913. No null draw matched the observed essential-site hits; the plus-one estimate is approximately 1e-5, not zero. With zero exceedances the approximate 95% upper bound is 3e-5, so Monte Carlo cannot resolve the much smaller exact tails. Direct-ligand recovery was 3/4, 4/4 and 4/4 at top 5/10/20, with the same Monte Carlo resolution; exact tails are 2.11e-6, 9.22e-8 and 2.13e-6. These are enrichment against a full-protein null, not calibrated prospective probabilities. TM/chemistry preselection, selected experimental testing, related evidence layers, and multiple reported benchmarks make that null optimistic. No post-hoc weight optimization was performed. The functional transport readout uses endpoint intracellular Mn (CFMEA), normalized to DNA and relative protein expression; it is not a direct single-turnover transport-rate measurement.

## Exact mutation-panel comparison

| mutation | tier | frozen_predicted_effect | experimental_effect | classification |
| --- | --- | --- | --- | --- |
| N127A | Tier 1 | strong | abolished | confirmed hit |
| D248A | Tier 1 | strong | abolished | confirmed hit |
| D280A | Tier 1 | strong | not tested | experimentally untested |
| D47A | Tier 1 | strong | abolished | confirmed hit |
| S252A | Tier 1 | strong | abolished | confirmed hit |
| D40A | Tier 2 | strong | abolished | confirmed hit |
| S50A | Tier 2 | strong | not tested | experimentally untested |
| N85A | Tier 2 | strong | not tested | experimentally untested |
| H244A | Tier 2 | strong | unchanged | experimentally negative |
| S282A | Tier 3 | strong | not tested | experimentally untested |
| E339A | Tier 3 | moderate | not tested | experimentally untested |
| D136A | Tier 3 | strong | not tested | experimentally untested |
| D248N | Tier 1 | strong | abolished | confirmed hit |
| D280N | Tier 1 | strong | not tested | experimentally untested |
| S56T | control | weak | not tested | experimentally untested |
| T90S | control | weak | not tested | experimentally untested |

Of 16 proposed substitutions, six have the predicted disruptive effect, one (H244A) is experimentally unchanged, and nine are untested. The six positive substitutions represent five sites because D248A and D248N both validate D248. Conditional on these seven actually tested substitutions, agreement on disruption is 6/7; this selected subset is not overall panel precision. D280A/N, S50A, N85A, S282A, E339A, D136A, S56T and T90S remain untested. The negative controls therefore have no validation here. H244N/D reduction does not rescue the specific H244A prediction.

## Residue-level diagnosis and misses

- D248 first enters the top 20 at Step 4 (#8), then becomes Step 5 #1 and Step 6 #2. Acidic chemistry, perfect ortholog conservation, N127 cross-helix proximity, cluster C1 and cavity V4 reinforce it despite zero sequence-specificity score.
- N127 first enters at Step 5 (#2). Perfect conservation alone did not prioritize its low specificity score; the cross-helix cluster and V4 cavity provide the main promotion. It is Step 6 #1.
- S252 first enters at Step 5 (#7), reaches Step 6 #6 and is Tier 1. Its polar class, conserved TM5 position and C1 cross-helix neighborhood helped despite no frozen cavity membership. Removing cluster evidence moves it to #11.
- D40 first enters the top 20 at Step 6 (#5); it was #21 at Steps 4 and 5. The strict sequence topology calls it a boundary residue, whereas the experiment assigns TM2. Acidic chemistry, conservation and cross-helix C1 connectivity promote it, but the topology-based group rule relegates a real ligand to Tier 2.
- D47 first enters at Step 4 (#9), then #4 at Steps 5 and 6. Acidic chemistry and V2/C1 membership recover a transport-essential recruitment residue, without demonstrating direct Mn ligation.
- E25 first enters at Step 4 (#6) and remains Step 6 #7. It is a **panel-selection miss**, not a ranking failure: fixed hypothesis quotas excluded it. The experiment supports stabilization of D40 rather than direct coordination.
- S39 enters at Step 6 (#14), and I291 at Step 5 (#11; Step 6 #18). Both fall outside the final panel although their tested substitutions reduce transport. S39 has near-TM polar-network support; I291 is promoted by hydrophobic-network/cavity V5 context.
- C93 reaches Step 4 #20 but falls to Step 5 #61 and Step 6 #28. Lower ortholog identity (0.783), no C1/cavity membership and no cross-helix polar neighbors weaken it. It is a top-20 and panel miss in the broader benchmark.
- M44 is Step 5 #48 and excluded from Step 6 mutation eligibility. Its hydrophobic stabilization of D40 was underrepresented by the chemical/network gate. It is the other broader top-20 miss.
- H244 reaches Step 6 #10, driven by chemistry plus C1 and V2/V3 membership, despite boundary status and pLDDT 70.44. H244A is the one experimentally negative panel prediction; cavity/network proximity did not imply sensitivity to alanine substitution.

Untested Tier 1/2 candidates have inspectable drivers rather than confirmed false-positive labels: D280 (identity 1.0, pLDDT 91.94) is in the separate T258-D280 cluster C2; S50 (identity 0.90, pLDDT 84.06) is in C1/V2; N85 (identity 0.967, pLDDT 87.0) is a boundary C1/V2 site with a cross-helix neighbor. The remaining exploratory specificity candidates are not experimentally adjudicated. Every important/site-panel position has frozen ranks, topology, confidence, neighbor counts and stored ablation score changes in `comparison/residue_evidence_diagnostics.tsv`. Largest ablation losses are descriptive, not causal attributions: correlated layers and repeated use of conservation prevent uniquely assigning success to one feature.

## Frozen ablation performance

| ablation | top_k | primary_hits | ablated_hits | interpretation | spearman_all |
| --- | --- | --- | --- | --- | --- |
| no_cavity | 5 | 4 | 4 | unchanged | 0.998932599193412 |
| no_cavity | 10 | 5 | 5 | unchanged | 0.998932599193412 |
| no_cluster | 5 | 4 | 3 | worsened | 0.999242918206187 |
| no_cluster | 10 | 5 | 4 | worsened | 0.999242918206187 |
| no_specificity | 5 | 4 | 4 | unchanged | 0.9999553237218962 |
| no_specificity | 10 | 5 | 5 | unchanged | 0.9999553237218962 |
| no_topology | 5 | 4 | 3 | worsened | 0.9400685841242242 |
| no_topology | 10 | 5 | 5 | unchanged | 0.9400685841242242 |

Removing sequence specificity changes no essential/ligand recovery at the reported cutoffs. Removing topology reduces essential top-5 recovery from 4 to 3 but leaves top-10 recovery unchanged. Removing polar-cluster evidence reduces essential top-10 recovery from 5 to 4 and direct-ligand recovery from 4 to 3: S252 falls out. Removing cavity evidence improves direct-ligand top-5 recovery from 3 to 4 (S252 enters) while leaving essential top-10 recovery at 5. It also removes H244, S50 and N85 from the frozen top 10, but those three are not all false positives: only H244A is experimentally negative. The broad top-20 benchmark worsens by one on removal of topology, cluster or cavity evidence. All four ablations and all cutoffs are retained; the primary ranking is untouched.

## Structural comparison

Experimental chains were matched by author residue number and verified against the frozen 485-aa sequence with zero identity mismatches. Unweighted Kabsch fits use all shared Cα atoms and, separately, the frozen strict TM ranges (12–28,44–61,86–105,121–141,245–265,279–299). No outlier trimming, structural refinement or coordinate alteration was performed. Only 288–295 residues per experimental protomer are resolved; full-length 485-residue RMSD cannot be reported.

| model_chain | state | resolved_residues | shared_CA_RMSD_A | TM_CA_RMSD_A | site_CA_RMSD_after_TM_fit_A |
| --- | --- | --- | --- | --- | --- |
| 9KVX_B | IF-Mn | 290 | 2.198 | 1.796 | 1.473 |
| 9KVX_A | IF-Mn | 290 | 2.198 | 1.796 | 1.473 |
| 9KVY_A | IF-Mn | 288 | 2.218 | 1.785 | 1.520 |
| 9KVY_B | OF | 295 | 4.025 | 3.205 | 4.136 |
| 9KVZ_B | apo-IF | 290 | 2.275 | 1.852 | 1.245 |
| 9KVZ_A | apo-IF | 290 | 2.297 | 1.869 | 1.497 |

The AF model is IF-like: approximately 1.8 Å TM RMSD for Mn-bound IF and 3.2 Å for OF. Four-site Cα RMSD after the TM fit is about 1.5 Å for IF and 4.1 Å for OF. All four ligands were in frozen connected cluster C1, but its 16 members span 29.24 Å. AF ligand-pair CB distances range 4.74–9.47 Å, so this was not a compact all-pairs 6 Å quartet. D40–N127 minimum donor separation is 6.87 Å in AF, 4.89 Å in 9KVX and 10.45 Å in the OF protomer. Thus the neighborhood was recovered better than the coordinating side-chain geometry. Even experimental IF CB distances can exceed 6 Å between ligands; a CB clique rule is intrinsically unsuitable for demanding a complete metal-coordination constellation.

After fitting AF to 9KVX, the N127 carbonyl lies approximately 4.53 Å from the experimental Mn position, versus 2.73 Å in the deposited model; D248 OD1 is about 4.05 Å versus 2.14 Å. These reference-ion distances are a diagnostic superposition, not docking or a predicted Mn site. Pairwise CA/CB/donor distances and all candidate donor-to-Mn distances are in `comparison/coordination_distances.tsv` and `comparison/metal_atom_distances.tsv`.

Frozen cavity V4 lines N127 and D248 but not D40/S252; V2 captures D47 context. `comparison/cavity_experimental_overlap.tsv` measures proximity of unchanged probe centers to experimentally placed Mn after TM superposition. The nearest V4 probe center is 7.25 Å from Mn in 9KVX after alignment (7.80 Å for 9KVY IF): overlap in lining residues did not accurately localize the ion. Tiny grid probe-center volumes are not validated biological cavity volumes. The blind analysis produced no 6 Å all-pairs triplet/quadruplet constellation and therefore missed the exact four-ligand assembly despite ranking its residues successfully.

The paper reports TM1/TM2/TM5 rotations of 37.1°/20.6°/22.4°. Our separate fixed-range, full-TM-fit endpoint-axis angles are 42.3°/11.6°/11.0°. They differ because the helix spans, reference alignment and angle definitions differ, especially for boundary-excluded D40; they are not a replication of the authors angle calculation. Frozen single-state predictions did not predict IF/OF movement. Experimental AlphaFold2-initialized model building further limits the independence of global backbone agreement.

## Mechanism assessment and future work

`comparison/predicted_vs_experimental_mechanism.tsv` separates SUPPORTED, PARTIALLY SUPPORTED, NOT SUPPORTED and NOT TESTED claims. The strongest success is residue-level experimental prioritization; the weakest claim would be pretending the blind workflow solved selectivity, stoichiometry, a complete coordination shell, or conformational energetics. Those were not established.

Could this workflow have suggested the correct mutagenesis experiments? **Yes, as a candidate-generation workflow:** the frozen 16-substitution panel contained all four coordinator alanine substitutions, D47A and D248N before the target paper was opened in this session. **It did not independently establish the full mechanism**, and its calibration cannot be inferred from one retrospectively chosen protein. It also missed E25/M44/S39/C93/I291 in the final panel and incorrectly expected an H244A effect.

For a future genuinely prospective study: timestamp datasets and model versions before experimental availability; document training/template cutoffs; preregister benchmark definitions and matched TM/chemistry nulls; use donor-atom/rotamer uncertainty rather than CB cliques for coordination geometry; retain topology boundary uncertainty in group assignment; test dynamic/oligomeric-state uncertainty only through an independently specified workflow; include a small representative set of hydrophobic second-shell candidates; prevent hypothesis quotas from silently discarding high-ranked alternatives such as E25; distinguish transport loss from expression/trafficking and metal-selectivity changes; experimentally test both negative controls and high-confidence untested sites. These are future changes only—none were applied to the frozen predictions.

## Outputs and reproducibility

New evidence: `ground_truth/SLC30A10_experimental_residues.tsv`, `ground_truth/SLC30A10_experimental_mechanism.md`, archived raw sources, rendered supplement pages and source-workbook cells. New analysis: `comparison/` scripts, protocol, source/checkpoint provenance, rank and mutation comparisons, metrics, permutations, ablations, diagnostics, structural distances and mechanism table. New figures: `figures/blind_vs_experimental_residue_ranks.png`, `figures/blind_prediction_structure_vs_experiment.png`, `figures/evidence_layer_recovery.png`. Execution commands and software versions are in `comparison/execution_provenance.json`. Reproduction writes only Step 7 outputs and must never invoke the old blind analysis scripts. No installation, docking, MD, blind rescoring or modification of Steps 1–6 was performed.
