# SLC30A10 AI Project

## Architecture

Codex runs on the local Mac.

Scientific computation runs on the remote Linux server through SSH alias:

slc-server

Remote project directory:

/path/to/projects/slc30a10_ai

Preferred remote conda environment:

/path/to/conda/envs/slc30a10_ai

## Scientific objective

Perform a blind computational prediction of molecular determinants of
human SLC30A10-mediated Mn2+ transport.

The target paper:
"Molecular mechanisms of SLC30A10-mediated manganese transport"

must NOT be used during the blind prediction phase.

## Remote server autonomy

Codex MAY:

- inspect the remote environment;
- inspect existing software versions;
- create project directories under:
  /path/to/user/
- create project-specific conda environments;
- install packages inside user-owned project environments;
- reuse existing system/shared bioinformatics tools;
- synchronize files with rsync;
- write and execute analysis scripts;
- generate logs;
- retrieve results to the Mac.

Codex MUST check whether software already exists before installing it.

## Forbidden operations

Codex MUST NOT:

- use sudo;
- run apt install;
- modify /usr;
- modify /usr/local;
- modify /opt/miniforge3 base;
- run conda update --all;
- upgrade the shared conda installation;
- install software globally;
- delete files outside the SLC30A10 project;
- use more than 8 CPU threads by default;
- use more than 16 CPU threads without explicit approval.

## Expensive jobs

Before launching any job expected to exceed 30 minutes, Codex must report:

- scientific purpose;
- command;
- CPU threads;
- RAM estimate;
- disk estimate;
- runtime estimate;

and wait for approval.

## Scientific rules

1. Never fabricate data.
2. Separate prediction from experimental evidence.
3. Preserve raw outputs.
4. Record commands and software versions.
5. Use reproducible scripts.
6. Use fixed random seeds when applicable.
7. Report uncertainty and failed analyses.
8. Do not tune parameters merely to agree with the target paper.
9. Freeze blind predictions before revealing experimental ground truth.
10. Prefer falsifiable predictions.

## Phase 1

CPU-only workflow:

sequence
→ homolog retrieval
→ multiple sequence alignment
→ conservation
→ transmembrane topology
→ predicted structure analysis
→ cavity/residue features
→ candidate Mn-binding residues
→ mutation prioritization
→ blind prediction freeze
→ comparison with experimental ground truth
