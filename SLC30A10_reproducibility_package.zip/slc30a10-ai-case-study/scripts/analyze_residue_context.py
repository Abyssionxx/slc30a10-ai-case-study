#!/usr/bin/env python3
"""Blind sequence-only topology/context analysis. No network or structural inputs."""
import csv, hashlib, json, os
from pathlib import Path
import numpy as np
from analyze_sequence_conservation import fasta, tsv, percentiles, ranks
ROOT=Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR']=str(ROOT/'.runtime/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
KD=dict(zip('ACDEFGHIKLMNPQRSTVWY',[1.8,2.5,-3.5,-3.5,2.8,-.4,-3.2,4.5,-3.9,3.8,1.9,-3.5,-1.6,-3.5,-4.5,-.8,-.7,4.2,-.9,-1.3]))
POLAR=set('DEKRHSTNQCY')
CLASSES={'acidic':'DE','basic':'KRH','polar uncharged':'STNQC','aromatic':'FWY','aliphatic/hydrophobic':'AVILM','glycine/proline special':'GP'}

def runs(mask):
    result=[]; start=None
    for i,v in enumerate(list(mask)+[False]):
        if v and start is None: start=i
        elif not v and start is not None: result.append((start,i-1)); start=None
    return result

def properties(mask):
    tm=runs(mask); non=runs(~mask); boundaries=[p for pair in tm for p in pair]
    h=np.zeros(len(mask),int); long=np.zeros(len(mask),bool); terminal=np.zeros(len(mask),bool)
    for number,(a,b) in enumerate(tm,1): h[a:b+1]=number
    for a,b in non:
        if b-a+1>=40: long[a:b+1]=True
        if a==0 or b==len(mask)-1: terminal[a:b+1]=True
    distance=np.array([min(abs(i-p) for p in boundaries) if boundaries else len(mask) for i in range(len(mask))])
    return dict(helices=tm,helix=h,long=long,terminal=terminal,distance=distance)

def main():
    raw=ROOT/'data/raw/topology'; p=ROOT/'sequences/SLC30A10_human_canonical.fasta'
    digest=hashlib.sha256(p.read_bytes()).hexdigest(); assert digest==p.with_suffix('.sha256').read_text().split()[0]
    target=next(iter(fasta(p).values())); n=len(target); assert n==485
    # Verify Step 3 files against their frozen output manifest before reading scores.
    for line in (ROOT/'results/step3_outputs.sha256').read_text().splitlines():
        sha,name=line.split('  ',1); assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha,name
    ph=json.loads((raw/'phobius.json').read_text())['predictions']; assert len(ph)==1 and ph[0]['length']==n
    ph=ph[0]; state1=['?']*n
    for feature in ph['features']:
        a,b=feature['start']-1,feature['stop']; assert 0<=a<b<=n
        assert all(c=='?' for c in state1[a:b]); state1[a:b]=[feature['label'].upper()]*(b-a)
    assert '?' not in state1 and set(state1)<=set('IMO')
    state2=next(iter(fasta(raw/'scampi_query.top').values())); assert len(state2)==n and set(state2)<=set('IMO')
    assert next(iter(fasta(raw/'scampi_query.raw.fa').values()))==target
    for name in ['phobius.json','scampi_query.top']:
        meta=json.loads((raw/(name+'.provenance.json')).read_text())
        assert meta['input_fasta_sha256']==digest
        assert hashlib.sha256((raw/name).read_bytes()).hexdigest()==meta['response_sha256']
    m1=np.array([x=='M' for x in state1]); m2=np.array([x=='M' for x in state2]); strict=m1&m2; union=m1|m2; disagree=m1!=m2
    prop=properties(strict); up=properties(union)
    all_bounds=[x for pair in runs(m1)+runs(m2) for x in pair]
    step3=list(csv.DictReader((ROOT/'results/tables/SLC30A10_sequence_specificity.tsv').open(),delimiter='\t'))
    assert len(step3)==n and ''.join(r['human_residue'] for r in step3)==target
    topology=[]; contexts=[]; annotated=[]; candidates=[]
    for i,aa in enumerate(target):
        clas=next(k for k,v in CLASSES.items() if aa in v)
        charge='negative' if aa in 'DE' else 'positive' if aa in 'KR' else 'titratable' if aa=='H' else 'neutral'
        density=sum(a in POLAR for a in target[max(0,i-4):min(n,i+5)])/len(target[max(0,i-4):min(n,i+5)])
        near=bool(prop['distance'][i]<=5)
        status='TM' if strict[i] else 'disagreement' if disagree[i] else 'non-TM'
        orientation=state1[i] if state1[i]==state2[i] else 'uncertain'
        topology.append(dict(residue_number=i+1,amino_acid=aa,phobius_state=state1[i],scampi_state=state2[i],phobius_TM=bool(m1[i]),scampi_TM=bool(m2[i]),consensus_TM_status=status,strict_TM=bool(strict[i]),union_TM=bool(union[i]),predicted_helix_number=int(prop['helix'][i]),boundary_uncertainty=bool(disagree[i] or min(abs(i-x) for x in all_bounds)<=5),predictor_disagreement=bool(disagree[i]),predicted_loop_nonTM_status='uncertain' if disagree[i] else 'TM' if strict[i] else 'loop/non-TM',orientation_consensus=orientation,phobius_confidence='NA (posterior SVG in raw JSON)',scampi_confidence='NA (not supplied)'))
        context=dict(residue_number=i+1,amino_acid=aa,amino_acid_class=clas,charge_class=charge,hydropathy_Kyte_Doolittle=KD[aa],hydropathy_window19=float(np.mean([KD[a] for a in target[max(0,i-9):min(n,i+10)]])),inside_TM=bool(strict[i]),TM_status=status,TM_helix_number=int(prop['helix'][i]),within5_TM_boundary=near,boundary_distance=int(prop['distance'][i]),long_nonTM=bool(prop['long'][i]),terminal_nonTM=bool(prop['terminal'][i]),window_pm5=target[max(0,i-5):min(n,i+6)],window_pm5_start=max(0,i-5)+1,window_pm5_end=min(n,i+6),polar_charged_density_pm4=density)
        contexts.append(context)
        flags={'A_TM_polar_charged':bool(strict[i] and aa in POLAR),'B_TM_hydrophobic':bool(strict[i] and aa in 'AVILMFW'),'C_TM_boundary':near,'D_loop_polar_charged':bool(not strict[i] and aa in POLAR),'E_long_nonTM':bool(prop['long'][i])}
        categories=';'.join(k for k,v in flags.items() if v) or 'other/special'
        annotated.append(dict(**step3[i],**{k:v for k,v in context.items() if k not in ['residue_number','amino_acid']},categories=categories,**flags))
        K=1. if aa in 'DEH' else .6 if aa in 'NQSTCY' else .5 if aa in 'KR' else .05
        def transport(mask,pr):
            L=1. if mask[i] else .6 if pr['distance'][i]<=5 else .1
            P=.25 if pr['long'][i] else 1.
            return float(step3[i]['ortholog_identity'])*(.5+.5*float(step3[i]['specificity_score']))*L*K*(.5+.5*density)*P,L,P
        score,L,P=transport(strict,prop); alt,_,_=transport(union,up)
        assignment=('TM'+str(prop['helix'][i])) if strict[i] else ('boundary' if near else 'non-TM')
        rationale=('acidic/His chemical prior' if aa in 'DEH' else 'polar donor/acceptor chemical prior' if aa in 'NQSTCY' else 'basic proton/electrostatic chemical prior' if aa in 'KR' else 'low chemical-role prior')+'; '+assignment+'; local polar/charged fraction '+format(density,'.3f')
        candidates.append(dict(**annotated[-1],transport_score=score,union_transport_score=alt,location_factor=L,chemistry_factor=K,long_region_factor=P,assignment=assignment,physicochemical_rationale=rationale))
    scores=[r['transport_score'] for r in candidates]; uscores=[r['union_transport_score'] for r in candidates]
    for r,a,b in zip(candidates,percentiles(scores),percentiles(uscores)):
        r.update(transport_percentile=a,union_transport_percentile=b,percentile_shift_union_minus_strict=b-a)
    top=sorted(candidates,key=lambda r:(-r['transport_score'],int(r['human_residue_number'])))[:20]
    utop=sorted(candidates,key=lambda r:(-r['union_transport_score'],int(r['human_residue_number'])))[:20]
    ids=lambda rows:{int(r['human_residue_number']) for r in rows}
    primary_ids=ids(top); union_ids=ids(utop)
    s3top=sorted(step3,key=lambda r:(-float(r['specificity_score']),int(r['human_residue_number'])))[:20]
    sensitive=[]
    for r in candidates:
        pos=int(r['human_residue_number']); changed=(pos in primary_ids)!=(pos in union_ids)
        r['highly_topology_sensitive']=abs(r['percentile_shift_union_minus_strict'])>10 or changed
        r['top20_membership_changes']=changed
        if r['highly_topology_sensitive']: sensitive.append(r)
    fmt=lambda mask:[[a+1,b+1] for a,b in runs(mask)]
    summary=dict(phobius_ranges=fmt(m1),scampi_ranges=fmt(m2),strict_ranges=fmt(strict),union_ranges=fmt(union),TM_disagreement_positions=(np.flatnonzero(disagree)+1).tolist(),agreement_fraction=float(np.mean(~disagree)),strict_union_spearman=float(np.corrcoef(ranks(scores),ranks(uscores))[0,1]),top20_shared=len(primary_ids&union_ids),strict_only_top20=sorted(primary_ids-union_ids),union_only_top20=sorted(union_ids-primary_ids),highly_sensitive_positions=[int(r['human_residue_number']) for r in sensitive],step3_top20_shared=sorted(primary_ids&ids(s3top)),top20=[r['human_residue']+r['human_residue_number'] for r in top],sequence_sha256=digest,software=dict(numpy=np.__version__,matplotlib=matplotlib.__version__))
    tsv(ROOT/'data/processed/SLC30A10_topology_consensus.tsv',topology)
    out=ROOT/'results/tables'
    tsv(out/'SLC30A10_residue_context.tsv',contexts); tsv(out/'SLC30A10_topology_annotated_specificity.tsv',annotated)
    tsv(out/'SLC30A10_topology_transport_candidates.tsv',sorted(candidates,key=lambda r:(-r['transport_score'],int(r['human_residue_number']))))
    tsv(out/'SLC30A10_topology_boundary_sensitivity.tsv',candidates)
    (ROOT/'results/step4_qc.json').write_text(json.dumps(summary,indent=2)+'\n')
    # Figures use sequence coordinates only.
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(2,1,figsize=(13,5),sharex=True,gridspec_kw={'height_ratios':[2,1]})
    for y,(name,mask,color) in enumerate([('Phobius',m1,'#5893b0'),('SCAMPI-single',m2,'#b084ba'),('Strict consensus',strict,'#22766e')]):
        for h,(a,b) in enumerate(runs(mask),1):
            axes[0].broken_barh([(a+.5,b-a+1)],(y-.25,.5),facecolors=color)
            if name=='Strict consensus': axes[0].text((a+b)/2+1,y,str(h),ha='center',va='center',color='white',fontsize=8)
    axes[0].set(yticks=[0,1,2],yticklabels=['Phobius','SCAMPI-single','Strict consensus'],title='Blind sequence-based membrane topology')
    groups=[('Acidic DE','DE','#c54745'),('Basic KRH','KRH','#3d63a7'),('Polar STNQCY','STNQCY','#248269')]
    for y,(label,letters,color) in enumerate(groups):
        pos=[i+1 for i,a in enumerate(target) if a in letters]; axes[1].scatter(pos,[y]*len(pos),marker='|',s=65,color=color)
    axes[1].set(yticks=[0,1,2],yticklabels=[g[0] for g in groups],xlabel='Human SLC30A10 residue number',xlim=(1,n)); fig.tight_layout(); fig.savefig(ROOT/'figures/SLC30A10_topology_map.png',dpi=180); plt.close(fig)
    fig,ax=plt.subplots(figsize=(13,4.8))
    for a,b in prop['helices']: ax.axvspan(a+.5,b+1.5,color='#22766e',alpha=.14)
    ax.plot(range(1,n+1),scores,color='#6c4298',lw=1,label='Strict-consensus score'); ax.plot(range(1,n+1),uscores,color='#9b9b9b',lw=.7,alpha=.65,label='Union sensitivity')
    for r in top[:10]:
        x=int(r['human_residue_number']); y=r['transport_score']; ax.annotate(r['human_residue']+str(x),(x,y),xytext=(0,12+(x%3)*10),textcoords='offset points',ha='center',fontsize=8,rotation=45,arrowprops=dict(arrowstyle='-',lw=.5,color='gray'))
    ax.set(xlabel='Human SLC30A10 residue number',ylabel='Heuristic transport-candidate score',xlim=(1,n),ylim=(0,max(scores+uscores)*1.35),title='Blind topology-aware transport candidates · labels show top 10'); ax.legend(loc='upper right'); fig.tight_layout(); fig.savefig(ROOT/'figures/SLC30A10_topology_transport_score.png',dpi=180); plt.close(fig)
    meta1=json.loads((raw/'phobius.json.provenance.json').read_text()); meta2=json.loads((raw/'scampi_query.top.provenance.json').read_text())
    report=['# Step 4: blind topology and sequence context','', 'Two independent single-sequence predictors were used. No functional residue annotations, homolog retrieval, experimental comparison, structures, or disorder prediction were used.','', '## Predictor methods and provenance','',f'- Phobius normal HMM service: https://phobius.sbc.su.se/api ; retrieved {meta1["date"]}. Exact engine/build version not exposed. Orientation: '+ph['topology']+'. No signal peptide predicted. Raw JSON contains a posterior SVG; numerical confidence not supplied/extracted.',f'- SCAMPI2 SCAMPI-single: https://scampi.bioinfo.se/pred/help/ ; retrieved {meta2["date"]}. Exact service build not exposed. Orientation states I/O/M preserved in the consensus TSV. No numerical confidence supplied. Forced new single-sequence job; no MSA mode.', '- Both predictors place N and C termini inside. These are predictions, not measured orientations.','', '```json',json.dumps(summary,indent=2),'```','', '## Fixed scoring formulas and categories','',(ROOT/'data/processed/step4_prespecified_methods.md').read_text(),'','## Primary top 20 (strict consensus)','', '| Residue | Assignment | Score | Ortholog identity | Step3 percentile | Chemical rationale |','|---|---|---:|---:|---:|---|']
    for r in top: report.append(f'| {r["human_residue"]}{r["human_residue_number"]} | {r["assignment"]} | {r["transport_score"]:.5f} | {float(r["ortholog_identity"]):.4f} | {float(r["specificity_percentile"]):.3f} | {r["physicochemical_rationale"]} |')
    report+=['','## Boundary sensitivity','', f'Strict/union Spearman: {summary["strict_union_spearman"]:.6f}; shared top20: {summary["top20_shared"]}/20. Highly sensitive means >10 percentile points or any top20 membership change. Full per-residue results are in SLC30A10_topology_boundary_sensitivity.tsv.','', '| Sensitive residue | Strict percentile | Union percentile | Top20 membership change |','|---|---:|---:|---|']
    for r in sensitive: report.append(f'| {r["human_residue"]}{r["human_residue_number"]} | {r["transport_percentile"]:.3f} | {r["union_transport_percentile"]:.3f} | {r["top20_membership_changes"]} |')
    report+=['','## Comparison with Step 3','', 'Original specificity scores and percentiles are unchanged. Shared top20 positions: '+str(summary['step3_top20_shared'])+'. Secondary ranking adds chemical and location priors; it is not a replacement for Step 3.','', '## Limitations','', 'Predictor agreement is not calibrated confidence. TM intersection can shorten helices; the union sensitivity quantifies this choice but does not sample all possible topologies. Sequence chemical groups suggest possible roles only; geometry, protonation, oligomerization and transport function are untested. Long non-TM is a length proxy and must not be read as predicted disorder. Equal sequence weighting and provisional orthology from earlier steps remain limitations. Service model versions are not exposed, so archived outputs define exact reproducibility.','', 'Commands: `python3 -B scripts/fetch_topology_predictions.py` (public services), then `scripts/remote_run.sh "python -B scripts/analyze_residue_context.py"` (remote scoring). No new software installed.']
    (ROOT/'reports/step4_topology_sequence_context.md').write_text('\n'.join(report)+'\n')
    paths=[ROOT/'data/processed/SLC30A10_topology_consensus.tsv',ROOT/'results/step4_qc.json',ROOT/'reports/step4_topology_sequence_context.md',ROOT/'figures/SLC30A10_topology_map.png',ROOT/'figures/SLC30A10_topology_transport_score.png']+list(out.glob('SLC30A10_topology*.tsv'))+[out/'SLC30A10_residue_context.tsv']
    (ROOT/'results/step4_outputs.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in paths))
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
