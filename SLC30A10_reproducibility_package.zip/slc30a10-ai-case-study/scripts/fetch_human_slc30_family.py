#!/usr/bin/env python3
"""Fetch reviewed human SLC30A1-SLC30A10 canonical sequences."""
from slc30_dataset_common import main
if __name__ == '__main__':
    main('family')
