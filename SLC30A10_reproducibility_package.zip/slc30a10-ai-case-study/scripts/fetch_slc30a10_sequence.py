#!/usr/bin/env python3
"""Fetch identity/sequence fields only; never request annotation or literature.

Run: python3 -B scripts/fetch_slc30a10_sequence.py
Repeat without changing the frozen input: use --output-dir data/rechecks/run_name
Existing canonical outputs are never overwritten. Python standard library only.
"""
import argparse
import csv
import hashlib
import io
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

QUERY = '(gene_exact:SLC30A10) AND (organism_id:9606)'
FIELDS = 'accession,id,gene_primary,organism_name,organism_id,reviewed,length,sequence'
BASE = 'https://rest.uniprot.org/uniprotkb/'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.output_dir.resolve()
    fasta = root / 'sequences/SLC30A10_human_canonical.fasta'
    checksum = fasta.with_suffix('.sha256')
    metadata = root / 'data/processed/SLC30A10_sequence_metadata.tsv'
    if any(p.exists() for p in (fasta, checksum, metadata)):
        raise RuntimeError('Frozen output exists; use a new --output-dir for a repeat retrieval.')
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    raw = root / 'data/raw' / ('uniprot_sequence_' + stamp)
    raw.mkdir(parents=True, exist_ok=False)
    requests = []

    def fetch(url, filename):
        with urlopen(Request(url, headers={'User-Agent': 'slc30a10-blind-sequence/1.0'}), timeout=20) as response:
            body = response.read()
            info = {'url': url, 'retrieved_utc': datetime.now(timezone.utc).isoformat(),
                    'headers': dict(response.headers), 'sha256': hashlib.sha256(body).hexdigest()}
        (raw / filename).write_bytes(body)
        requests.append(info)
        (raw / 'provenance.json').write_text(json.dumps({'requests': requests,
            'python': sys.version, 'platform': platform.platform(), 'argv': sys.argv,
            'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2) + '\n')
        return body

    url = BASE + 'search?' + urlencode({'query': QUERY, 'format': 'tsv', 'fields': FIELDS, 'size': 500})
    body = fetch(url, 'query.tsv')
    if 'rel="next"' in requests[-1]['headers'].get('Link', ''):
        raise RuntimeError('Unexpected pagination; refuse incomplete accession resolution.')
    rows = list(csv.DictReader(io.StringIO(body.decode()), delimiter='\t'))
    selected = [r for r in rows if r['Reviewed'] == 'reviewed' and
                r['Gene Names (primary)'] == 'SLC30A10' and r['Organism (ID)'] == '9606']
    if len(selected) != 1:
        raise RuntimeError('Expected exactly one reviewed exact-gene human entry; found %d' % len(selected))
    row = selected[0]
    accession = row['Entry']
    if not accession.isalnum():
        raise RuntimeError('Unexpected primary accession format')
    # The primary accession FASTA endpoint supplies the canonical entry sequence.
    content = fetch(BASE + accession + '.fasta', 'canonical.fasta')
    lines = content.decode('ascii').splitlines()
    if sum(line.startswith('>') for line in lines) != 1 or not lines[0].startswith('>sp|' + accession + '|'):
        raise RuntimeError('Expected one reviewed primary-accession FASTA record')
    sequence = ''.join(lines[1:])
    if not sequence or set(sequence) - set('ACDEFGHIKLMNPQRSTVWY'):
        raise RuntimeError('Empty sequence or nonstandard/ambiguous/stop residue')
    if sequence != row['Sequence'] or len(sequence) != int(row['Length']):
        raise RuntimeError('Search sequence/length does not match canonical FASTA')
    selection = ('Unique reviewed entry among exact-gene SLC30A10, taxonomy 9606 query results; '
                 'canonical sequence from primary-accession FASTA endpoint, matched to search sequence.')
    record = dict(database='UniProtKB', accession=accession, entry_name=row['Entry Name'],
        gene=row['Gene Names (primary)'], organism=row['Organism'], taxonomy_id=row['Organism (ID)'],
        reviewed_status=row['Reviewed'], canonical_status='canonical (primary accession FASTA)',
        sequence_length=len(sequence), source_query=QUERY, retrieval_date=requests[-1]['retrieved_utc'],
        source_query_url=url, fasta_url=requests[-1]['url'], selection_method=selection,
        query_result_count=len(rows), raw_provenance=str(raw.relative_to(root)))
    for p in (fasta, metadata):
        p.parent.mkdir(parents=True, exist_ok=True)
    with fasta.open('xb') as handle:
        handle.write(content)
    digest = hashlib.sha256(content).hexdigest()
    with checksum.open('x') as handle:
        handle.write(digest + '  sequences/' + fasta.name + '\n')
    with metadata.open('x', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(record), delimiter='\t')
        writer.writeheader()
        writer.writerow(record)
    qc = dict(accession=accession, reviewed=True, canonical=True, records=1,
              standard_amino_acids_only=True, no_stops=True, no_ambiguous_residues=True,
              length=len(sequence), n_terminal_10=sequence[:10], c_terminal_10=sequence[-10:],
              fasta_sha256=digest, selection_method=selection)
    (raw / 'local_qc.json').write_text(json.dumps(qc, indent=2) + '\n')
    print(json.dumps(qc, indent=2))


if __name__ == '__main__':
    main()
