#!/usr/bin/env python3
"""Validate final panel eligibility, unchanged scores, and chemistry arithmetic."""
import csv,json,hashlib,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if (ROOT/'reports/BLIND_PHASE_LOCKED.txt').exists(): raise RuntimeError('Locked: do not create new validation outputs')
read=lambda p:list(csv.DictReader((ROOT/p).open(),delimiter='\t'))
for p,h in json.loads((ROOT/'data/processed/step6_input_ranking_hashes.json').read_text())['files'].items(): assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h
h=json.loads((ROOT/'data/processed/step6_control_selection_correction.json').read_text())['unchanged_mutation_ranking_sha256']
assert hashlib.sha256((ROOT/'results/tables/SLC30A10_mutation_prioritization.tsv').read_bytes()).hexdigest()==h
mutations=read('results/tables/SLC30A10_mutation_prioritization.tsv'); bymutation={r['mutation']:r for r in mutations}; assert len(mutations)==len(bymutation)
seq=''.join((ROOT/'sequences/SLC30A10_human_canonical.fasta').read_text().splitlines()[1:])
for r in mutations:
    i=int(r['residue_position']); assert seq[i-1]==r['wild_type'] and r['mutation']==r['wild_type']+str(i)+r['mutant']
    expected=float(r['step5_structure_score'])*float(r['ortholog_conservation'])*(.25+.75*float(r['chemical_loss_factor']))*(.5+.25*bool(r['polar_cluster_membership'])+.25*bool(r['cavity_membership']))*(.5+.5*min(int(r['cross_helix_polar_neighbors'])/3,1))
    assert math.isclose(expected,float(r['mutation_priority_score']),abs_tol=1e-12)
panel=read('results/tables/SLC30A10_final_blind_mutation_panel.tsv')
assert len(panel)==16 and len({r['residue_position'] for r in panel})==14 and len({r['mutation'] for r in panel})==16
for r in panel:
    m=bymutation[r['mutation']]; assert float(r['mutation_priority_score'])==float(m['mutation_priority_score'])
    group=r['hypothesis_group']
    if group!='control': assert m[{'G1':'group1_eligible','G2':'group2_eligible','G3':'group3_eligible'}[group]]=='True'
for group,number in [('G1',5),('G2',4),('G3',3)]: assert len({r['residue_position'] for r in panel if r['hypothesis_group']==group})==number
matched=[r for r in mutations if int(r['TM_helix'])>0 and float(r['pLDDT'])>=80]; values=sorted(float(r['mutation_priority_score']) for r in matched); cutoff=values[(len(values)-1)//4]
controls=[r for r in panel if r['hypothesis_group']=='control']; assert len(controls)==2
for r in controls:
    m=bymutation[r['mutation']]; assert float(m['mutation_priority_score'])<=cutoff and float(m['chemical_loss_factor'])<=.25 and float(m['pLDDT'])>=80 and int(m['TM_helix'])>0
report=(ROOT/'reports/FINAL_BLIND_PREDICTION.md').read_text()
assert 'No target-paper evidence has been used' in report
for r in panel: assert r['mutation'] in report
record={'status':'PASS','mutation_count':len(mutations),'panel_mutations':len(panel),'panel_positions':14,'controls':[r['mutation'] for r in controls],'control_matched_pool_cutoff':cutoff,'checks':['Prior Step3–5 ranking hashes unchanged','Primary Step6 ranking hash unchanged after control-only correction','WT numbering and mutation uniqueness','Independent priority arithmetic','5/4/3 residue-group eligibility','Two well-modeled low-priority topology-matched controls','Final report contains panel and blindness statement']}
(ROOT/'results/step6_validation.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps(record,indent=2))
