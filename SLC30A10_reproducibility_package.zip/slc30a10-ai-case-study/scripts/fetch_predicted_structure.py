#!/usr/bin/env python3
"""Retrieve only AlphaFold DB prediction assets; never query experimental PDB."""
import csv,hashlib,json,urllib.request
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]; raw=ROOT/'data/raw/structure'; raw.mkdir(parents=True,exist_ok=True)
acc=next(csv.DictReader((ROOT/'data/processed/SLC30A10_sequence_metadata.tsv').open(),delimiter='\t'))['accession']
f=ROOT/'sequences/SLC30A10_human_canonical.fasta'; target=''.join(f.read_text().splitlines()[1:]); assert hashlib.sha256(f.read_bytes()).hexdigest()==f.with_suffix('.sha256').read_text().split()[0]
records=json.loads((raw/'retrieval_provenance.json').read_text()) if (raw/'retrieval_provenance.json').exists() else []
def fetch(url,path):
 assert url.startswith('https://alphafold.ebi.ac.uk/')
 if path.exists():
  matches=[r for r in records if r['file']==str(path.relative_to(ROOT)) and r['url']==url]
  assert len(matches)==1 and hashlib.sha256(path.read_bytes()).hexdigest()==matches[0]['sha256']
  return path.read_bytes()
 with urllib.request.urlopen(url,timeout=30) as r: body=r.read(); headers=dict(r.headers)
 path.write_bytes(body); records.append(dict(url=url,file=str(path.relative_to(ROOT)),retrieval_date=datetime.now(timezone.utc).isoformat(),sha256=hashlib.sha256(body).hexdigest(),headers=headers))
 (raw/'retrieval_provenance.json').write_text(json.dumps(records,indent=2)+'\n'); return body
models=json.loads(fetch('https://alphafold.ebi.ac.uk/api/prediction/'+acc,raw/'alphafold_api.json'))
selected=[m for m in models if m.get('uniprotAccession')==acc and m.get('uniprotSequence')==target and m.get('uniprotStart')==1 and m.get('uniprotEnd')==len(target)]
if len(selected)!=1: raise RuntimeError('No unique full-length sequence-matched model; stop before prediction')
m=selected[0]; (raw/'selected_model.json').write_text(json.dumps(m,indent=2)+'\n')
for key in ['pdbUrl','cifUrl','paeDocUrl','plddtDocUrl']:
 if m.get(key):
  url=m[key]; destination=(ROOT/'structures/predicted' if key in ['pdbUrl','cifUrl'] else raw)/url.rsplit('/',1)[-1]; fetch(url,destination)
print(json.dumps({k:m.get(k) for k in ['modelEntityId','latestVersion','toolUsed','modelCreatedDate','pdbUrl','cifUrl','paeDocUrl','plddtDocUrl']},indent=2))
