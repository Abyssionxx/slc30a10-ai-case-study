#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
REMOTE=/path/to/projects/slc30a10_ai
SSH='ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o UpdateHostKeys=no -o ConnectTimeout=10'
if [[ $# -gt 1 || ( $# -eq 1 && $1 != --dry-run ) ]]; then
    echo "Usage: $0 [--dry-run]" >&2; exit 2
fi
# No --delete. Preserve output directory structure, but do not upload outputs.
# mkdir affects only the project itself; its parent must already exist.
if [[ $# -eq 0 ]]; then
    $SSH slc-server "test -d '$REMOTE' || mkdir -- '$REMOTE'"
fi
rsync -av --safe-links "${1:---human-readable}" -e "$SSH" \
    --exclude='.git/' --exclude='.DS_Store' --exclude='__pycache__/' \
    --exclude='*.pyc' --exclude='*.pyo' --exclude='.runtime/' \
    --include='*/' --exclude='/results/***' --exclude='/figures/***' \
    --exclude='/logs/***' --exclude='/reports/***' --exclude='*.log' \
    "$ROOT/" "slc-server:$REMOTE/"
