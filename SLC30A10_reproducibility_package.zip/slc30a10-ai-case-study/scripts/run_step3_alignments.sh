#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p alignments logs reports results/tables
for f in sequences/SLC30A10_human_canonical.sha256 sequences/SLC30A10_orthologs.sha256 sequences/human_SLC30_family.sha256; do sha256sum -c "$f"; done
for name in SLC30A10_orthologs human_SLC30_family; do
    test ! -e "alignments/${name}_mafft.fasta" || { echo "Refusing to overwrite alignment" >&2; exit 1; }
done
{
    date -u +%FT%TZ
    command -v mafft
    mafft --version 2>&1
    python --version
    sha256sum scripts/run_step3_alignments.sh scripts/analyze_sequence_conservation.py data/processed/step3_prespecified_methods.md
} > logs/step3_alignment_provenance.txt
for name in SLC30A10_orthologs human_SLC30_family; do
    printf 'timeout 1200s mafft --auto --thread 8 --threadit 0 sequences/%s.fasta > alignments/%s_mafft.fasta 2> logs/%s_mafft.stderr.txt\n' "$name" "$name" "$name" >> logs/step3_alignment_provenance.txt
    timeout 1200s mafft --auto --thread 8 --threadit 0 "sequences/${name}.fasta" > "alignments/${name}_mafft.fasta" 2> "logs/${name}_mafft.stderr.txt"
    sha256sum "alignments/${name}_mafft.fasta" >> logs/step3_alignment_provenance.txt
    date -u +%FT%TZ >> logs/step3_alignment_provenance.txt
done
python -B scripts/analyze_sequence_conservation.py
