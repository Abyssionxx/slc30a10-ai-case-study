#!/usr/bin/env python3
"""Independent arithmetic/geometry and frozen-output checks for Step 5."""
import csv,hashlib,json,math,itertools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def read(name): return list(csv.DictReader((ROOT/name).open(),delimiter='\t'))
for manifest in ['step3_outputs.sha256','step4_outputs.sha256','step5_outputs.sha256']:
    for line in (ROOT/'results'/manifest).read_text().splitlines():
        digest,name=line.split('  ',1); assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
context=read('results/tables/SLC30A10_structural_context.tsv'); ranked=read('results/tables/SLC30A10_structure_transport_candidates.tsv')
assert len(context)==len(ranked)==485
assert {int(r['residue_number']) for r in ranked}==set(range(1,486))
xyz={int(r['residue_number']):tuple(float(r[k]) for k in ['x','y','z']) for r in context}
old3={int(r['human_residue_number']):r for r in read('results/tables/SLC30A10_sequence_specificity.tsv')}
old4={int(r['human_residue_number']):r for r in read('results/tables/SLC30A10_topology_transport_candidates.tsv')}
for r in ranked:
    i=int(r['residue_number']); assert float(r['step3_specificity_score'])==float(old3[i]['specificity_score']); assert float(r['step4_transport_score'])==float(old4[i]['transport_score'])
    L=1 if int(r['TM_helix']) else .6 if int(r['associated_near_TM_helix']) else .1
    expected=float(r['ortholog_identity'])*(.5+.5*float(r['step4_transport_score']))*L*(.4+.2*min(int(r['cross_helix_polar_neighbors6'])/3,1)+.2*bool(r['cluster_membership'])+.2*bool(r['cavity_membership']))*float(r['pLDDT'])/100
    assert math.isclose(expected,float(r['step5_score']),abs_tol=1e-12)
clusters=[r for r in read('results/tables/SLC30A10_TM_polar_clusters.tsv') if r['variant']=='strict_6A_all']
valid_combos=0
for cluster in clusters:
    members=[int(x[1:]) for x in cluster['members'].split(';')]
    assert len(members)==int(cluster['cluster_size'])
    # Independent connected-component traversal at the specified 6 A cutoff.
    visited={members[0]}
    while True:
        expanded=visited|{j for j in members if any(math.dist(xyz[i],xyz[j])<=6 for i in visited)}
        if expanded==visited: break
        visited=expanded
    assert visited==set(members)
    eligible=[i for i in members if context[i-1]['amino_acid'] in 'DEHNQSTCY']
    for size in [3,4]:
        for combo in itertools.combinations(eligible,size):
            helices={int(context[i-1]['TM_helix']) for i in combo}-{0}
            if len(helices)>=2 and all(math.dist(xyz[i],xyz[j])<=6 for i,j in itertools.combinations(combo,2)): valid_combos+=1
assert valid_combos==len(read('results/tables/SLC30A10_candidate_coordination_constellations.tsv'))
voxels=read('results/intermediate/SLC30A10_cavity_voxels.tsv')
for c in read('results/tables/SLC30A10_cavities.tsv'):
    count=sum(v['cavity_id']==c['cavity_id'] for v in voxels)
    assert count==int(c['voxel_count']) and count*8==int(c['volume_A3'])
record={'status':'PASS','checks':['Step3/4/5 manifest hashes','485 positions and unchanged Step3/4 scores','Independent Step5 score recomputation','Primary cluster connectivity','Independent constellation enumeration','Cavity voxel volumes'],'constellation_count':valid_combos,'script_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ['scripts/fetch_predicted_structure.py','scripts/analyze_structure_qc.py','scripts/find_transmembrane_polar_clusters.py','scripts/validate_step5.py','data/processed/step5_prespecified_methods.md']}}
(ROOT/'results/step5_validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
