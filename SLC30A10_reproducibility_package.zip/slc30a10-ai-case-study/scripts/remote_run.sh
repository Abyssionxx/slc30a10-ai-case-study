#!/bin/bash
set -euo pipefail
if [[ $# -eq 0 ]]; then
    echo "Usage: $0 'shell command' OR $0 executable arg ..." >&2
    echo "Jobs expected to exceed 30 minutes require approval before invocation." >&2
    exit 2
fi
# One argument is a shell command; multiple arguments preserve argv quoting.
if [[ $# -eq 1 ]]; then
    command_text=$1
else
    printf -v command_text '%q ' "$@"
fi
{
    cat <<'REMOTE_SETUP'
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
source /opt/miniforge3/etc/profile.d/conda.sh
conda activate /path/to/conda/envs/slc30a10_ai
cd /path/to/projects/slc30a10_ai
# Keep ordinary temporary/cache writes in the project.
mkdir -p .runtime/tmp .runtime/cache
export TMPDIR="$PWD/.runtime/tmp" XDG_CACHE_HOME="$PWD/.runtime/cache"
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
export NUMEXPR_NUM_THREADS=8 NUMEXPR_MAX_THREADS=8 VECLIB_MAXIMUM_THREADS=8
export BLIS_NUM_THREADS=8 OMP_THREAD_LIMIT=8
export CUDA_VISIBLE_DEVICES=''
# These are defaults, not an OS resource sandbox. Use <=8 tool-specific threads.
REMOTE_SETUP
    printf 'exec bash --noprofile --norc -euo pipefail -c %q\n' "$command_text"
} | ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o UpdateHostKeys=no \
    -o ConnectTimeout=10 slc-server 'bash --noprofile --norc -s'
