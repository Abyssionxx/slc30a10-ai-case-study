#!/usr/bin/env python3
"""One-time local freeze after validated review; never overwrites a lock."""
import hashlib,json,subprocess
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
lock=ROOT/'reports/BLIND_PHASE_LOCKED.txt'
if lock.exists(): raise RuntimeError('Blind phase already locked')
assert json.loads((ROOT/'results/step6_validation.json').read_text())['status']=='PASS'
for p,h in json.loads((ROOT/'data/processed/step6_input_ranking_hashes.json').read_text())['files'].items(): assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h
files=['reports/FINAL_BLIND_PREDICTION.md','results/tables/SLC30A10_final_blind_mutation_panel.tsv','results/tables/SLC30A10_sequence_specificity.tsv','results/tables/SLC30A10_topology_transport_candidates.tsv','results/tables/SLC30A10_structure_transport_candidates.tsv']
def checksum(p): return hashlib.sha256((ROOT/p).read_bytes()).hexdigest()
final=ROOT/'results/FINAL_BLIND_PREDICTION.sha256'; assert not final.exists()
final.write_text(''.join(checksum(p)+'  '+p+'\n' for p in files))
# Git-tracked checkpoint files are the declared snapshot universe; no caches or .git internals.
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
paths=sorted({p for p in tracked if p}|{'results/FINAL_BLIND_PREDICTION.sha256'})
full=ROOT/'results/BLIND_PHASE_FILES.sha256'; assert not full.exists()
full.write_text(''.join(checksum(p)+'  '+p+'\n' for p in paths))
parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
text='UTC freeze timestamp: '+datetime.now(timezone.utc).isoformat()+'\nGit checkpoint commit before lock: '+parent+'\nFinal freeze commit: the subsequent commit containing this lock (git rev-parse HEAD).\n\n'
text+='Blind predictions frozen before comparison with experimental ground truth.\n\n'
text+='No target-paper evidence, experimental SLC30A10 structures, reported mutations, disease variants, or literature-derived functional residues were used.\n'
text+='No blind prediction files may be modified after this lock. Future comparison must use separate files.\n\n'
for p in files+['results/FINAL_BLIND_PREDICTION.sha256','results/BLIND_PHASE_FILES.sha256']: text+=checksum(p)+'  '+p+'\n'
lock.write_text(text)
print(text)
