"""Sequence-only UniProt dataset construction; no functional annotations requested."""
import argparse, csv, hashlib, io, json, re, statistics, sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode

ROOT = Path(__file__).resolve().parents[1]
FIELDS = 'accession,id,gene_primary,protein_name,organism_name,organism_id,reviewed,length,fragment,lineage,sequence'
QUERIES = {'orthologs':'(gene_exact:SLC30A10) AND (taxonomy_id:7742)',
           'family':'(gene:SLC30*) AND (organism_id:9606) AND (reviewed:true)'}
NAMES = {'orthologs':'SLC30A10_orthologs', 'family':'human_SLC30_family'}
AA = set('ACDEFGHIKLMNPQRSTVWY')

def write_tsv(path, rows):
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter='\t'); w.writeheader(); w.writerows(rows)

def main(kind):
    parser=argparse.ArgumentParser()
    parser.add_argument('--raw-dir', type=Path, help='Replay a previously saved query without network access')
    args=parser.parse_args()
    name=NAMES[kind]
    fasta=ROOT/'sequences'/f'{name}.fasta'
    if fasta.exists(): raise RuntimeError('Refusing to overwrite frozen dataset')
    target_path=ROOT/'sequences/SLC30A10_human_canonical.fasta'
    target_bytes=target_path.read_bytes()
    assert hashlib.sha256(target_bytes).hexdigest()==target_path.with_suffix('.sha256').read_text().split()[0]
    target=''.join(target_bytes.decode().splitlines()[1:])
    target_acc=target_bytes.decode().splitlines()[0].split('|')[1]
    if args.raw_dir:
        raw=args.raw_dir.resolve()
        provenance=json.loads((raw/'provenance.json').read_text())
    else:
        raw=ROOT/'data/raw'/('uniprot_'+name+'_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
        raw.mkdir(parents=True)
        url='https://rest.uniprot.org/uniprotkb/search?'+urlencode(dict(query=QUERIES[kind],format='tsv',fields=FIELDS,size=500))
        provenance={'query':QUERIES[kind],'pages':[], 'python':sys.version,'command':sys.argv}
        while url:
            with urlopen(Request(url,headers={'User-Agent':'slc30-blind-dataset/1.0'}),timeout=20) as r:
                data=r.read(); headers=dict(r.headers); link=r.headers.get('Link','')
            filename=f'page_{len(provenance["pages"])+1:03}.tsv'
            (raw/filename).write_bytes(data)
            provenance['pages'].append(dict(file=filename,url=url,headers=headers,sha256=hashlib.sha256(data).hexdigest(),retrieved_utc=datetime.now(timezone.utc).isoformat()))
            (raw/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
            match=re.search(r'<([^>]+)>; rel="next"',link); url=match.group(1) if match else None
    rows=[]
    for page in provenance['pages']:
        data=(raw/page['file']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==page['sha256']
        rows.extend(csv.DictReader(io.StringIO(data.decode()),delimiter='\t'))
    print('Query records:',len(rows), 'columns:',list(rows[0]),flush=True)
    def clade(r):
        line=r['Taxonomic lineage']
        for key in ['Mammalia','Aves','Lepidosauria','Testudines','Crocodylia','Amphibia','Actinopterygii','Chondrichthyes','Dipnoi','Coelacanthimorpha','Cyclostomata']:
            if key in line: return key
        return 'Other vertebrates'
    candidates=[]
    for r in rows:
        seq=r['Sequence']; ratio=len(seq)/len(target)
        r['decision']=''; r['length_ratio']=round(ratio,4); r['length_flag']=not 0.8<=ratio<=1.2
        r['clade']=clade(r); r['genus']=r['Organism'].split()[0]
        reasons=[]
        if not seq or len(seq)!=int(r['Length']): reasons.append('empty or inconsistent length')
        if set(seq)-AA: reasons.append('nonstandard/ambiguous residues (strict zero tolerance)')
        if r['Fragment'].strip().lower() not in ('','false','no'): reasons.append('database fragment flag')
        if kind=='orthologs':
            if r['Gene Names (primary)'].upper()!='SLC30A10': reasons.append('primary gene not exact SLC30A10')
            if r['length_flag']: reasons.append('outside prespecified 80-120% length window; completeness uncertain')
            if not seq.startswith('M'): reasons.append('missing initiator methionine; possible partial model')
            if r['Organism (ID)']=='9606' and (r['Entry']!=target_acc or seq!=target): reasons.append('human representative must match frozen target')
        else:
            if not re.fullmatch(r'SLC30A(?:[1-9]|10)',r['Gene Names (primary)']): reasons.append('not exact numbered SLC30A1-SLC30A10 primary gene')
            if r['Organism (ID)']!='9606' or r['Reviewed']!='reviewed': reasons.append('not reviewed human')
        if reasons: r['decision']='excluded: '+'; '.join(reasons)
        else: candidates.append(r)
    # Review status, proximity to target length, then accession; no residue annotations.
    def rank(r): return (r['Reviewed']!='reviewed',abs(int(r['Length'])-len(target)),r['Entry'])
    if kind=='orthologs':
        species={}
        for r in sorted(candidates,key=rank):
            tax=r['Organism (ID)']
            if tax in species: r['decision']='excluded: alternate same-species entry; reviewed/length/accession preference'
            else: species[tax]=r
        groups=defaultdict(list)
        for r in species.values(): groups[r['clade']].append(r)
        for g in groups: groups[g].sort(key=rank)
        selected=[]; used_genera=set()
        human=[r for r in species.values() if r['Organism (ID)']=='9606']
        for r in human: selected.append(r); used_genera.add(r['genus']); groups[r['clade']].remove(r)
        # Round-robin clades, favoring new genera; deterministic cap of 60.
        while len(selected)<60 and any(groups.values()):
            for g in sorted(groups):
                if not groups[g] or len(selected)>=60: continue
                index=next((i for i,r in enumerate(groups[g]) if r['genus'] not in used_genera),0)
                r=groups[g].pop(index); selected.append(r); used_genera.add(r['genus'])
        for pool in groups.values():
            for r in pool: r['decision']='excluded: diversity-balanced 60-sequence cap'
    else:
        selected=sorted(candidates,key=lambda r:int(r['Gene Names (primary)'][6:]))
        genes=[r['Gene Names (primary)'] for r in selected]
        assert len(genes)==len(set(genes)), 'Multiple reviewed records per family gene require review'
        assert set(genes)=={'SLC30A'+str(i) for i in range(1,11)}, 'Incomplete family set'
    assert selected
    from Bio.Align import PairwiseAligner
    import Bio
    aligner=PairwiseAligner(); aligner.mode='global'; aligner.match_score=2; aligner.mismatch_score=-1
    aligner.open_gap_score=-5; aligner.extend_gap_score=-0.5
    metadata=[]
    for r in selected:
        r['decision']='retained'
        seq=r['Sequence']; alignment=aligner.align(target,seq)[0]
        indices=alignment.indices
        matches=sum(i>=0 and j>=0 and target[i]==seq[j] for i,j in zip(indices[0],indices[1]))
        pid=100*matches/indices.shape[1]
        metadata.append(dict(accession=r['Entry'],gene=r['Gene Names (primary)'],protein_name=r['Protein names'],organism=r['Organism'],taxonomy_id=r['Organism (ID)'],reviewed_status=r['Reviewed'],sequence_length=len(seq),clade=r['clade'],lineage=r['Taxonomic lineage'],length_ratio=r['length_ratio'],length_flag=r['length_flag'],identity_to_human_percent=round(pid,3),sequence=seq,source_query=QUERIES[kind],retrieval_date=provenance['pages'][-1]['retrieved_utc'],raw_directory=str(raw.relative_to(ROOT)),orthology_status='gene-name-based candidate; not phylogenetically confirmed' if kind=='orthologs' else 'human paralog'))
    content=''.join('>'+r['accession']+' gene='+r['gene']+' taxid='+r['taxonomy_id']+'\n'+'\n'.join(r['sequence'][i:i+60] for i in range(0,len(r['sequence']),60))+'\n' for r in metadata)
    fasta.write_text(content)
    digest=hashlib.sha256(fasta.read_bytes()).hexdigest()
    fasta.with_suffix('.sha256').write_text(digest+'  sequences/'+fasta.name+'\n')
    processed=ROOT/'data/processed'
    write_tsv(processed/f'{name}_metadata.tsv',metadata)
    write_tsv(processed/f'{name}_selection_audit.tsv',rows)
    lengths=[r['sequence_length'] for r in metadata]
    qc=dict(dataset=name,sequence_count=len(metadata),species_count=len({r['taxonomy_id'] for r in metadata}),length_min=min(lengths),length_max=max(lengths),length_median=statistics.median(lengths),ambiguous_sequence_count=sum(bool(set(r['sequence'])-AA) for r in metadata),duplicate_sequence_count=len(metadata)-len({r['sequence'] for r in metadata}),accessions_unique=len(metadata)==len({r['accession'] for r in metadata}),species_unique=len(metadata)==len({r['taxonomy_id'] for r in metadata}),clade_counts=dict(Counter(r['clade'] for r in metadata)),reviewed_counts=dict(Counter(r['reviewed_status'] for r in metadata)),length_flagged_retained=sum(r['length_flag'] for r in metadata),identity_min=min(r['identity_to_human_percent'] for r in metadata),identity_max=max(r['identity_to_human_percent'] for r in metadata),identity_method='Biopython global pairwise alignment; match 2, mismatch -1, gap open -5, extend -0.5; identities / all alignment columns including gaps; first optimal alignment; QC only, no MSA',biopython_version=Bio.__version__,sha256=digest,queried_count=len(rows),decision_counts=dict(Counter(r['decision'] for r in rows)))
    (processed/f'{name}_qc.json').write_text(json.dumps(qc,indent=2)+'\n')
    print(json.dumps(qc,indent=2),flush=True)
