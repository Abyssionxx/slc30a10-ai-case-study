#!/usr/bin/env python3
"""Fixed geometry-only clustering, cavity fallback and blind Step5 ranking."""
import csv,json,hashlib,itertools,os,platform
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree,Delaunay
from scipy.spatial.distance import cdist,pdist
from scipy import ndimage
from Bio.PDB import ShrakeRupley,PPBuilder
import Bio,scipy
from analyze_structure_qc import main as qc_main,ROOT
from analyze_residue_context import properties,runs
from analyze_sequence_conservation import percentiles,ranks
os.environ['MPLCONFIGDIR']=str(ROOT/'.runtime/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
POLAR=set('DEKRHNQSTCY'); COORD=set('DEHNQSTCY')

def write(path,rows,fields=None):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else fields,delimiter='\t'); w.writeheader(); w.writerows(rows)

def frame(ca,mask):
    axes=[]
    for a,b in runs(mask):
        _,_,v=np.linalg.svd(ca[a:b+1]-ca[a:b+1].mean(0)); axes.append(v[0])
    _,v=np.linalg.eigh(sum(np.outer(a,a) for a in axes)); normal=v[:,-1]; center=ca[mask].mean(0)
    return center,normal

def geometry_cavities(d,mask):
    ca=d['ca']; center,normal=frame(ca,mask)
    atoms=[]; radii=[]; owners=[]
    for i,r in enumerate(d['residues']):
        for atom in r:
            if atom.element=='H': continue
            atoms.append(atom.coord); owners.append(i); radii.append({'C':1.70,'N':1.55,'O':1.52,'S':1.80}.get(atom.element,1.70)+1.4)
    atoms=np.array(atoms); radii=np.array(radii); owners=np.array(owners); tree=cKDTree(atoms)
    def blocked(points):
        distances,index=tree.query(points,k=16,workers=1)
        answer=np.any(distances<=radii[index],axis=1)
        # Exact fallback in the unusual case of >16 neighbors within max radius.
        for k in np.flatnonzero((~answer)&(distances[:,-1]<=radii.max())):
            near=tree.query_ball_point(points[k],radii.max()); answer[k]=np.any(np.linalg.norm(atoms[near]-points[k],axis=1)<=radii[near])
        return answer
    bounds=ca[mask]; axes=[np.arange(np.floor(bounds[:,j].min()/2)*2,np.ceil(bounds[:,j].max()/2)*2+1,2) for j in range(3)]
    grid=np.stack(np.meshgrid(*axes,indexing='ij'),axis=-1); pts=grid.reshape(-1,3)
    eligible=(Delaunay(bounds).find_simplex(pts)>=0)&(np.abs((pts-center)@normal)<=15)
    selected=np.flatnonzero(eligible); selected=selected[~blocked(pts[selected])]
    rays=list(np.eye(3))+list(-np.eye(3))+[np.array(x)/np.sqrt(3) for x in itertools.product([-1,1],repeat=3)]
    counts=np.zeros(len(selected),int)
    for ray in rays:
        hit=np.zeros(len(selected),bool)
        for step in range(1,11):
            pending=np.flatnonzero(~hit)
            if not len(pending): break
            hit[pending]=blocked(pts[selected[pending]]+step*ray)
        counts+=hit
    occupied=np.zeros(len(pts),bool); occupied[selected[counts>=10]]=True
    labels,num=ndimage.label(occupied.reshape(grid.shape[:3]))
    cavities=[]; voxels=[]; core=properties(mask)['helix']
    for label in range(1,num+1):
        idx=np.flatnonzero(labels.ravel()==label)
        if len(idx)<3: continue
        pocket=pts[idx]; lined=set()
        for neighbors in tree.query_ball_point(pocket,4.5): lined.update(owners[neighbors].tolist())
        helices=sorted(set(core[list(lined)])-{0})
        if len(helices)<2: continue
        cavity_id='V'+str(len(cavities)+1); members=sorted(lined)
        cavities.append(dict(cavity_id=cavity_id,volume_A3=len(idx)*8,voxel_count=len(idx),lining_residues=';'.join(d['target'][i]+str(i+1) for i in members),TM_helices=';'.join(map(str,helices)),acidic_count=sum(d['target'][i] in 'DE' for i in members),polar_charged_count=sum(d['target'][i] in POLAR for i in members),mean_pLDDT=float(np.mean(d['confidence'][members])),members=members))
        for xyz in pocket: voxels.append(dict(cavity_id=cavity_id,x=float(xyz[0]),y=float(xyz[1]),z=float(xyz[2])))
    return cavities,voxels,center,normal

def assignment(mask):
    p=properties(mask); associated=p['helix'].copy()
    for i in np.flatnonzero((associated==0)&(p['distance']<=5)):
        associated[i]=min(range(1,len(p['helices'])+1),key=lambda h:(min(abs(i-p['helices'][h-1][0]),abs(i-p['helices'][h-1][1])),h))
    return p,associated

def graph(d,mask,threshold,exclude):
    p,associated=assignment(mask); valid=d['confidence']>=70 if exclude else np.ones(485,bool)
    nodes=[i for i,a in enumerate(d['target']) if a in POLAR and associated[i]>0 and valid[i]]
    unseen=set(nodes); components=[]
    while unseen:
        start=min(unseen); unseen.remove(start); stack=[start]; component=[]
        while stack:
            x=stack.pop(); component.append(x)
            near={i for i in unseen if d['dist'][x,i]<=threshold}; unseen-=near; stack.extend(sorted(near,reverse=True))
        component=sorted(component)
        helices=sorted(set(p['helix'][component])-{0})
        if len(helices)>=2: components.append(component)
    return components,p,associated,valid

def main():
    d,modelqc=qc_main(); target=d['target']; conf=d['confidence']; d['dist']=cdist(d['reps'],d['reps']); dist=d['dist']; n=485
    masks={name:np.array([r[key]=='True' for r in d['topology']]) for name,key in [('strict','strict_TM'),('Phobius','phobius_TM'),('SCAMPI','scampi_TM')]}
    orth=np.array([float(r['ortholog_identity']) for r in d['s3']]); t4=np.array([float(r['transport_score']) for r in d['s4']]); s3=np.array([float(r['specificity_score']) for r in d['s3']]); p4=np.array([float(r['specificity_percentile']) for r in d['s3']])
    cavities,voxels,center,normal=geometry_cavities(d,masks['strict']); memberships=[[] for _ in range(n)]
    top4=set(np.argsort(-t4,kind='stable')[:20])
    for cavity in cavities:
        cavity['step4_top20_overlap']=';'.join(target[i]+str(i+1) for i in cavity['members'] if i in top4)
        for i in cavity['members']: memberships[i].append(cavity['cavity_id'])
    results={}; clusterrows=[]
    for name,mask in masks.items():
        for threshold in [5,6,8]:
            for exclude in [False,True]:
                key=f'{name}_{threshold}A_'+('pLDDT70' if exclude else 'all')
                components,p,associated,valid=graph(d,mask,threshold,exclude); clusterids=[[] for _ in range(n)]
                for number,members in enumerate(components,1):
                    cluster_id=key+'_C'+str(number)
                    for i in members: clusterids[i].append(cluster_id)
                    pair=pdist(d['reps'][members]); pae=d['pae'][np.ix_(members,members)]; off=~np.eye(len(members),dtype=bool)
                    clusterrows.append(dict(variant=key,cluster_id=cluster_id,threshold_A=threshold,topology=name,exclude_low_confidence=exclude,members=';'.join(target[i]+str(i+1) for i in members),TM_helices=';'.join(map(str,sorted(set(p['helix'][members])-{0}))),acidic_count=sum(target[i] in 'DE' for i in members),polar_coordination_count=sum(target[i] in 'HNQSTCY' for i in members),basic_count=sum(target[i] in 'KR' for i in members),cluster_size=len(members),mean_pairwise_distance=float(pair.mean()),max_pairwise_distance=float(pair.max()),mean_pLDDT=float(conf[members].mean()),mean_pairwise_PAE=float(pae[off].mean()),max_pairwise_PAE=float(pae[off].max()),step3_scores=';'.join(f'{target[i]}{i+1}:{s3[i]:.6f}' for i in members),step4_scores=';'.join(f'{target[i]}{i+1}:{t4[i]:.6f}' for i in members)))
                count=np.zeros(n,int)
                for i in range(n):
                    if associated[i]>0:
                        count[i]=sum(j!=i and valid[j] and p['helix'][j]>0 and p['helix'][j]!=associated[i] and a in POLAR and dist[i,j]<=threshold for j,a in enumerate(target))
                location=np.where(mask,1.,np.where(p['distance']<=5,.6,.1))
                score=orth*(.5+.5*t4)*location*(.4+.2*np.minimum(count/3,1)+.2*np.array([bool(x) for x in clusterids])+.2*np.array([bool(x) for x in memberships]))*conf/100
                score[~valid]=0
                results[key]=dict(score=score,components=components,p=p,associated=associated,clusterids=clusterids,crosscount=count,valid=valid)
    baseline=results['strict_6A_all']; p=baseline['p']; associated=baseline['associated']; base=baseline['score']; brank=percentiles(base); baseids=set(np.argsort(-base,kind='stable')[:20]); bnodes=set().union(*map(set,baseline['components'])) if baseline['components'] else set()
    robustness=[]
    for key,r in results.items():
        ids=set(np.argsort(-r['score'],kind='stable')[:20]); nodes=set().union(*map(set,r['components'])) if r['components'] else set()
        best=[max([len(set(c)&set(x))/len(set(c)|set(x)) for x in r['components']]+[0]) for c in baseline['components']]
        robustness.append(dict(variant=key,spearman=float(np.corrcoef(ranks(base),ranks(r['score']))[0,1]),top20_shared=len(baseids&ids),cluster_count=len(r['components']),clustered_residue_count=len(nodes),clustered_residue_Jaccard=len(nodes&bnodes)/len(nodes|bnodes) if nodes|bnodes else 1.,mean_best_cluster_Jaccard=float(np.mean(best)) if best else 'NA',percentile_shifts_gt10=int(sum(abs(np.array(brank)-percentiles(r['score']))>10)),top20_enter=';'.join(target[i]+str(i+1) for i in sorted(ids-baseids)),top20_leave=';'.join(target[i]+str(i+1) for i in sorted(baseids-ids))))
    # SASA and coarse backbone dihedral secondary-structure labels.
    ShrakeRupley(probe_radius=1.4,n_points=100).compute(d['structure'],level='R')
    ss=['unknown']*n
    for peptide in PPBuilder().build_peptides(d['structure']):
        for residue,(phi,psi) in zip(peptide,peptide.get_phi_psi_list()):
            if phi is None or psi is None: continue
            phi,psi=np.degrees([phi,psi]); ss[residue.id[1]-1]='helix_like' if -100<=phi<=-30 and -80<=psi<=-5 else 'extended_like' if -180<=phi<=-70 and (70<=psi<=180 or -180<=psi<=-120) else 'coil_like'
    context=[]; ranked=[]
    for i,a in enumerate(target):
        near=[j for j in range(n) if j!=i]; other=[j for j in near if p['helix'][j]>0 and p['helix'][j]!=associated[i]]
        row=dict(residue_number=i+1,amino_acid=a,TM_helix=int(p['helix'][i]),associated_near_TM_helix=int(associated[i]),representative_atom='CA' if a=='G' else 'CB',x=float(d['reps'][i,0]),y=float(d['reps'][i,1]),z=float(d['reps'][i,2]),membrane_axis_depth=float((d['reps'][i]-center)@normal),SASA_A2=float(d['residues'][i].sasa),secondary_structure=ss[i],nearest_other_TM_helix_distance=float(min(dist[i,j] for j in other)),polar_charged_within4=sum(target[j] in POLAR and dist[i,j]<=4 for j in near),polar_charged_within6=sum(target[j] in POLAR and dist[i,j]<=6 for j in near),polar_charged_within8=sum(target[j] in POLAR and dist[i,j]<=8 for j in near),acidic_within6=sum(target[j] in 'DE' and dist[i,j]<=6 for j in near),histidine_polar_heteroatom_class_within6=sum(target[j] in 'HNQSTCY' and dist[i,j]<=6 for j in near),pLDDT=float(conf[i]))
        context.append(row)
        neighbors=sorted([j for j in near if target[j] in POLAR],key=lambda j:(dist[i,j],j))[:5]
        ranked.append(dict(residue_number=i+1,amino_acid=a,TM_helix=int(p['helix'][i]),associated_near_TM_helix=int(associated[i]),ortholog_identity=float(orth[i]),step3_specificity_score=float(s3[i]),step3_specificity_percentile=float(p4[i]),step4_transport_score=float(t4[i]),step5_score=float(base[i]),step5_percentile=brank[i],cross_helix_polar_neighbors6=int(baseline['crosscount'][i]),cluster_membership=';'.join(baseline['clusterids'][i]),cavity_membership=';'.join(memberships[i]),nearest_polar_neighbors=';'.join(f'{target[j]}{j+1}:{dist[i,j]:.3f}A' for j in neighbors),pLDDT=float(conf[i])))
    ranked.sort(key=lambda r:(-r['step5_score'],r['residue_number']))
    constellations=[]
    for number,members in enumerate(baseline['components'],1):
        eligible=[i for i in members if target[i] in COORD]
        for size in [3,4]:
            for combo in itertools.combinations(eligible,size):
                helices=set(p['helix'][list(combo)])-{0}
                if len(helices)<2: continue
                pair=pdist(d['reps'][list(combo)]); maximum=float(pair.max())
                if maximum>6: continue
                value=(1-maximum/6)*float(orth[list(combo)].mean())*(.5+.5*float(t4[list(combo)].mean()))
                common=set(memberships[combo[0]])
                for i in combo[1:]: common&=set(memberships[i])
                constellations.append(dict(members=';'.join(target[i]+str(i+1) for i in combo),size=size,TM_helices=';'.join(map(str,sorted(helices))),cluster_id='strict_6A_all_C'+str(number),shared_cavities=';'.join(sorted(common)),max_distance_A=maximum,mean_distance_A=float(pair.mean()),mean_ortholog_identity=float(orth[list(combo)].mean()),mean_step4_score=float(t4[list(combo)].mean()),constellation_score=value))
    constellations.sort(key=lambda r:(-r['constellation_score'],r['members']))
    out=ROOT/'results/tables'
    write(out/'SLC30A10_structural_context.tsv',context)
    write(out/'SLC30A10_TM_polar_clusters.tsv',clusterrows,['variant','cluster_id','members','TM_helices'])
    write(out/'SLC30A10_cavities.tsv',[{k:v for k,v in c.items() if k!='members'} for c in cavities],['cavity_id','volume_A3','lining_residues','TM_helices','acidic_count','polar_charged_count','step4_top20_overlap','mean_pLDDT'])
    write(out/'SLC30A10_structure_transport_candidates.tsv',ranked)
    write(out/'SLC30A10_candidate_coordination_constellations.tsv',constellations,['members','size','TM_helices','cluster_id','shared_cavities','max_distance_A','mean_distance_A','mean_ortholog_identity','mean_step4_score','constellation_score'])
    write(out/'SLC30A10_structure_robustness.tsv',robustness)
    write(ROOT/'results/intermediate/SLC30A10_cavity_voxels.tsv',voxels,['cavity_id','x','y','z'])
    write(out/'SLC30A10_structure_variant_scores.tsv',[dict(residue_number=i+1,amino_acid=target[i],**{k:float(r['score'][i]) for k,r in results.items()}) for i in range(n)])
    summary=dict(primary_cluster_count=len(baseline['components']),cavity_count=len(cavities),constellation_count=len(constellations),triplets=sum(r['size']==3 for r in constellations),quadruplets=sum(r['size']==4 for r in constellations),top20=[r['amino_acid']+str(r['residue_number']) for r in ranked[:20]],top10=[r['amino_acid']+str(r['residue_number']) for r in ranked[:10]],top5=[r['amino_acid']+str(r['residue_number']) for r in ranked[:5]],membrane_center=center.tolist(),membrane_normal_unsigned=normal.tolist(),software=dict(python=platform.python_version(),biopython=Bio.__version__,numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__))
    (ROOT/'results/step5_analysis_qc.json').write_text(json.dumps(summary,indent=2)+'\n')
    # Reproducible visualization orientation computed only from TM coordinates.
    z=normal; x=np.cross(z,[1,0,0] if abs(z[0])<.9 else [0,1,0]); x/=np.linalg.norm(x); y=np.cross(z,x); basis=np.stack([x,y,z],axis=1); coords=(d['ca']-center)@basis
    def backbone(filename,clusters=False):
        fig=plt.figure(figsize=(9,8)); ax=fig.add_subplot(111,projection='3d'); ax.plot(*coords.T,color='#b9b9b9',lw=.8,alpha=.6)
        if not clusters:
            for h,(a,b) in enumerate(p['helices'],1): ax.plot(*coords[a:b+1].T,lw=3,label='TM'+str(h))
        else:
            for number,members in enumerate(baseline['components'],1):
                xyz=(d['reps'][members]-center)@basis; ax.scatter(*xyz.T,s=22,label='Cluster '+str(number))
        ax.set(xlabel='Frame X (A)',ylabel='Frame Y (A)',zlabel='Unsigned TM axis (A)',title='Sequence-predicted model: '+('computed polar clusters' if clusters else 'sequence-derived TM helices'))
        if (clusters and baseline['components']) or not clusters: ax.legend(fontsize=8,loc='upper left')
        ax.set_box_aspect(np.ptp(coords,axis=0)); ax.view_init(elev=15,azim=-65); fig.tight_layout(); fig.savefig(ROOT/'figures'/filename,dpi=180); plt.close(fig)
    backbone('SLC30A10_structure_topology.png'); backbone('SLC30A10_polar_cluster_structure.png',True)
    fig,ax=plt.subplots(figsize=(13,4.5)); ax.plot(range(1,n+1),base,color='#6c4298',lw=1)
    for a,b in p['helices']: ax.axvspan(a+.5,b+1.5,color='#22766e',alpha=.12)
    ax.set(xlabel='Human SLC30A10 residue number',ylabel='Step5 heuristic score',title='Blind structure-aware transport-candidate score',xlim=(1,n)); fig.tight_layout(); fig.savefig(ROOT/'figures/SLC30A10_structure_candidate_scores.png',dpi=180); plt.close(fig)
    pdb=d['pdb'].relative_to(ROOT)
    pml=['# Run from project root: pymol scripts/view_step5_candidates.pml',f'load {pdb}, predicted','hide everything','show cartoon, predicted','color gray80, predicted']
    colors=['cyan','magenta','yellow','orange','green','marine']
    for h,(a,b) in enumerate(p['helices'],1): pml+=[f'select TM{h}, predicted and resi {a+1}-{b+1}',f'color {colors[(h-1)%len(colors)]}, TM{h}']
    for number,members in enumerate(baseline['components'],1): pml += [f'select cluster{number}, predicted and resi '+ '+'.join(str(i+1) for i in members),f'show sticks, cluster{number}']
    pml+=['select top20, predicted and resi '+'+'.join(str(r['residue_number']) for r in ranked[:20]),'show spheres, top20 and name CA','set sphere_scale, 0.3','orient predicted','bg_color white']
    (ROOT/'scripts/view_step5_candidates.pml').write_text('\n'.join(pml)+'\n')
    report=['# Step 5: blind sequence-predicted structural analysis','', 'No experimental SLC30A10 structure, residue annotation, mutation information, literature comparison or docking was used. AlphaFold predictions may have training/template influences; this is not a de novo model trained without historical structural data.','', '## Source and model QC','',f'Model {d["selected"]["modelEntityId"]}, version {d["selected"]["latestVersion"]}; resource describes pipeline as {d["selected"]["toolUsed"]}. PDB: {d["selected"]["pdbUrl"]}. Exact retrieval URLs/dates/checksums: data/raw/structure/retrieval_provenance.json. PDB, mmCIF, pLDDT JSON and PAE JSON preserved. No linked substitution annotations or MSA assets retrieved.','', '```json',json.dumps(modelqc,indent=2),'```','', '## Pre-specified algorithms and formula','',(ROOT/'data/processed/step5_prespecified_methods.md').read_text(),'','## Geometric results','', '```json',json.dumps(summary,indent=2),'```','', '### Primary 6 A polar clusters','']
    for r in clusterrows:
        if r['variant']=='strict_6A_all': report.append(f'- {r["cluster_id"]}: {r["members"]}; helices {r["TM_helices"]}; mean/max pair distance {r["mean_pairwise_distance"]:.2f}/{r["max_pairwise_distance"]:.2f} A; pLDDT {r["mean_pLDDT"]:.1f}; mean/max PAE {r["mean_pairwise_PAE"]:.2f}/{r["max_pairwise_PAE"]:.2f} A.')
    report+=['','### Cavities',f'{len(cavities)} grid-defined internal pockets found. This is the specified geometry fallback, not fpocket/P2Rank.']
    for c in cavities: report.append(f'- {c["cavity_id"]}: probe-center volume {c["volume_A3"]} A^3; lining {c["lining_residues"]}; helices {c["TM_helices"]}; mean pLDDT {c["mean_pLDDT"]:.1f}; Step4 overlap {c["step4_top20_overlap"]}.')
    report+=['','## Top 20 blind structure-aware candidates','', 'First 5 and first 10 rows define top5/top10; ties use residue number.','', '| Rank | Residue | Core/near helix | S3 | S4 | S5 | Cluster | Cavity | pLDDT | Nearest polar neighbors |','|---:|---|---|---:|---:|---:|---|---|---:|---|']
    for k,r in enumerate(ranked[:20],1): report.append(f'| {k} | {r["amino_acid"]}{r["residue_number"]} | {r["TM_helix"]}/{r["associated_near_TM_helix"]} | {r["step3_specificity_score"]:.4f} | {r["step4_transport_score"]:.4f} | {r["step5_score"]:.4f} | {r["cluster_membership"]} | {r["cavity_membership"]} | {r["pLDDT"]:.1f} | {r["nearest_polar_neighbors"]} |')
    report+=['','## Candidate ion-coordination constellations','', f'{len(constellations)} total combinations. These are close representative-atom constellations, not evidence that donor atoms coordinate an ion. The first 20 are shown; all are in the TSV.','', '| Members | Helices | Max distance A | Score | Shared cavity |','|---|---|---:|---:|---|']
    for r in constellations[:20]: report.append(f'| {r["members"]} | {r["TM_helices"]} | {r["max_distance_A"]:.3f} | {r["constellation_score"]:.5f} | {r["shared_cavities"]} |')
    report+=['','## Robustness','', '| Variant | Spearman | Shared top20 | Clusters | Clustered-residue Jaccard | Best cluster Jaccard | >10 percentile shifts |','|---|---:|---:|---:|---:|---|---:|']
    for r in robustness: report.append(f'| {r["variant"]} | {r["spearman"]:.4f} | {r["top20_shared"]} | {r["cluster_count"]} | {r["clustered_residue_Jaccard"]:.3f} | {r["mean_best_cluster_Jaccard"]} | {r["percentile_shifts_gt10"]} |')
    report+=['','## Limitations','', 'The single predicted monomer and its low-confidence regions may place loops incorrectly. pLDDT measures local confidence, and PAE qualifies relative positioning. TM constraints provide an approximate unsigned axis, not a validated membrane orientation. SASA is water-probe accessibility, not lipid exposure. Dihedral secondary structure is coarse because DSSP is unavailable. Pocket volumes depend on probe/grid and are not physical ion-accessibility measurements. Connected polar networks can span a large distance; compact constellations use an all-pairs criterion. Heuristic scores are hypotheses and may prioritize nonliganding scaffold residues; original S3/S4 scores remain preserved. No experimental or literature comparison has been made.','', 'Commands: `python3 -B scripts/fetch_predicted_structure.py`; `scripts/remote_run.sh "python -B scripts/find_transmembrane_polar_clusters.py"`. The latter invokes analyze_structure_qc.py. No installations or local AlphaFold run.']
    (ROOT/'reports/step5_structure_analysis.md').write_text('\n'.join(report)+'\n')
    paths=[out/'SLC30A10_structure_confidence.tsv',out/'SLC30A10_structural_context.tsv',out/'SLC30A10_TM_polar_clusters.tsv',out/'SLC30A10_cavities.tsv',out/'SLC30A10_structure_transport_candidates.tsv',out/'SLC30A10_candidate_coordination_constellations.tsv',out/'SLC30A10_structure_robustness.tsv',out/'SLC30A10_structure_variant_scores.tsv',ROOT/'results/intermediate/SLC30A10_cavity_voxels.tsv',ROOT/'results/step5_model_qc.json',ROOT/'results/step5_analysis_qc.json',ROOT/'reports/step5_structure_analysis.md',ROOT/'scripts/view_step5_candidates.pml']+[ROOT/'figures'/name for name in ['SLC30A10_structure_topology.png','SLC30A10_polar_cluster_structure.png','SLC30A10_structure_candidate_scores.png']]
    (ROOT/'results/step5_outputs.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in paths))
    print(json.dumps(summary,indent=2)); print('Robustness:',json.dumps(robustness,indent=2))
if __name__=='__main__': main()
