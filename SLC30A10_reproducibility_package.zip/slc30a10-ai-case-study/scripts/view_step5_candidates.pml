# Run from project root: pymol scripts/view_step5_candidates.pml
load structures/predicted/AF-Q6XR72-F1-model_v6.pdb, predicted
hide everything
show cartoon, predicted
color gray80, predicted
select TM1, predicted and resi 12-28
color cyan, TM1
select TM2, predicted and resi 44-61
color magenta, TM2
select TM3, predicted and resi 86-105
color yellow, TM3
select TM4, predicted and resi 121-141
color orange, TM4
select TM5, predicted and resi 245-265
color green, TM5
select TM6, predicted and resi 279-299
color marine, TM6
select cluster1, predicted and resi 25+28+39+40+41+43+46+47+50+84+85+127+244+248+252+284
show sticks, cluster1
select cluster2, predicted and resi 258+280
show sticks, cluster2
select top20, predicted and resi 248+127+280+47+50+25+252+284+46+294+291+18+295+28+290+89+85+298+282+54
show spheres, top20 and name CA
set sphere_scale, 0.3
orient predicted
bg_color white
