#!/usr/bin/env python3
"""Submit only the frozen sequence to Phobius and SCAMPI-single; preserve responses."""
import hashlib,json,re,urllib.request,urllib.parse,http.cookiejar
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]; raw=ROOT/'data/raw/topology'; raw.mkdir(parents=True,exist_ok=True)
f=ROOT/'sequences/SLC30A10_human_canonical.fasta'; data=f.read_bytes()
assert hashlib.sha256(data).hexdigest()==f.with_suffix('.sha256').read_text().split()[0]
seq=''.join(data.decode().splitlines()[1:]); payload='>blind_target\n'+seq+'\n'
jar=http.cookiejar.CookieJar(); opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def request(url,name,body=None,headers={}):
 with opener.open(urllib.request.Request(url,data=body,headers=headers),timeout=45) as r:
  b=r.read(); meta=dict(url=url,response_url=r.url,date=datetime.now(timezone.utc).isoformat(),headers=dict(r.headers),response_sha256=hashlib.sha256(b).hexdigest(),input_fasta_sha256=hashlib.sha256(data).hexdigest())
 (raw/name).write_bytes(b); (raw/(name+'.provenance.json')).write_text(json.dumps(meta,indent=2)+'\n')
 return b,meta
if not (raw/'phobius.json').exists():
 b,m=request('https://phobius.sbc.su.se/api/predict','phobius.json',json.dumps({'sequence':payload,'plot':True}).encode(),{'Content-Type':'application/json'})
 p=json.loads(b)['predictions'][0]; print('Phobius:',{k:v for k,v in p.items() if k not in ['svg']})
if not (raw/'scampi_submission.html').exists():
 b,m=request('https://scampi.bioinfo.se/','scampi_form.html')
 token=re.search(r'name=["\']csrfmiddlewaretoken["\'] value=["\']([^"\']+)',b.decode()).group(1)
 form=dict(csrfmiddlewaretoken=token,rawseq=payload,jobname='blind_sequence_topology',email='',forcerun='on',do='Submit SCAMPI-single')
 b,m=request('https://scampi.bioinfo.se/pred/','scampi_submission.html',urllib.parse.urlencode(form).encode(),{'Content-Type':'application/x-www-form-urlencoded','Referer':'https://scampi.bioinfo.se/'})
 print('SCAMPI response URL:',m['response_url'])
 print(b.decode()[-7000:])
submission=(raw/'scampi_submission.html').read_text()
job=re.search(r'Result for (rst_[a-zA-Z0-9]+)',submission).group(1)
b,m=request('https://scampi.bioinfo.se/pred/result/'+job,'scampi_status.html')
links=re.findall(r'href=["\']([^"\']+)',b.decode())
print('SCAMPI result links:',[x for x in links if '/result/' in x])
for link in links:
 if '/static/result/'+job+'/' in link and (link.endswith('.fa') or link.endswith('.txt') or link.endswith('.top')):
  filename='scampi_'+link.rsplit('/',1)[-1]
  if not (raw/filename).exists(): request(urllib.parse.urljoin('https://scampi.bioinfo.se/',link),filename)
