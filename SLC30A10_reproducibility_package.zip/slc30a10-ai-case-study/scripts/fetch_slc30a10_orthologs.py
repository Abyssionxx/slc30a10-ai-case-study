#!/usr/bin/env python3
"""Fetch vertebrate gene-name-based SLC30A10 ortholog candidates; see shared module."""
from slc30_dataset_common import main
if __name__ == '__main__':
    main('orthologs')
