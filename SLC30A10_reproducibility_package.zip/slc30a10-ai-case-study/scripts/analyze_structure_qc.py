#!/usr/bin/env python3
"""Validate AFDB model against frozen target; write per-residue confidence."""
import csv,json,hashlib
from pathlib import Path
import numpy as np
from Bio.PDB import PDBParser
from Bio.Data.PDBData import protein_letters_3to1
ROOT=Path(__file__).resolve().parents[1]

def load():
    raw=ROOT/'data/raw/structure'; selected=json.loads((raw/'selected_model.json').read_text())
    for record in json.loads((raw/'retrieval_provenance.json').read_text()):
        assert hashlib.sha256((ROOT/record['file']).read_bytes()).hexdigest()==record['sha256']
    fasta=ROOT/'sequences/SLC30A10_human_canonical.fasta'; target=''.join(fasta.read_text().splitlines()[1:])
    assert hashlib.sha256(fasta.read_bytes()).hexdigest()==fasta.with_suffix('.sha256').read_text().split()[0]
    for manifest in ['step3_outputs.sha256','step4_outputs.sha256']:
        for line in (ROOT/'results'/manifest).read_text().splitlines():
            digest,name=line.split('  ',1); assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    pdb=ROOT/'structures/predicted'/selected['pdbUrl'].rsplit('/',1)[-1]
    structure=PDBParser(QUIET=True).get_structure('AF',pdb)
    assert len(structure)==1 and len(list(structure[0]))==1
    residues=list(structure[0].get_residues())
    assert len(residues)==len(target)==485
    assert [r.id for r in residues]==[(' ',i,' ') for i in range(1,486)]
    assert ''.join(protein_letters_3to1[r.resname] for r in residues)==target
    reps=np.array([r['CA' if a=='G' else 'CB'].coord for r,a in zip(residues,target)],float)
    ca=np.array([r['CA'].coord for r in residues],float); confidence=np.array([r['CA'].bfactor for r in residues])
    doc=json.loads((raw/selected['plddtDocUrl'].rsplit('/',1)[-1]).read_text())
    assert doc['residueNumber']==list(range(1,486)) and np.allclose(confidence,doc['confidenceScore'],atol=.011)
    pae=np.array(json.loads((raw/selected['paeDocUrl'].rsplit('/',1)[-1]).read_text())[0]['predicted_aligned_error']); assert pae.shape==(485,485)
    topology=list(csv.DictReader((ROOT/'data/processed/SLC30A10_topology_consensus.tsv').open(),delimiter='\t'))
    s3=list(csv.DictReader((ROOT/'results/tables/SLC30A10_sequence_specificity.tsv').open(),delimiter='\t'))
    s4=list(csv.DictReader((ROOT/'results/tables/SLC30A10_topology_transport_candidates.tsv').open(),delimiter='\t')); s4=sorted(s4,key=lambda r:int(r['human_residue_number']))
    assert ''.join(r['amino_acid'] for r in topology)==target
    return locals()

def main():
    d=load(); confidence=d['confidence']; topology=d['topology']
    top20=sorted(d['s4'],key=lambda r:(-float(r['transport_score']),int(r['human_residue_number'])))[:20]
    topids={int(r['human_residue_number']) for r in top20}; rows=[]
    for i,a in enumerate(d['target']):
        rows.append(dict(residue_number=i+1,amino_acid=a,pLDDT=float(confidence[i]),confidence_bin='very_high' if confidence[i]>=90 else 'confident' if confidence[i]>=70 else 'low' if confidence[i]>=50 else 'very_low',strict_TM_helix=int(topology[i]['predicted_helix_number']),step4_top20=i+1 in topids))
    p=ROOT/'results/tables/SLC30A10_structure_confidence.tsv'
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t'); w.writeheader(); w.writerows(rows)
    helices={}
    for h in sorted({r['strict_TM_helix'] for r in rows}-{0}):
        values=[r['pLDDT'] for r in rows if r['strict_TM_helix']==h]; helices[str(h)]={'mean':float(np.mean(values)),'median':float(np.median(values)),'min':float(min(values)),'count':len(values)}
    qc=dict(model_id=d['selected']['modelEntityId'],model_version=d['selected']['latestVersion'],coverage=1.,residues=485,missing_residues=[],numbering_sequence_exact=True,mean_pLDDT=float(np.mean(confidence)),median_pLDDT=float(np.median(confidence)),below70=int(sum(confidence<70)),TM_helix_confidence=helices,step4_top20_confidence={d['target'][i-1]+str(i):float(confidence[i-1]) for i in sorted(topids)},pLDDT_JSON_match=True)
    (ROOT/'results/step5_model_qc.json').write_text(json.dumps(qc,indent=2)+'\n')
    print(json.dumps(qc,indent=2)); return d,qc
if __name__=='__main__': main()
