#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
REMOTE=/path/to/projects/slc30a10_ai
SSH='ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o UpdateHostKeys=no -o ConnectTimeout=10'
if [[ $# -gt 1 || ( $# -eq 1 && $1 != --dry-run ) ]]; then
    echo "Usage: $0 [--dry-run]" >&2; exit 2
fi
for dir in results figures logs reports; do
    # Refuse local symlinks so retrieval cannot follow them outside the project.
    if [[ -L "$ROOT/$dir" ]] || [[ -d "$ROOT/$dir" && -n "$(find "$ROOT/$dir" -type l -print -quit)" ]]; then
        echo "Refusing destination containing symlinks: $ROOT/$dir" >&2; exit 1
    fi
done
for dir in results figures logs reports; do
    # Preserve existing local files; never delete local or remote outputs.
    rsync -av --safe-links --ignore-existing "${1:---human-readable}" -e "$SSH" \
        --exclude='.DS_Store' --exclude='__pycache__/' --exclude='*.py[co]' \
        "slc-server:$REMOTE/$dir/" "$ROOT/$dir/"
done
