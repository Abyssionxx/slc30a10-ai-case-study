#!/usr/bin/env python3
"""Pre-specified blind mutation panel and evidence-ablation analysis; no network."""
import csv,hashlib,json,math,itertools
from pathlib import Path
from datetime import datetime,timezone
import numpy as np
from analyze_sequence_conservation import ranks,percentiles
ROOT=Path(__file__).resolve().parents[1]
if (ROOT/'reports/BLIND_PHASE_LOCKED.txt').exists(): raise RuntimeError('Blind phase locked: refusing to regenerate predictions')

def read(name): return list(csv.DictReader((ROOT/name).open(),delimiter='\t'))
def indexed(name,key): return {int(r[key]):r for r in read(name)}
def write(name,rows,fields=None):
    with (ROOT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else fields,delimiter='\t'); w.writeheader(); w.writerows(rows)
def polarity(a): return 'acidic' if a in 'DE' else 'basic' if a in 'KRH' else 'polar' if a in 'NQSTC' else 'polar-aromatic' if a=='Y' else 'nonpolar-aromatic' if a in 'FW' else 'nonpolar'
def size(a): return next(k for k,v in {'tiny':'GA','small':'SCDNTP','medium':'EQHV','large':'ILMKRFYW'}.items() if a in v)
def charge(a): return -1 if a in 'DE' else 1 if a in 'KR' else 0
ATOMS={'D':{'O':2},'E':{'O':2},'N':{'O':1,'N':1},'Q':{'O':1,'N':1},'S':{'O':1},'T':{'O':1},'Y':{'O':1},'C':{'S':1},'M':{'S':1},'H':{'N':2},'K':{'N':1},'R':{'N':3},'W':{'N':1}}
LIB={'D':'AN','E':'AQ','N':'AQ','Q':'AN','S':'AT','T':'AS','C':'AS','H':'AN','K':'AR','R':'AK','Y':'AF','I':'AV','L':'AI','V':'AI','M':'AL','F':'AY','W':'AF'}
def loss(w,m):
    if w in 'DE': return 1. if m=='A' else .8
    if w in 'HC': return 1. if m=='A' else .6
    if w=='Y': return .75 if m=='A' else .6
    if w in 'NQST': return .75 if m=='A' else .25
    if w in 'KR': return .6 if m=='A' else .25
    return .2 if m=='A' else .15

def main():
    hashes=json.loads((ROOT/'data/processed/step6_input_ranking_hashes.json').read_text())['files']
    for path,digest in hashes.items(): assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest
    for name in ['step3_outputs.sha256','step4_outputs.sha256','step5_outputs.sha256']:
        for line in (ROOT/'results'/name).read_text().splitlines():
            digest,path=line.split('  ',1); assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==digest,path
    seq=''.join((ROOT/'sequences/SLC30A10_human_canonical.fasta').read_text().splitlines()[1:]); assert len(seq)==485
    s3=indexed('results/tables/SLC30A10_sequence_specificity.tsv','human_residue_number'); s4=indexed('results/tables/SLC30A10_topology_transport_candidates.tsv','human_residue_number'); s5=indexed('results/tables/SLC30A10_structure_transport_candidates.tsv','residue_number'); context=indexed('results/tables/SLC30A10_structural_context.tsv','residue_number')
    g1=set()
    for i,w in enumerate(seq,1):
        r=s5[i]
        if w in 'DEHNQSTCY' and int(r['TM_helix'])>0 and float(r['ortholog_identity'])>=.8 and float(r['pLDDT'])>=70 and (r['cluster_membership'] or r['cavity_membership']): g1.add(i)
    xyz={i:tuple(float(context[i][k]) for k in ['x','y','z']) for i in context}
    mutations=[]; components={}
    for i,w in enumerate(seq,1):
        if w not in LIB: continue
        r=s5[i]; c4=s4[i]; I=float(r['ortholog_identity']); S3=float(r['step3_specificity_score']); T4=float(r['step4_transport_score']); S5=float(r['step5_score']); C=bool(r['cluster_membership']); V=bool(r['cavity_membership']); N=min(int(r['cross_helix_polar_neighbors6'])/3,1); conf=float(r['pLDDT']); core=int(r['TM_helix']); near=int(r['associated_near_TM_helix'])
        if w in 'YILVMFW' and not(core>0 and conf>=70 and I>=.8 and (C or V) and N>0): continue
        L5=1. if core else .6 if near else .1
        L4=float(c4['location_factor']); K4=float(c4['chemistry_factor']); P4=float(c4['long_region_factor']); density=float(c4['polar_charged_density_pm4'])
        rebuilt4=I*(.5+.5*S3)*L4*K4*(.5+.5*density)*P4
        assert math.isclose(rebuilt4,T4,abs_tol=1e-12)
        def reconstruct(mode):
            factor=1. if mode=='no_specificity' else .5+.5*S3
            t=I*factor*(1. if mode=='no_topology' else L4)*K4*(.5+.5*density)*(1. if mode=='no_topology' else P4)
            cc=0 if mode=='no_cluster' else C; vv=0 if mode=='no_cavity' else V
            structure=I*(.5+.5*t)*(1. if mode=='no_topology' else L5)*(.4+.2*N+.2*cc+.2*vv)*conf/100
            return structure,cc,vv
        assert math.isclose(reconstruct('primary')[0],S5,abs_tol=1e-12)
        G2=w in 'DEKRHNQSTCY' and near>0 and I>=.7 and conf>=70 and (N>0 or any(math.dist(xyz[i],xyz[j])<=8 for j in g1 if j!=i))
        G3=I>=.8 and float(r['step3_specificity_percentile'])>=90
        components[i]=dict(I=I,S3=S3,T4=T4,S5=S5,C=C,V=V,N=N,confidence=conf,core=core,near=near,G1=i in g1,G2=G2,G3=G3)
        for m in LIB[w]:
            F=loss(w,m); lost={element:max(0,ATOMS.get(w,{}).get(element,0)-ATOMS.get(m,{}).get(element,0)) for element in ['O','N','S']}
            values={}
            for mode in ['primary','no_specificity','no_topology','no_cluster','no_cavity']:
                structure,cc,vv=reconstruct(mode)
                values[mode]=structure*I*(.25+.75*F)*(.5+.25*cc+.25*vv)*(.5+.5*N)
            mutation_class='alanine substitution' if m=='A' else 'amide neutralization' if w in 'DE' else 'conservative/chemistry contrast'
            mutations.append(dict(wild_type=w,residue_position=i,mutant=m,mutation=w+str(i)+m,mutation_class=mutation_class,ortholog_conservation=I,step3_specificity_score=S3,step3_specificity_percentile=float(r['step3_specificity_percentile']),step4_topology_score=T4,step5_structure_score=S5,TM_helix=core,associated_near_TM_helix=near,cavity_membership=r['cavity_membership'],polar_cluster_membership=r['cluster_membership'],cross_helix_polar_neighbors=int(r['cross_helix_polar_neighbors6']),formal_charge_change=charge(m)-charge(w),charge_caveat='H titratable; nominal charge only' if 'H' in w+m else 'nominal charge; local protonation unmodeled',polarity_change=polarity(w)+' -> '+polarity(m),size_class_change=size(w)+' -> '+size(m),lost_potential_O=lost['O'],lost_potential_N=lost['N'],lost_potential_S=lost['S'],removes_potential_coordination_atom=any(lost.values()),pLDDT=conf,chemical_loss_factor=F,chemical_priority_multiplier=.25+.75*F,cluster_cavity_multiplier=.5+.25*C+.25*V,cross_helix_centrality=N,network_multiplier=.5+.5*N,mutation_priority_score=values['primary'],no_specificity_score=values['no_specificity'],no_topology_score=values['no_topology'],no_cluster_score=values['no_cluster'],no_cavity_score=values['no_cavity'],group1_eligible=i in g1,group2_eligible=G2,group3_eligible=G3,PLM_score='NA: not available'))
    for r,p in zip(mutations,percentiles([r['mutation_priority_score'] for r in mutations])): r['mutation_priority_percentile']=p
    mutations.sort(key=lambda r:(-r['mutation_priority_score'],r['residue_position'],r['mutant']))
    positions=sorted(components); bypos={i:[r for r in mutations if r['residue_position']==i] for i in positions}; best={i:bypos[i][0] for i in positions}
    residue_order=sorted(positions,key=lambda i:(-best[i]['mutation_priority_score'],i)); selected=set(); groups={}
    for group,quota in [('G1',5),('G2',4),('G3',3)]:
        eligible=[i for i in residue_order if i not in selected and components[i][group]]
        if group=='G3': eligible.sort(key=lambda i:(-best[i]['step3_specificity_percentile'],-components[i]['I'],i))
        groups[group]=eligible[:quota]; selected.update(groups[group])
    group_helices={components[i]['core'] for i in groups['G1']}
    # Qualification correction documented separately; primary scores are unchanged.
    matched_pool=[r for r in mutations if r['TM_helix']>0 and r['pLDDT']>=80]
    sorted_scores=sorted(r['mutation_priority_score'] for r in matched_pool)
    cutoff=sorted_scores[(len(sorted_scores)-1)//4]
    control_pool=[r for r in matched_pool if r['chemical_loss_factor']<=.25 and r['residue_position'] not in selected and r['mutation_priority_score']<=cutoff]
    control_pool.sort(key=lambda r:(r['mutation_priority_score'],r['residue_position'],r['mutant']))
    controls=[]
    for r in control_pool:
        if r['residue_position'] not in {x['residue_position'] for x in controls}: controls.append(r)
        if len(controls)==2: break
    panel=[]
    descriptions={'G1':'possible direct ion-interaction','G2':'possible transport-network','G3':'possible SLC30A10-specific regulatory/specificity','control':'computational negative control'}
    def panelrow(r,group,contrast=False):
        i=r['residue_position']; c=components[i]
        evidence='high (within-model)' if c['confidence']>=85 and c['I']>=.9 and (c['C'] or c['V']) else 'moderate' if c['confidence']>=70 and c['I']>=.8 else 'low'
        outcome='weak' if group=='control' else 'strong' if r['mutation_priority_percentile']>=90 else 'moderate' if r['mutation_priority_percentile']>=60 else 'weak'
        rationale=f"{r['mutation_class']}; chemical-loss prior={r['chemical_loss_factor']}; ortholog identity={c['I']:.3f}; S3 percentile={r['step3_specificity_percentile']:.2f}; TM={c['core']}; cross-helix neighbors={r['cross_helix_polar_neighbors']}; cluster={c['C']}; cavity={c['V']}"
        if contrast: rationale+='; amide contrast to separate charge loss from alanine side-chain removal'
        if group=='control': rationale+='; conservative substitution selected from lowest-priority eligible controls; not guaranteed inert'
        return dict(residue=r['wild_type']+str(i),residue_position=i,wild_type=r['wild_type'],substitution=r['mutant'],mutation=r['mutation'],hypothesis_group=group,hypothesis=descriptions[group],tier={'G1':'Tier 1','G2':'Tier 2','G3':'Tier 3','control':'control'}[group],predicted_qualitative_effect=outcome,confidence_level=evidence,TM_helix=c['core'],ortholog_conservation=c['I'],step3_specificity_percentile=r['step3_specificity_percentile'],step4_score=c['T4'],step5_score=c['S5'],mutation_priority_score=r['mutation_priority_score'],mutation_priority_percentile=r['mutation_priority_percentile'],pLDDT=c['confidence'],rationale=rationale)
    for group in ['G1','G2','G3']:
        for i in groups[group]: panel.append(panelrow(best[i],group))
    acidic=[i for i in groups['G1'] if seq[i-1] in 'DE'][:2]
    for i in acidic:
        variant=next(r for r in bypos[i] if r['mutant']==('N' if seq[i-1]=='D' else 'Q')); panel.append(panelrow(variant,'G1',True))
    panel.extend(panelrow(r,'control') for r in controls)
    primary=np.array([best[i]['mutation_priority_score'] for i in positions]); top10=set(sorted(positions,key=lambda i:(-best[i]['mutation_priority_score'],i))[:10]); sensitivity=[]; dependencies=[]
    primary_pct=percentiles(primary)
    for mode in ['no_specificity','no_topology','no_cluster','no_cavity']:
        values=[max(r[mode+'_score'] for r in bypos[i]) for i in positions]; alt={i:v for i,v in zip(positions,values)}; alt_top=set(sorted(positions,key=lambda i:(-alt[i],i))[:10]); altpct=percentiles(values)
        sensitive=[]
        for i,a,b in zip(positions,primary_pct,altpct):
            dependent=abs(a-b)>10 or ((i in top10)!=(i in alt_top))
            if dependent: sensitive.append(seq[i-1]+str(i))
            dependencies.append(dict(ablation=mode,residue_position=i,residue=seq[i-1]+str(i),primary_residue_priority=best[i]['mutation_priority_score'],ablated_residue_priority=alt[i],primary_percentile=a,ablated_percentile=b,percentile_shift=b-a,highly_dependent=dependent,top10_membership_changes=(i in top10)!=(i in alt_top)))
        sensitivity.append(dict(ablation=mode,spearman=float(np.corrcoef(ranks(primary),ranks(values))[0,1]),top10_shared=len(top10&alt_top),highly_dependent_residues=';'.join(sensitive),top10_enter=';'.join(seq[i-1]+str(i) for i in sorted(alt_top-top10)),top10_leave=';'.join(seq[i-1]+str(i) for i in sorted(top10-alt_top))))
    write('results/tables/SLC30A10_mutation_prioritization.tsv',mutations)
    write('results/tables/SLC30A10_final_blind_mutation_panel.tsv',panel)
    write('results/tables/SLC30A10_mutation_evidence_sensitivity.tsv',sensitivity)
    write('results/tables/SLC30A10_mutation_evidence_dependencies.tsv',dependencies)
    tiers={k:[seq[i-1]+str(i) for i in v] for k,v in groups.items()}
    summary=dict(tier1=tiers['G1'],tier2=tiers['G2'],tier3=tiers['G3'],panel_mutations=[r['mutation'] for r in panel],controls=[r['mutation'] for r in controls],panel_mutation_count=len(panel),panel_unique_residues=len({r['residue_position'] for r in panel}),candidate_mutations=len(mutations),candidate_residues=len(positions),group_counts={k:len(v) for k,v in groups.items()},PLM='skipped: packages/weights absent',sensitivity=sensitivity)
    (ROOT/'results/step6_qc.json').write_text(json.dumps(summary,indent=2)+'\n')
    datasets={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(list((ROOT/'sequences').glob('*.fasta'))+list((ROOT/'alignments').glob('*.fasta')))}
    modelqc=json.loads((ROOT/'results/step5_model_qc.json').read_text()); structureqc=json.loads((ROOT/'results/step5_analysis_qc.json').read_text())
    report=['# FINAL BLIND PREDICTION: human SLC30A10 transport determinants','', 'This is a falsifiable, sequence/prediction-derived hypothesis set. No target-paper evidence has been used. No experimental SLC30A10 structures, reported mutations, disease variants, or literature-derived functional residues were accessed. No predictions have been compared with experimental ground truth.','', 'The matched SHA256 manifest, BLIND_PHASE_LOCKED.txt, and git snapshot define the final blind freeze. Predictions are not experimental findings.','', '## Frozen target and datasets','', 'Canonical human SLC30A10: UniProtKB Q6XR72, reviewed, 485 aa; accession resolved by exact-gene/taxonomy query in Step1, not hard-coded.','', '| File | SHA256 |','|---|---|']
    for name,h in datasets.items(): report.append(f'| {name} | `{h}` |')
    report+=['','### Preserved ranking hashes','']+[f'- {name}: `{h}`' for name,h in hashes.items()]
    report+=['','## Methods summary, Steps 1–6','', '1. Exact-gene UniProt query resolved the reviewed canonical target; raw sequence and provenance preserved and checksummed.', '2. Separate datasets: 60 vertebrate candidate orthologs/60 species and 10 reviewed human SLC30A1–10 paralogs. Orthology remains gene-name-based and provisional; fragments, ambiguity and prespecified length outliers were documented.', '3. Separate MAFFT 7.526 alignments (60x639 and10x1041), fixed human-position mapping, identity/entropy/coverage and sequence specificity. Lamprey-removal sensitivity retained the primary dataset.', '4. Independent Phobius and SCAMPI-single predictions; six TM regions. Strict/union sensitivity and prespecified chemical/location score. Long non-TM regions were not labeled disordered.', '5. AlphaFold DB AF-Q6XR72-F1 version6 sequence-matched predicted monomer, pLDDT/PAE, representative-atom networks, grid pocket fallback, 18 robustness variants. No experimental structure used.', '6. Pre-specified mutation chemistry and priority formula, hypothesis groups, conservative controls and four evidence ablations. No PLM scores: no suitable installed model or cached weights.', '', '## Exact Step 6 rules and scoring','',(ROOT/'data/processed/step6_prespecified_methods.md').read_text(),'','## Final residue hierarchy','', '**Tier 1 — highest-confidence predicted transport-critical candidates within this blind model:** '+', '.join(tiers['G1'])+'.','', '**Tier 2 — strong secondary candidates:** '+', '.join(tiers['G2'])+'.','', '**Tier 3 — exploratory specificity/regulatory candidates:** '+', '.join(tiers['G3'])+'.','', 'Tier membership reflects the pre-specified experimental arms and evidence quality, not a claim of demonstrated binding or transport mechanism.','', '### Tier 1 evidence','', '| Residue | Sequence evidence | Topology | Structure | Chemical test / proposed mutations |','|---|---|---|---|---|']
    for i in groups['G1']:
        r=best[i]; c=components[i]; variants=[p['mutation'] for p in panel if p['residue_position']==i]
        report.append(f'| {seq[i-1]}{i} | Identity {c["I"]:.3f}; specificity percentile {r["step3_specificity_percentile"]:.2f} | Strict TM{c["core"]} | pLDDT {c["confidence"]:.2f}; {r["polar_cluster_membership"]}; cavities {r["cavity_membership"]}; cross-helix neighbors {r["cross_helix_polar_neighbors"]} | {r["polarity_change"]}; '+', '.join(variants)+' |')
    report+=['','## Final minimal mutation panel','', f'{len(panel)} substitutions at {summary["panel_unique_residues"]} positions, including {len(controls)} computational controls. Group counts: '+str(summary['group_counts'])+'.','', '| Mutation | Hypothesis | Expected effect | Confidence | Rationale |','|---|---|---|---|---|']
    for r in panel: report.append(f'| {r["mutation"]} | {r["hypothesis_group"]}: {r["hypothesis"]} | {r["predicted_qualitative_effect"]} | {r["confidence_level"]} | {r["rationale"]} |')
    report+=['','## Predicted polar clusters','']
    for r in read('results/tables/SLC30A10_TM_polar_clusters.tsv'):
        if r['variant']=='strict_6A_all': report.append(f'- {r["cluster_id"]}: {r["members"]}; helices {r["TM_helices"]}; size {r["cluster_size"]}; mean/max pair distance {float(r["mean_pairwise_distance"]):.2f}/{float(r["max_pairwise_distance"]):.2f} A; mean pLDDT {float(r["mean_pLDDT"]):.2f}; mean PAE {float(r["mean_pairwise_PAE"]):.2f} A.')
    report+=['','## Predicted cavities','', 'Geometry-only grid pockets; probe-center voxel volumes are not calibrated cavity volumes.']
    for r in read('results/tables/SLC30A10_cavities.tsv'): report.append(f'- {r["cavity_id"]}: {r["volume_A3"]} A^3; lining residues {r["lining_residues"]}; TM helices {r["TM_helices"]}; acidic count {r["acidic_count"]}; polar/charged count {r["polar_charged_count"]}; mean pLDDT {float(r["mean_pLDDT"]):.2f}.')
    report+=['','## Evidence-layer robustness','', '| Removed layer | Spearman | Top10 overlap | Enter / leave |','|---|---:|---:|---|']
    for r in sensitivity: report.append(f'| {r["ablation"]} | {r["spearman"]:.6f} | {r["top10_shared"]}/10 | {r["top10_enter"]} / {r["top10_leave"]} |')
    for r in sensitivity: report.append(f'- Highly dependent under {r["ablation"]}: {r["highly_dependent_residues"] or "none"}.')
    report+=['','These are partial, correlated-evidence ablations. The primary panel was not changed after sensitivity analysis.','', '## Control-selection qualification correction','', 'The initial provisional controls I291V/L89I ranked above the 90th percentile of the full library and were rejected as insufficiently low-priority. This was a documented panel-selection correction, not a score/weight/tier adjustment. Final controls are the two lowest-score conservative variants (chemical-loss factor<=0.25) in the lower quartile of all core-TM,pLDDT>=80 candidate mutations, excluding test-panel sites. Matched pool:48 mutations; lower-quartile cutoff0.0295886626. S56T and T90S meet this criterion. The initial output is archived in data/raw/step6_initial_panel_superseded; the mutation-ranking checksum is verified unchanged.','', '## Negative findings','', '- No candidate triplet or quadruplet met the pre-specified mutual6A representative-atom geometry rule; no ion-coordination constellation is claimed.', '- No available PLM was used, and no new model weights or frameworks were downloaded.', '- No direct metal-binding affinity, Mn specificity, transport percentage, docking or molecular-dynamics result was calculated.', '- fpocket/P2Rank and DSSP were unavailable in checked locations: pocket analysis used the documented grid fallback and secondary structure used a coarse dihedral heuristic.', '', '## Uncertainty and limitations','', f'Model mean pLDDT {modelqc["mean_pLDDT"]:.2f}, median {modelqc["median_pLDDT"]:.2f}; {modelqc["below70"]}/485 residues below70. Local confidence is not correctness, and AlphaFold training/template influences cannot be excluded. Uncertain TM4 positions and the monomer model constrain interpretation.', 'Ortholog assignments are provisional and taxonomic sampling is uneven. MSA uncertainty, topology disagreements, heuristic chemical priors, representative-atom distances and cavity-grid choices can change rankings. Low-confidence exclusion zeroes scores and affects global rank correlations even where top candidates remain stable.', 'A connected polar network is not a compact metal site. Side-chain O/N/S counts do not establish donor orientation, protonation or ion selectivity. Hydrophobic controls can still affect folding or trafficking. High specificity outside a cavity can reflect regulatory, structural or alignment effects; Tier3 is exploratory.', 'Qualitative strong/moderate/weak effects are prioritization hypotheses. Any functional change should be interpreted alongside expression, localization/folding and WT/control measurements. No exact transport percentages are predicted.', '', '## Blindness statement','', '**No target-paper evidence has been used. Blind predictions are frozen before comparison with experimental ground truth.** Do not modify this report, panel or prior rankings after creation of BLIND_PHASE_LOCKED.txt; future ground-truth comparison belongs in separate files.']
    (ROOT/'reports/FINAL_BLIND_PREDICTION.md').write_text('\n'.join(report)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
