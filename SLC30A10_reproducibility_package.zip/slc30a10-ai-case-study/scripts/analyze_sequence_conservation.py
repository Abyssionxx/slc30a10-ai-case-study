#!/usr/bin/env python3
"""Blind, human-position-mapped scoring of two frozen MSAs; no network access."""
import csv, hashlib, json, math, os, platform
from collections import Counter
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR']=str(ROOT/'.runtime/matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
AA=set('ACDEFGHIKLMNPQRSTVWY')

def fasta(path):
    records={}; key=None
    for line in path.read_text().splitlines():
        if line.startswith('>'):
            key=line[1:].split()[0]
            if key in records: raise ValueError('Duplicate ID: '+key)
            records[key]=''
        elif line.strip():
            assert key is not None
            records[key]+=line.strip().upper()
    assert records and all(records.values())
    return records

def tsv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t'); w.writeheader(); w.writerows(rows)

def ranks(values):
    values=np.asarray(values); result=np.empty(len(values),float)
    order=np.argsort(values,kind='stable'); i=0
    while i<len(values):
        j=i+1
        while j<len(values) and values[order[j]]==values[order[i]]: j+=1
        result[order[i:j]]=(i+j-1)/2+1; i=j
    return result

def percentiles(values): return (100*(ranks(values)-1)/(len(values)-1)).tolist()

def stats(chars,human):
    counts=Counter(c for c in chars if c!='-'); k=sum(counts.values())
    p=[v/k for v in counts.values()] if k else []
    consensus=min(counts,key=lambda a:(-counts[a],a)) if k else '-'
    return dict(non_gap_count=k,coverage_fraction=k/len(chars),identity_fraction=counts[human]/k if k else 0.,shannon_entropy_bits=-sum(x*math.log2(x) for x in p),distinct_amino_acids=len(counts),consensus_residue=consensus,consensus_frequency=counts[consensus]/k if k else 0.)

def score(aln, target_id, target, omit=None):
    ids=[i for i in aln if i!=omit]; rows=[]; position=0
    for col,residue in enumerate(aln[target_id]):
        if residue=='-': continue
        position+=1
        rows.append(dict(human_residue_number=position,human_residue=residue,alignment_column=col+1,**stats([aln[i][col] for i in ids],residue)))
    assert ''.join(r['human_residue'] for r in rows)==target
    assert len(rows)==len(target)
    return rows

def compare(a,b):
    a=np.asarray(a); b=np.asarray(b)
    return dict(pearson=float(np.corrcoef(a,b)[0,1]),spearman=float(np.corrcoef(ranks(a),ranks(b))[0,1]),maximum_absolute_change=float(np.max(np.abs(a-b))),positions_rank_change_gt10=int(np.sum(np.abs(np.array(percentiles(a))-percentiles(b))>10)))

def main():
    for name in ['SLC30A10_human_canonical','SLC30A10_orthologs','human_SLC30_family']:
        p=ROOT/'sequences'/f'{name}.fasta'
        assert hashlib.sha256(p.read_bytes()).hexdigest()==p.with_suffix('.sha256').read_text().split()[0]
    canonical=fasta(ROOT/'sequences/SLC30A10_human_canonical.fasta'); assert len(canonical)==1
    target_id=next(iter(canonical)).split('|')[1]; target=next(iter(canonical.values()))
    alignments={}; qc={}
    for name,expected in [('SLC30A10_orthologs',60),('human_SLC30_family',10)]:
        inputs=fasta(ROOT/'sequences'/f'{name}.fasta'); aln=fasta(ROOT/'alignments'/f'{name}_mafft.fasta')
        assert set(inputs)==set(aln) and len(aln)==expected
        assert len({len(s) for s in aln.values()})==1
        for key,seq in aln.items():
            assert set(seq)<=AA|{'-'} and seq.replace('-','')==inputs[key], key
        assert aln[target_id].replace('-','')==target
        alignments[name]=aln
        qc[name]=dict(records=len(aln),alignment_length=len(next(iter(aln.values()))),ids_exactly_once=True,all_ungapped_sequences_match_inputs=True,frozen_target_present=True)
    orth=alignments['SLC30A10_orthologs']; family=alignments['human_SLC30_family']
    assert 'A0ACM8BIL7' in orth
    o=score(orth,target_id,target); f=score(family,target_id,target); no=score(orth,target_id,target,omit='A0ACM8BIL7')
    meta=list(csv.DictReader((ROOT/'data/processed/human_SLC30_family_metadata.tsv').open(),delimiter='\t'))
    genes={r['gene']:r['accession'] for r in meta}
    assert set(genes)=={'SLC30A'+str(i) for i in range(1,11)} and set(genes.values())==set(family)
    for row in f:
        col=row['alignment_column']-1
        for i in range(1,11): row['SLC30A'+str(i)]=family[genes['SLC30A'+str(i)]][col]
        other=stats([seq[col] for key,seq in family.items() if key!=target_id],row['human_residue'])
        row.update({'other9_'+k:v for k,v in other.items()})
    specificity=[]
    for a,b in zip(o,f):
        assert a['human_residue_number']==b['human_residue_number'] and a['human_residue']==b['human_residue']
        value=a['coverage_fraction']*a['identity_fraction']*b['other9_coverage_fraction']*(1-b['other9_identity_fraction'])
        specificity.append(dict(human_residue_number=a['human_residue_number'],human_residue=a['human_residue'],ortholog_identity=a['identity_fraction'],family_identity=b['identity_fraction'],ortholog_entropy=a['shannon_entropy_bits'],family_entropy=b['shannon_entropy_bits'],ortholog_coverage=a['coverage_fraction'],family_coverage=b['coverage_fraction'],other9_identity=b['other9_identity_fraction'],other9_coverage=b['other9_coverage_fraction'],specificity_score=value))
    values=[r['specificity_score'] for r in specificity]
    for r,p in zip(specificity,percentiles(values)): r['specificity_percentile']=p
    ov=[r['identity_fraction'] for r in o]; nv=[r['identity_fraction'] for r in no]
    sv=[a['coverage_fraction']*a['identity_fraction']*b['other9_coverage_fraction']*(1-b['other9_identity_fraction']) for a,b in zip(no,f)]
    sensitivity=[]
    for i in range(len(target)):
        sensitivity.append(dict(human_residue_number=i+1,human_residue=target[i],ortholog_identity_primary=ov[i],ortholog_identity_without_lamprey=nv[i],identity_delta=nv[i]-ov[i],identity_percentile_primary=percentiles(ov)[i],identity_percentile_without_lamprey=percentiles(nv)[i],specificity_primary=values[i],specificity_without_lamprey=sv[i],specificity_percentile_primary=percentiles(values)[i],specificity_percentile_without_lamprey=percentiles(sv)[i]))
    sensitivity_qc={'ortholog_identity':compare(ov,nv),'specificity':compare(values,sv),'method':'Drop lamprey from fixed MSA; no realignment'}
    sensitivity_qc['substantial_effect']=sensitivity_qc['specificity']['spearman']<.95 or sensitivity_qc['specificity']['positions_rank_change_gt10']>len(target)*.1
    out=ROOT/'results/tables'; out.mkdir(parents=True,exist_ok=True)
    for name,rows in [('SLC30A10_ortholog_conservation',o),('SLC30_family_conservation',f),('SLC30A10_sequence_specificity',specificity),('SLC30A10_ortholog_conservation_without_lamprey',no),('SLC30A10_lamprey_sensitivity',sensitivity)]: tsv(out/(name+'.tsv'),rows)
    qc['sensitivity']=sensitivity_qc; qc['human_positions']=len(target); qc['software']={'python':platform.python_version(),'numpy':np.__version__,'matplotlib':matplotlib.__version__}
    (ROOT/'results/step3_qc.json').write_text(json.dumps(qc,indent=2)+'\n')
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    x=np.arange(1,len(target)+1)
    fig,ax=plt.subplots(figsize=(13,4.5)); ax.plot(x,ov,lw=1,color='#176a87',label='Identity to human (non-gap denominator)'); ax.plot(x,[r['coverage_fraction'] for r in o],lw=1,color='#b7791f',alpha=.8,label='Coverage')
    ax.set(xlabel='Human SLC30A10 residue number',ylabel='Fraction',ylim=(-.03,1.06),xlim=(1,len(target)),title='SLC30A10 candidate ortholog conservation · 60 sequences'); ax.legend(loc='lower left',fontsize=9); fig.tight_layout(); fig.savefig(ROOT/'figures/SLC30A10_ortholog_conservation_profile.png',dpi=180); plt.close(fig)
    fig,axes=plt.subplots(2,1,figsize=(13,6),sharex=True)
    axes[0].plot(x,values,lw=1,color='#6c4298'); axes[0].set(ylabel='Specificity score',ylim=(-.03,1.03),title='Blind sequence-specificity profile')
    axes[1].plot(x,percentiles(values),lw=1,color='#176a87'); axes[1].set(xlabel='Human SLC30A10 residue number',ylabel='Rank percentile',ylim=(-3,103),xlim=(1,len(target)))
    fig.tight_layout(); fig.savefig(ROOT/'figures/SLC30A10_sequence_specificity_profile.png',dpi=180); plt.close(fig)
    top=sorted(specificity,key=lambda r:(-r['specificity_score'],r['human_residue_number']))[:20]
    report=['# Step 3: blind sequence conservation','', 'Sequence-only analysis; no experimental or structural comparison. Top residues are computational candidates, not established functional sites.','', '## Alignment provenance','', '```text',(ROOT/'logs/step3_alignment_provenance.txt').read_text().strip(),'```','', '## Dataset and alignment QC','']
    for name in alignments: report.append(f'- {name}: {qc[name]["records"]} records; {qc[name]["alignment_length"]} columns. Every input ID occurs once; all ungapped sequences exactly match inputs; frozen human target present.')
    report+=['','485 human positions mapped independently in each MSA.','', '## Pre-specified scoring and limitations','',(ROOT/'data/processed/step3_prespecified_methods.md').read_text(),'','## Lamprey sensitivity','', '```json',json.dumps(sensitivity_qc,indent=2),'```','', 'Primary alignment retains sea lamprey. Membership sensitivity does not test how realignment would change columns.','', '## Top 20 blind sequence-specificity candidates','', '| Position | Residue | Score | Percentile | Ortholog identity | Ortholog coverage | Other-9 identity | Other-9 coverage |','|---:|:---:|---:|---:|---:|---:|---:|---:|']
    for r in top: report.append(f'| {r["human_residue_number"]} | {r["human_residue"]} | {r["specificity_score"]:.6f} | {r["specificity_percentile"]:.3f} | {r["ortholog_identity"]:.4f} | {r["ortholog_coverage"]:.4f} | {r["other9_identity"]:.4f} | {r["other9_coverage"]:.4f} |')
    boundary=top[-1]['specificity_score']; report+=['',f'The rank-20 boundary score is shared by {sum(r["specificity_score"]==boundary for r in specificity)} residues. Ties are ordered by residue number only.','', 'Software: '+json.dumps(qc['software'])]
    (ROOT/'reports/step3_sequence_conservation.md').write_text('\n'.join(report)+'\n')
    paths=sorted(list((ROOT/'alignments').glob('*_mafft.fasta'))+list(out.glob('*conservation*.tsv'))+[out/'SLC30A10_sequence_specificity.tsv',out/'SLC30A10_lamprey_sensitivity.tsv',ROOT/'results/step3_qc.json']+list((ROOT/'figures').glob('*profile.png'))+[ROOT/'reports/step3_sequence_conservation.md'])
    (ROOT/'results/step3_outputs.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in paths))
    print(json.dumps(qc,indent=2)); print('Top 20:',', '.join(r['human_residue']+str(r['human_residue_number']) for r in top))

if __name__=='__main__': main()
