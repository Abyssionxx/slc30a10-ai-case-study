# Environment and exact execution examples

[Reproducibility](REPRODUCIBILITY.md) · [Pipeline](PIPELINE.md) · [Setup prompt](prompts/00_setup_audit.md)

## Architecture and operating contract

The Mac holds Git, prompts, source authoring and retrieved results. SSH sends scientific jobs to a user-owned Linux Conda environment; rsync returns artifacts. No Codex server installation is required by this architecture. Host addresses, port, username and key stay in the user's SSH configuration; `slc-server` abstracts those details.

| Setting | Existing instance |
|---|---|
| Local root | `/path/to/slc30a10_ai` |
| SSH alias | `slc-server` |
| Remote root | `/path/to/projects/slc30a10_ai` |
| Conda prefix | `/path/to/conda/envs/slc30a10_ai` |
| Conda activation | `/opt/miniforge3/etc/profile.d/conda.sh` |
| Normal CPU limit | 8; no more than 16 without explicit approval |
| Statistical evaluation | 1 thread |
| Long jobs | Expected >30 minutes: report purpose, command, CPU, RAM, disk, runtime and obtain approval per AGENTS.md |

Inspect available tools before installing anything. Use only project/user environments. No sudo, apt, global installs, shared Conda/base upgrades, or changes to `/usr`, `/usr/local`, `/opt/miniforge3` base. The wrapper's environment variables are defaults, not an OS resource sandbox: tool-specific flags must also obey limits. GPU visibility is disabled.

## Recorded versions, not a complete environment lock

| Dependency | Recorded version/source |
|---|---|
| Python | 3.11.16 |
| NumPy | 2.4.6 |
| SciPy | 1.17.1 |
| Biopython | 1.88 |
| Matplotlib | 3.11.1 |
| MAFFT | 7.526; 2024/Apr/26 |
| SeqKit | 2.1.0 |
| Phobius / SCAMPI-single | Responses retrieved 2026-09-13; exact service builds unavailable |
| Predicted model | AF-Q6XR72-F1 version 6, archived PDB/mmCIF, pLDDT and PAE |

Evidence: [execution versions](comparison/execution_provenance.json), [alignment log](logs/step3_alignment_provenance.txt), [dataset notes](data/processed/SLC30_step2_notes.md), [structure provenance](data/raw/structure/retrieval_provenance.json). HMMER/BLAST are audit candidates, not required executed stages in the completed workflow. fpocket/P2Rank and DSSP were unavailable; the recorded geometric cavity and dihedral fallbacks were used. PLM packages/weights were unavailable and skipped. No full historical Conda explicit lock was preserved here; package build/channel identity cannot be reconstructed from version numbers alone.

For a new run, capture `conda list --explicit` and `conda env export` from the project prefix into that new run's environment records, plus executable paths and version output. Install missing packages only into a new user-owned prefix. A fresh environment export is a current observation, not evidence of the 2026-09-13 environment.

## Exact wrapper usage

Run these examples from the existing local root. The dry runs require SSH connectivity. They are documented examples, not commands executed by this documentation update.

```sh
cd /path/to/slc30a10_ai
bash scripts/push_server.sh --dry-run
bash scripts/remote_run.sh 'python --version; mafft --version; seqkit version'
bash scripts/remote_run.sh 'sha256sum -c results/FINAL_BLIND_PREDICTION.sha256; sha256sum -c results/BLIND_PHASE_FILES.sha256'
bash scripts/pull_results.sh --dry-run
```

Actual transfer cycle for a fresh, configured run (review dry-run output first):

```sh
bash scripts/push_server.sh --dry-run
bash scripts/push_server.sh
bash scripts/remote_run.sh 'python --version'
bash scripts/pull_results.sh --dry-run
bash scripts/pull_results.sh
```

Scientific example for an **isolated, unlocked stage-input copy only**, after changing each wrapper's remote destination and activation prefix:

```sh
bash scripts/push_server.sh
bash scripts/remote_run.sh 'bash scripts/run_step3_alignments.sh'
bash scripts/remote_run.sh 'python -B scripts/analyze_sequence_conservation.py'
bash scripts/pull_results.sh --dry-run
bash scripts/pull_results.sh
```

Single-argument remote mode evaluates a shell command; multiple-argument mode preserves argv quoting:

```sh
bash scripts/remote_run.sh python -B --version
bash scripts/remote_run.sh 'OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 python --version'
```

[push_server.sh](scripts/push_server.sh) accepts only no argument or `--dry-run`. It uploads from its own parent directory, excludes Git, runtime/cache bytecode, and root results/figures/logs/reports; it never uses `--delete`. **It does not exclude ground_truth, comparison or experimental reference assets.** Never push a revealed checkout into a blind project. Review the complete staged input tree. It does not upload excluded output directories' contents, so a remote freeze audit requires those already to exist remotely.

[remote_run.sh](scripts/remote_run.sh) activates the fixed prefix, changes into the fixed remote root, creates project `.runtime/tmp` and `.runtime/cache`, exports the 8-thread BLAS/OpenMP limits, disables GPU visibility, and invokes Bash with error checking. Therefore even a version query can create these runtime directories. It uses BatchMode, strict host-key checks, no host-key updates and a 10-second connection timeout. If the host is not already trusted, configure SSH trust through the normal user process; do not disable verification.

[pull_results.sh](scripts/pull_results.sh) pulls **only results, figures, logs and reports**, with `--ignore-existing`, `--safe-links`, no deletion, and rejection of symlink-containing local destinations. It does not refresh existing files and does not fetch alignments, sequences, data, structures, comparison or ground_truth. Compare checksums; an existing stale file will remain stale.

For complete retrieval, explicitly stage omitted directories into a **new local staging directory**, preserving the canonical checkout. For example, after reveal when retrieving comparison data:

```sh
stage_dir="$(mktemp -d /tmp/slc30a10-retrieval.XXXXXX)"
rsync -av --safe-links --ignore-existing -e 'ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -o UpdateHostKeys=no -o ConnectTimeout=10' slc-server:/path/to/projects/slc30a10_ai/comparison/ "$stage_dir/comparison/"
```

Repeat explicitly for each required omitted directory; compare its manifest before incorporating files into a new run. Do not change the completed checkout to accommodate a remote mismatch. The synchronization wrappers hard-code this project's remote root; the YAML cannot redirect them.
