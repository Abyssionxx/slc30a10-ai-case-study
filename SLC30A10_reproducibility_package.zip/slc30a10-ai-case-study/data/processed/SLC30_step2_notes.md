# Step 2: blind sequence datasets

QC passed for dataset integrity and transfer. Orthology is provisional: exact gene-name retrieval does not prove orthology, and unannotated homologs or differently named teleost duplicates may be missed. No functional residue annotations, experimental mutation results, structures, or target literature were requested. Protein names were retained solely as database identity metadata, not used as selection criteria.

The frozen Step 1 FASTA checksum was verified before processing. Both datasets contain the identical frozen human SLC30A10 amino-acid sequence. Queries, timestamps, HTTP headers and response checksums are preserved in data/raw/uniprot_* directories. Sequence computation ran remotely with existing Biopython 1.88; remote validation used SeqKit 2.1.0.

## Selection policy

Ortholog query: (gene_exact:SLC30A10) AND (taxonomy_id:7742). From 482 records, exclude database fragments, any nonstandard residue, missing initiator M, inconsistent length, non-exact primary gene, or nonfrozen human records. Prespecified acceptable length is 388–582 aa (80–120% of 485). All 52 outside-window candidates were explicitly flagged and excluded with a completeness-uncertain reason in the accession-level selection audit. This is a conservative heuristic, not proof of truncation; genuine length-divergent homologs may be lost. There were 273 fragment-flagged records and 5 ambiguous records; these counts overlap other reasons.

Select one entry per taxonomy ID by reviewed status, then proximity to target length, then accession. Keep the frozen human representative. Balance clades by round-robin sampling, favoring new genera within each clade, up to 60 representatives. Of 120 quality-passing species representatives, 60 were omitted by the diversity cap. Taxonomic availability still limits balance: 28 mammals, 10 ray-finned fishes, 8 birds, 7 lepidosaurs, 4 turtles, 1 crocodilian, 1 amphibian, 1 cyclostome. No claim of complete vertebrate coverage is made.

Retained ortholog candidates: 60 species, 2 reviewed and 58 unreviewed; 393–486 aa, median 465 aa. The shortest and lowest-identity retained entry is A0ACM8BIL7 (Petromyzon marinus), 393 aa and 37.678% global identity. It passes the prespecified quality filters but remains a divergent, unreviewed candidate requiring later orthology scrutiny. No identity threshold was imposed or tuned.

Family query: (gene:SLC30*) AND (organism_id:9606) AND (reviewed:true). Keep exact primary genes SLC30A1 through SLC30A10, without metal-specificity filters. All 10 returned entries qualify. Length 369–765 aa, median 445 aa. SLC30A2 (372), SLC30A5 (765), SLC30A7 (376), and SLC30A8 (369) lie outside the target-relative ortholog length window but are retained: family paralogs need not share the target's length.

## Identity and integrity QC

Pairwise identity uses global alignment against the frozen target, match +2, mismatch -1, gap open -5, gap extension -0.5; identical residues divided by all alignment columns including gaps. Use the first optimum deterministically. These are QC alignments only; no MSA or conservation calculation was performed. Identity range is 37.678–100% for ortholog candidates and 15.453–100% for family proteins. Different architectures and terminal extensions affect this measure.

Both datasets have zero ambiguous sequences, zero duplicate sequences, and unique accessions and FASTA names. Ortholog taxonomy IDs are unique; all family records intentionally share taxonomy 9606. Remote seqkit rmdup checks by full name and sequence each removed zero records. Local recomputed SHA256 values matched checksum files and remote sha256sum output.

## Reproduction

Run in a clean project copy containing the frozen Step 1 input; scripts refuse to overwrite an existing dataset:

    scripts/remote_run.sh 'python -B scripts/fetch_slc30a10_orthologs.py; python -B scripts/fetch_human_slc30_family.py'

For exact response replay, pass --raw-dir data/raw/<matching_saved_response_directory> to each Python script in that clean copy. Live queries can change with database releases. The shared implementation is scripts/slc30_dataset_common.py.

After retrieval to the Mac, scripts/push_server.sh synchronized both datasets. Validation command:

    scripts/remote_run.sh 'seqkit version; for f in sequences/SLC30A10_orthologs.fasta sequences/human_SLC30_family.fasta; do seqkit stats -j 1 "$f"; seqkit rmdup -j 1 -n "$f" | seqkit stats -j 1; seqkit rmdup -j 1 -s "$f" | seqkit stats -j 1; sha256sum "$f"; done; sha256sum -c sequences/SLC30A10_orthologs.sha256; sha256sum -c sequences/human_SLC30_family.sha256'

Captured output: data/processed/SLC30_step2_remote_qc.txt. No downstream analysis was started.
