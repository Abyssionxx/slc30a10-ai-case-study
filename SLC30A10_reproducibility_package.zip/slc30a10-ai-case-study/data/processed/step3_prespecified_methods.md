# Step 3 methods fixed before alignment/scoring

Inputs: frozen Step 1 canonical FASTA and Step 2 ortholog/family FASTAs, verified by SHA256. No external scientific data or literature.

Separate MAFFT commands (MAFFT 7.526):

    mafft --auto --thread 8 --threadit 0 sequences/SLC30A10_orthologs.fasta > alignments/SLC30A10_orthologs_mafft.fasta
    mafft --auto --thread 8 --threadit 0 sequences/human_SLC30_family.fasta > alignments/human_SLC30_family_mafft.fasta

Each command is wrapped in GNU timeout 1200s; stdout and stderr preserved separately. Iterative-refinement multithreading is disabled for reproducibility. No random sampling or random seed is used.

Map each non-gap character of the aligned frozen human target to consecutive 1-based human positions, verifying the entire ungapped sequence equals the frozen target. Ortholog statistics include all 60 records (including the human target). Main family statistics include all 10 human paralogs. Also calculate family statistics excluding SLC30A10 (9 records) for specificity to avoid self-identity inflation.

For n records and k non-gap residues: coverage C=k/n; identity I=number identical to the human residue/k; Shannon entropy H=-sum(p_a log2 p_a) over non-gap amino-acid frequencies; consensus frequency=max(p_a); ties in consensus resolved alphabetically. Report distinct amino-acid count. All-gap columns: coverage 0, identity 0, entropy 0, consensus '-', consensus frequency 0; undefined biological statistics are flagged by k=0.

Specificity S = C_orth * I_orth * C_other9 * (1-I_other9). Equal multiplicative factors, no fitted weights, score in [0,1]. High values indicate conserved ortholog residues with covered but nonidentical other paralogs. Entropies are reported but do not enter the score. Report all-10 family identity/coverage separately from other-9 identity/coverage. No residue identity or functional annotation affects selection.

Percentile = 100*(average ascending rank - 1)/(485-1); ties receive their mean rank. Larger percentiles indicate larger score/conservation. Top-20 tie-breaker: smaller human residue number. Ties do not imply a biological ordering.

Sensitivity: remove A0ACM8BIL7 from the fixed ortholog alignment without realigning, rescore all columns and specificity with the original family alignment unchanged. Compare ortholog identity and specificity using Pearson and Spearman (average ranks), maximum absolute value changes, and count positions with absolute percentile changes >10 points. Operational substantial-effect flag, fixed beforehand: specificity Spearman <0.95 OR >10% of positions moving >10 specificity percentile points. Primary analysis retains lamprey; any flag prompts caution and presentation of the sensitivity output, without silently replacing the primary dataset. This test measures membership sensitivity, not alignment sensitivity.

Limitations: gene-name-based orthology remains provisional; equal sequence weights are not phylogenetic weights; uneven clade sampling can bias conservation. Divergent family alignments and gappy columns may be uncertain. This is a blind sequence signal, not evidence of transport or binding function.
