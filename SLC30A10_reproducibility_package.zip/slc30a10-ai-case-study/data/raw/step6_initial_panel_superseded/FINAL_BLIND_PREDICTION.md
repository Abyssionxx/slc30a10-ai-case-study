# FINAL BLIND PREDICTION: human SLC30A10 transport determinants

This is a falsifiable, sequence/prediction-derived hypothesis set. No target-paper evidence has been used. No experimental SLC30A10 structures, reported mutations, disease variants, or literature-derived functional residues were accessed. No predictions have been compared with experimental ground truth.

The matched SHA256 manifest, BLIND_PHASE_LOCKED.txt, and git snapshot define the final blind freeze. Predictions are not experimental findings.

## Frozen target and datasets

Canonical human SLC30A10: UniProtKB Q6XR72, reviewed, 485 aa; accession resolved by exact-gene/taxonomy query in Step1, not hard-coded.

| File | SHA256 |
|---|---|
| alignments/SLC30A10_orthologs_mafft.fasta | `48fc8c6dad50604e00fb1a94a8abb04776de3758489ccd6dd298741fd5267463` |
| alignments/human_SLC30_family_mafft.fasta | `0f13a79f7eb7fa727d27a8cf2853b4241937517edd2ca4fe4f405e265b0d733b` |
| sequences/SLC30A10_human_canonical.fasta | `6a297b6de2a94fb567e5eb450032cd90807705ab8eef5fc0727136b15a9c9448` |
| sequences/SLC30A10_orthologs.fasta | `d0796892c45df1f842c34a845bf268abd6fcb43943c1c4a4d63b7493e0aafdc4` |
| sequences/human_SLC30_family.fasta | `1e38e48396fadcf1fbe97c0344e896c549f561f4d839c1685622492d15107d31` |

### Preserved ranking hashes

- results/tables/SLC30A10_sequence_specificity.tsv: `458815ca2d705daf8510a466e5f4013a5554f9d33ff27250ac0ffd13e8acde91`
- results/tables/SLC30A10_topology_transport_candidates.tsv: `9ba1304186b4ff2788844871c1f341533214943e577667c96a1554482234e266`
- results/tables/SLC30A10_structure_transport_candidates.tsv: `7e21d96754aa4377f506a2967030bdaf6d2c79251fee0888c75bb1d94571a826`

## Methods summary, Steps 1–6

1. Exact-gene UniProt query resolved the reviewed canonical target; raw sequence and provenance preserved and checksummed.
2. Separate datasets: 60 vertebrate candidate orthologs/60 species and 10 reviewed human SLC30A1–10 paralogs. Orthology remains gene-name-based and provisional; fragments, ambiguity and prespecified length outliers were documented.
3. Separate MAFFT 7.526 alignments (60x639 and10x1041), fixed human-position mapping, identity/entropy/coverage and sequence specificity. Lamprey-removal sensitivity retained the primary dataset.
4. Independent Phobius and SCAMPI-single predictions; six TM regions. Strict/union sensitivity and prespecified chemical/location score. Long non-TM regions were not labeled disordered.
5. AlphaFold DB AF-Q6XR72-F1 version6 sequence-matched predicted monomer, pLDDT/PAE, representative-atom networks, grid pocket fallback, 18 robustness variants. No experimental structure used.
6. Pre-specified mutation chemistry and priority formula, hypothesis groups, conservative controls and four evidence ablations. No PLM scores: no suitable installed model or cached weights.

## Exact Step 6 rules and scoring

# Step 6 rules fixed before final mutation ranks

Inputs: frozen Step1–5 outputs; hashes of S3/S4/S5 ranking TSVs recorded in step6_input_ranking_hashes.json before scoring. No fitting, new biological annotation, mutation lookup, or PLM download. Remote inspection found no esm, transformers or torch and no cached weights; PLM skipped.

Mutation library: D->A,N; E->A,Q; N->A,Q; Q->A,N; S->A,T; T->A,S; C->A,S; H->A,N. Basic residues may be tested by K->A,R and R->A,K. Y->A,F tests its hydroxyl/aromatic context. Other hydrophobic/aromatic substitutions are limited to I->A,V; L->A,I; V->A,I; M->A,L; F->A,Y; W->A,F, and only if core strict TM, pLDDT>=70, ortholog identity>=0.8, cavity or cluster membership, and >=1 cross-helix polar neighbor. Y has the same strong-support gate because it is aromatic. A/G/P are not mutated in this panel design. All eligible polar/basic sites across the sequence remain in the mutation table, including exploratory sites.

Nominal charge: D/E=-1,K/R=+1,other residues=0; H is titratable and this nominal integer does not predict protonation. Polarity classes: D/E acidic,K/R/H basic,N/Q/S/T/C polar,Y polar-aromatic,F/W nonpolar-aromatic,other nonpolar. Size bins: tiny GA; small SCDNTP; medium EQHV; large ILMKRFYW. Side-chain potential O/N/S counts: D/E O2; N/Q O1N1; S/T/Y O1; C/M S1; H N2; K N1; R N3; W N1; others0. Report lost atom counts by element; no claim of actual donor geometry, protonation or Mn binding. Amide neutralization loses an O while retaining/replacing heteroatom chemistry.

Chemical-loss factor F: D/E->A 1; D->N/E->Q 0.8; H/C->A 1; H->N/C->S 0.6; N/Q/S/T/Y->A 0.75; Y->F 0.6; K/R->A 0.6; N<->Q/S<->T/K<->R 0.25; other supported hydrophobic/aromatic->A 0.2; other conservative hydrophobic/aromatic 0.15. These are pre-specified heuristic intervention strengths, not empirical functional predictions.

Primary mutation priority M = S5 * Iorth * (0.25+0.75*F) * (0.5+0.25*C+0.25*V) * (0.5+0.5*N).
S5 is unmodified Step5 score; Iorth unmodified Step3 ortholog identity; C/V binary primary6A cluster/cavity membership; N=min(cross-helix polar-neighbor count within6A /3,1). Report every factor, raw M, and mean-rank percentile. Residue priority=max M over its eligible substitutions. Ties: lower position then substitution alphabetically. No raw S3/S4/S5 score altered.

Hypothesis eligibility (overlapping flags): G1 DEHNQSTCY, core strict TM, ortholog identity>=0.8, pLDDT>=70, and cluster or cavity. G2 DEKRHNQSTCY, core/near TM, ortholog identity>=0.7, pLDDT>=70, and >=1 cross-helix polar neighbor or within8A (representative atoms) of any G1 residue. G3 ortholog identity>=0.8 and Step3 specificity percentile>=90; central-cavity location not required. Groups are hypotheses, not validated functions.

Panel selection without manual overrides: choose 5 highest-residue-priority G1 positions; then 4 highest remaining G2; then 3 highest remaining G3 sorted by Step3 specificity percentile then ortholog identity then position (this preserves a distinct specificity-testing arm). If fewer eligible positions exist report shortfall, never lower criteria to fill. Each receives its highest-priority mutation. Add amide neutralization for the two highest-priority acidic selected G1 positions if present, as mechanistic contrasts. Controls: choose two lowest-M conservative hydrophobic/aromatic substitutions from the strong-support-gated mutation library, core TM,pLDDT>=80,excluding panel positions; prefer helices represented in G1. Control selection is computational; weak effects are hypotheses, not guaranteed inactivity.

Tiers: selected G1 positions become Tier1 (max5), selected G2 Tier2, selected G3 Tier3. Controls are outside the tiers. Evidence confidence: high within this model if pLDDT>=85,Iorth>=0.9 and cluster/cavity; moderate if pLDDT>=70 and Iorth>=0.8; low otherwise. No claim of high experimental certainty. Qualitative outcome by full mutation-library percentile: >=90 strong, >=60 moderate,else weak; controls weak by design. Interpret as expected perturbation of transport-related function, potentially confounded by folding, abundance or trafficking. No exact transport percentages.

Leave-one-layer sensitivity recomputes only temporary derived scores, never edits S3–5. Reconstruct T4=Iorth*(.5+.5*S3)*L4*K4*(.5+.5*density)*P4 and S5=Iorth*(.5+.5*T4)*L5*(.4+.2*N+.2*C+.2*V)*pLDDT/100, checking exact baseline reproduction. Remove specificity: replace (.5+.5*S3) by1 in reconstructed T4; remove topology: replace direct L4,P4,L5 by1 (fixed graph/cavity membership still retains topology dependence); remove cluster: set C=0 in S5 and M; remove cavity: set V=0 in S5 and M. All other components fixed. Analyze max-mutation residue ranks on a fixed eligible-residue universe, report Spearman and top10 overlap. Highly dependent means >10 percentile-point shift or entry/exit top10. These are partial ablations; evidence layers are correlated and cannot be fully disentangled without rebuilding the analysis.

Recommended assay interpretation: compare transport with WT and the computational controls; measure expression/localization or folding in parallel so a transport change is not automatically assigned to direct ion interaction. This is assay logic, not external experimental evidence.


## Final residue hierarchy

**Tier 1 — highest-confidence predicted transport-critical candidates within this blind model:** N127, D248, D280, D47, S252.

**Tier 2 — strong secondary candidates:** D40, S50, N85, H244.

**Tier 3 — exploratory specificity/regulatory candidates:** S282, E339, D136.

Tier membership reflects the pre-specified experimental arms and evidence quality, not a claim of demonstrated binding or transport mechanism.

### Tier 1 evidence

| Residue | Sequence evidence | Topology | Structure | Chemical test / proposed mutations |
|---|---|---|---|---|
| N127 | Identity 1.000; specificity percentile 29.86 | Strict TM4 | pLDDT 85.31; strict_6A_all_C1; cavities V4; cross-helix neighbors 2 | polar -> nonpolar; N127A |
| D248 | Identity 1.000; specificity percentile 3.93 | Strict TM5 | pLDDT 82.56; strict_6A_all_C1; cavities V4; cross-helix neighbors 1 | acidic -> nonpolar; D248A, D248N |
| D280 | Identity 1.000; specificity percentile 3.93 | Strict TM6 | pLDDT 91.94; strict_6A_all_C2; cavities ; cross-helix neighbors 1 | acidic -> nonpolar; D280A, D280N |
| D47 | Identity 0.900; specificity percentile 3.93 | Strict TM2 | pLDDT 82.50; strict_6A_all_C1; cavities V2; cross-helix neighbors 0 | acidic -> nonpolar; D47A |
| S252 | Identity 1.000; specificity percentile 43.90 | Strict TM5 | pLDDT 90.31; strict_6A_all_C1; cavities ; cross-helix neighbors 1 | polar -> nonpolar; S252A |

## Final minimal mutation panel

16 substitutions at 14 positions, including 2 computational controls. Group counts: {'G1': 5, 'G2': 4, 'G3': 3}.

| Mutation | Hypothesis | Expected effect | Confidence | Rationale |
|---|---|---|---|---|
| N127A | G1: possible direct ion-interaction | strong | high (within-model) | alanine substitution; chemical-loss prior=0.75; ortholog identity=1.000; S3 percentile=29.86; TM=4; cross-helix neighbors=2; cluster=True; cavity=True |
| D248A | G1: possible direct ion-interaction | strong | moderate | alanine substitution; chemical-loss prior=1.0; ortholog identity=1.000; S3 percentile=3.93; TM=5; cross-helix neighbors=1; cluster=True; cavity=True |
| D280A | G1: possible direct ion-interaction | strong | high (within-model) | alanine substitution; chemical-loss prior=1.0; ortholog identity=1.000; S3 percentile=3.93; TM=6; cross-helix neighbors=1; cluster=True; cavity=False |
| D47A | G1: possible direct ion-interaction | strong | moderate | alanine substitution; chemical-loss prior=1.0; ortholog identity=0.900; S3 percentile=3.93; TM=2; cross-helix neighbors=0; cluster=True; cavity=True |
| S252A | G1: possible direct ion-interaction | strong | high (within-model) | alanine substitution; chemical-loss prior=0.75; ortholog identity=1.000; S3 percentile=43.90; TM=5; cross-helix neighbors=1; cluster=True; cavity=False |
| D40A | G2: possible transport-network | strong | high (within-model) | alanine substitution; chemical-loss prior=1.0; ortholog identity=1.000; S3 percentile=43.90; TM=0; cross-helix neighbors=2; cluster=True; cavity=False |
| S50A | G2: possible transport-network | strong | moderate | alanine substitution; chemical-loss prior=0.75; ortholog identity=0.900; S3 percentile=64.46; TM=2; cross-helix neighbors=0; cluster=True; cavity=True |
| N85A | G2: possible transport-network | strong | high (within-model) | alanine substitution; chemical-loss prior=0.75; ortholog identity=0.967; S3 percentile=77.48; TM=0; cross-helix neighbors=1; cluster=True; cavity=True |
| H244A | G2: possible transport-network | strong | moderate | alanine substitution; chemical-loss prior=1.0; ortholog identity=1.000; S3 percentile=43.90; TM=0; cross-helix neighbors=1; cluster=True; cavity=True |
| S282A | G3: possible SLC30A10-specific regulatory/specificity | strong | moderate | alanine substitution; chemical-loss prior=0.75; ortholog identity=0.967; S3 percentile=98.86; TM=6; cross-helix neighbors=0; cluster=False; cavity=False |
| E339A | G3: possible SLC30A10-specific regulatory/specificity | moderate | moderate | alanine substitution; chemical-loss prior=1.0; ortholog identity=0.950; S3 percentile=98.55; TM=0; cross-helix neighbors=0; cluster=False; cavity=False |
| D136A | G3: possible SLC30A10-specific regulatory/specificity | strong | low | alanine substitution; chemical-loss prior=1.0; ortholog identity=0.933; S3 percentile=98.35; TM=4; cross-helix neighbors=0; cluster=False; cavity=False |
| D248N | G1: possible direct ion-interaction | strong | moderate | amide neutralization; chemical-loss prior=0.8; ortholog identity=1.000; S3 percentile=3.93; TM=5; cross-helix neighbors=1; cluster=True; cavity=True; amide contrast to separate charge loss from alanine side-chain removal |
| D280N | G1: possible direct ion-interaction | strong | high (within-model) | amide neutralization; chemical-loss prior=0.8; ortholog identity=1.000; S3 percentile=3.93; TM=6; cross-helix neighbors=1; cluster=True; cavity=False; amide contrast to separate charge loss from alanine side-chain removal |
| I291V | control: computational negative control | weak | high (within-model) | conservative/chemistry contrast; chemical-loss prior=0.15; ortholog identity=0.983; S3 percentile=86.16; TM=6; cross-helix neighbors=1; cluster=False; cavity=True; conservative substitution selected from lowest-priority eligible controls; not guaranteed inert |
| L89I | control: computational negative control | weak | high (within-model) | conservative/chemistry contrast; chemical-loss prior=0.15; ortholog identity=0.917; S3 percentile=65.29; TM=3; cross-helix neighbors=1; cluster=False; cavity=True; conservative substitution selected from lowest-priority eligible controls; not guaranteed inert |

## Predicted polar clusters

- strict_6A_all_C1: E25;S28;S39;D40;S41;N43;S46;D47;S50;S84;N85;N127;H244;D248;S252;T284; helices 1;2;4;5;6; size 16; mean/max pair distance 12.69/29.24 A; mean pLDDT 87.59; mean PAE 3.37 A.
- strict_6A_all_C2: T258;D280; helices 5;6; size 2; mean/max pair distance 4.94/4.94 A; mean pLDDT 92.00; mean PAE 2.00 A.

## Predicted cavities

Geometry-only grid pockets; probe-center voxel volumes are not calibrated cavity volumes.
- V1: 48 A^3; lining residues L11;L15;L51;L55; TM helices 1;2; acidic count 0; polar/charged count 0; mean pLDDT 78.72.
- V2: 256 A^3; lining residues D47;S50;L51;G54;A82;N85;A86;L89;L236;N237;G240;V241;H244;S294;A295;L298; TM helices 2;3;6; acidic count 1; polar/charged count 6; mean pLDDT 76.73.
- V3: 64 A^3; lining residues L11;M14;L15;T18;L51;F134;V241;H244;V245; TM helices 1;2;4;5; acidic count 0; polar/charged count 2; mean pLDDT 74.07.
- V4: 24 A^3; lining residues M14;L17;T18;V126;N127;G130;F134;D248; TM helices 1;4;5; acidic count 1; polar/charged count 3; mean pLDDT 80.89.
- V5: 24 A^3; lining residues L243;G247;I290;I291;S294;A295; TM helices 5;6; acidic count 0; polar/charged count 1; mean pLDDT 82.26.

## Evidence-layer robustness

| Removed layer | Spearman | Top10 overlap | Enter / leave |
|---|---:|---:|---|
| no_specificity | 0.999955 | 10/10 |  /  |
| no_topology | 0.940069 | 9/10 | S39 / S50 |
| no_cluster | 0.999243 | 8/10 | T18;S294 / E25;S252 |
| no_cavity | 0.998933 | 7/10 | S39;S46;T284 / S50;N85;H244 |
- Highly dependent under no_specificity: none.
- Highly dependent under no_topology: K7;T8;R10;S39;S50;C52;S56;R62;R63;T65;R66;E78;S84;T90;C93;T95;R103;R106;R109;Q135;D136;C137;C143;C144;R146;N237;K268;S269;E270;C273;S293;Q308;H333;E334;H336;E339;T348;H350;R367;E368;H371;H376;T379;Q381;E383;C400;C404;C409;C414;C415.
- Highly dependent under no_cluster: T18;E25;S252;S294.
- Highly dependent under no_cavity: S39;S46;S50;N85;N237;H244;T284.

These are partial, correlated-evidence ablations. The primary panel was not changed after sensitivity analysis.

## Negative findings

- No candidate triplet or quadruplet met the pre-specified mutual6A representative-atom geometry rule; no ion-coordination constellation is claimed.
- No available PLM was used, and no new model weights or frameworks were downloaded.
- No direct metal-binding affinity, Mn specificity, transport percentage, docking or molecular-dynamics result was calculated.
- fpocket/P2Rank and DSSP were unavailable in checked locations: pocket analysis used the documented grid fallback and secondary structure used a coarse dihedral heuristic.

## Uncertainty and limitations

Model mean pLDDT 67.48, median 80.06; 205/485 residues below70. Local confidence is not correctness, and AlphaFold training/template influences cannot be excluded. Uncertain TM4 positions and the monomer model constrain interpretation.
Ortholog assignments are provisional and taxonomic sampling is uneven. MSA uncertainty, topology disagreements, heuristic chemical priors, representative-atom distances and cavity-grid choices can change rankings. Low-confidence exclusion zeroes scores and affects global rank correlations even where top candidates remain stable.
A connected polar network is not a compact metal site. Side-chain O/N/S counts do not establish donor orientation, protonation or ion selectivity. Hydrophobic controls can still affect folding or trafficking. High specificity outside a cavity can reflect regulatory, structural or alignment effects; Tier3 is exploratory.
Qualitative strong/moderate/weak effects are prioritization hypotheses. Any functional change should be interpreted alongside expression, localization/folding and WT/control measurements. No exact transport percentages are predicted.

## Blindness statement

**No target-paper evidence has been used. Blind predictions are frozen before comparison with experimental ground truth.** Do not modify this report, panel or prior rankings after creation of BLIND_PHASE_LOCKED.txt; future ground-truth comparison belongs in separate files.
