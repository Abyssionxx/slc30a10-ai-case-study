# Pipeline: setup → blind prediction → freeze → reveal → report

[Reproducibility](REPRODUCIBILITY.md) · [Environment/commands](ENVIRONMENT.md) · [Prompts](prompts/README.md) · [Parameter specification](config/pipeline.yaml)

Run stages sequentially, verifying input hashes and committing the validated stage before proceeding in a new project. This completed instance is locked: the table maps evidence and execution entry points, not instructions to regenerate it. Step 8 is the evaluation/reporting handoff; the actually executed statistical extension is Step 8A. No distinct historical Step 8 algorithm is invented.

| Stage / prompt | Input → operation → acceptance/output | Existing implementation/evidence |
|---|---|---|
| [Setup/audit](prompts/00_setup_audit.md) | Read rules → read-only server/software audit → configure user environment and isolated destinations; record versions and resource limits | [Rules](AGENTS.md), [wrappers](ENVIRONMENT.md) |
| [1 Sequence](prompts/01_sequence.md) | Authoritative canonical sequence → validate accession, length, alphabet, one record → immutable FASTA, metadata, raw retrieval and SHA256 | [Fetcher](scripts/fetch_slc30a10_sequence.py), [QC](data/processed/SLC30A10_step1_qc.json) |
| [2 Datasets](prompts/02_datasets.md) | Frozen sequence → separate candidate ortholog/family collections → selection audit, metadata, hashes and QC | [Orthologs](scripts/fetch_slc30a10_orthologs.py), [family](scripts/fetch_human_slc30_family.py), [policy](data/processed/SLC30_step2_notes.md) |
| [3 Conservation](prompts/03_conservation.md) | Two frozen FASTAs → separate MAFFT alignments, target mapping and specificity → all positions, QC, lamprey sensitivity | [Alignment](scripts/run_step3_alignments.sh), [analysis](scripts/analyze_sequence_conservation.py), [methods](data/processed/step3_prespecified_methods.md) |
| [4 Topology](prompts/04_topology.md) | Frozen sequence and Step 3 → Phobius/SCAMPI masks, chemistry and secondary score → preserve sequence scores, compare strict/union masks | [Retrieval](scripts/fetch_topology_predictions.py), [analysis](scripts/analyze_residue_context.py), [methods](data/processed/step4_prespecified_methods.md) |
| [5 Structure](prompts/05_structure.md) | Sequence-matched prediction and Steps 1–4 → structure QC, graph/cavity features and score → 18 sensitivity variants, retain zero constellation result | [Model retrieval](scripts/fetch_predicted_structure.py), [QC](scripts/analyze_structure_qc.py), [geometry](scripts/find_transmembrane_polar_clusters.py), [methods](data/processed/step5_prespecified_methods.md) |
| [6 Mutations](prompts/06_mutations.md) | Frozen Steps 1–5 → chemistry-defined substitutions and max mutation priority per residue → panel, tiers, controls, ablations and transparent correction record | [Prioritization](scripts/prioritize_mutations.py), [methods](data/processed/step6_prespecified_methods.md), [validation](results/step6_validation.json) |
| [Freeze](prompts/06B_freeze.md) | Validated blind assets → final report, manifests, local/remote verification and lock → immutable Git checkpoint before reveal | [Freeze script](scripts/freeze_blind_predictions.py), [lock](reports/BLIND_PHASE_LOCKED.txt) |
| [7 Ground truth](prompts/07_ground_truth_comparison.md) | Verified frozen checkpoint → paper/supplements curation, experimental alignment and stored-rank comparison → new ground_truth/comparison artifacts | [Comparison scripts](comparison/scripts/), [methods](comparison/methods_prespecified.md), [report](reports/STEP7_GROUND_TRUTH_COMPARISON.md) |
| [8 Handoff](prompts/08_evaluation_handoff.md) | Completed Step 7 → audit benchmarks and frozen covariates → fixed Step 8A design; no score changes | [Comparison README](comparison/README.md) |
| [8A Matched null](prompts/08A_matched_null.md) | Fixed ranks/labels/feature pools → 1M accepted permutations per design, exact checks and Holm adjustment → 90 cutoff and 72 rank tests | [Implementation](comparison/matched_null/matched_null.py), [protocol](comparison/matched_null/METHODS_PRESPECIFIED.md), [report](reports/STEP8A_MATCHED_NULL_ROBUSTNESS.md) |
| [Report](prompts/09_technical_report.md) | All frozen analyses → publication-style synthesis, sourced figures/tables → report and concise summary with integrity checks | [Full report](reports/SLC30A10_AI4SCIENCE_TECHNICAL_REPORT.md), [report assets](reports/technical_case_study/) |

## Fixed scoring chain

Use the linked methods for complete definitions, eligibility, ties, corner cases and sensitivity rules. These heuristic scores are not probabilities and were not fitted against the paper.

- Step 3: `S = Corth * Iorth * Cother * (1 - Iother)`; target excluded from other-paralog statistics, all-family values reported separately. Entropy is descriptive.
- Step 4: `T = Iorth * (0.5 + 0.5*S) * L * K * (0.5 + 0.5*D) * P`; L is topology location, K chemistry, D local polar density, P long non-TM penalty.
- Step 5: `S5 = Iorth * (0.5 + 0.5*T) * L * (0.4 + 0.2*N + 0.2*C + 0.2*V) * pLDDT/100`; N is capped cross-helix neighbor evidence, C cluster and V cavity membership.
- Step 6: `M = S5 * Iorth * (0.25 + 0.75*F) * (0.5 + 0.25*C + 0.25*V) * (0.5 + 0.5*N)`; F is the fixed substitution chemistry-loss factor. Residue priority is maximum M among eligible substitutions. Missing/ineligible sites remain unranked.

Step 3–5 percentiles use average ascending ranks with target-length normalization. Ranked-list ties use lower residue position; substitution ties then use alphabetical order. Step 6 ranked 215 of 485 positions. Panel tiers are selected hypothesis arms, not interchangeable with Top 5/10/20.

## Data lifecycle and stop conditions

Raw downloads live under data/raw; frozen sequence datasets under sequences; alignments under alignments; predicted models under structures/predicted; processed methods/QC under data/processed; analytical tables under results/tables; logs and figures retain command/output provenance. After reveal, ground_truth and comparison are separate from prediction outputs. Reports summarize, never replace, numerical evidence.

For each fresh stage: verify dependencies and checksums; save methods before scoring; estimate resources; run remotely with explicit limits; retrieve all required directories (the pull wrapper is limited); verify hashes and scientific QC; record failures and commit. Stop for identity/numbering/hash mismatches, inadequate inputs or unresolved blinding exposure. Do not weaken a rule to fill a panel or force a cavity/cluster. A new run should record full prompt text, config hash and stage commit at each gate.

## Statistical interpretation

Step 7 used 100,000 full-protein uniform permutations, seed 20260913. Step 8A used 1,000,000 accepted draws per benchmark/null, master seed 2026091308 and separate pilot seed 2026091309. NULL 0 samples all residues; NULL 1 matches TM/boundary eligibility; NULL 2 adds DEHNQSTCY; NULL 3 adds global conservation bins; NULL 4 adds confidence categories; diagnostic NULL 5 matches exact topology/chemistry plus ordinal conservation/confidence/Step 4 score bins, never geometry features.

Use product-uniform slot draws conditioned on distinct residues and feature-only deterministic sparse-pool expansion. Retain known sites in eligible pools. Report out-of-support sites, singleton pools and possible-set counts. Keep NA ranks; report rank summaries and their unranked handling explicitly. Use `(k+1)/(N+1)`, Monte Carlo intervals and prespecified Holm families. No p=0 or causal attribution to geometry. See the exact [matched-null protocol](comparison/matched_null/METHODS_PRESPECIFIED.md).
